from django.utils.html import format_html
from json import load
from analysis.admin_functions.val import (
    rent_state, sale_state
)


def form_building_id_str(obj):
    if not obj.building_id:
        return '-'

    if obj.building_id != 0:
        url = f"https://base2.of.ru/building/card/{obj.building_id}"
        return url


def form_building_id(obj):
    url = form_building_id_str(obj)
    return format_html(
        '<a href="{url}" target="_blank">{id}</a>',
        url=url,
        id=obj.building_id
    )


def form_block_id(obj):
    if obj.block_id:
        url = form_building_id_str(obj)
        url += '/rent-block/' if obj.offer_type == "Аренда" else '/sale-block/'
        return format_html(
            '<a href="{url}" target="_blank">{id}</a>',
            url=url + f'{obj.block_id}', id=obj.block_id
        )


def format_price(obj, param):
    """Функция форматирует числа по тысячам."""
    attr = getattr(obj, param)
    if attr is not None:
        formatted_price = "{:,}".format(
            int(attr)
        ).replace(",", " ")
        return formatted_price


def form_cian_id(obj):
    if obj.offer_type == "Аренда":
        url = (
            f"https://www.cian.ru/rent/commercial/{obj.cian_id.split(',')[0]}/"
        )
        return format_html(
            '<a href="{url}" target="_blank">{id}</a>',
            url=url,
            id=obj.cian_id
        )
    else:
        url = (
            f"https://www.cian.ru/sale/commercial/{obj.cian_id.split(',')[0]}/"
        )
        return format_html(
            '<a href="{url}" target="_blank">{id}</a>',
            url=url,
            id=obj.cian_id
        )


def get_rentavik_url(file, url_id):
    url = None
    with open(f'{file}_parsing_data.json', 'r', encoding='utf-8') as f:
        data = load(f)
    for item in data:
        if item['cian_id'] == url_id:
            url = item['url']

    return url


def form_rentavik_id(obj):
    url = ''
    url_id = obj.cian_id.split(',')[0]
    if obj.offer_type == "Аренда":
        url = get_rentavik_url('arenda', url_id)
    else:
        url = get_rentavik_url('prodaja', url_id)
    return format_html(
        '<a href="{url}" target="_blank">{id}</a>',
        url=url,
        id=obj.cian_id
    )


def exclude_rentavik_ads(queryset, request, broker_ids=None, resp_id=False):
    if not request.user.is_superuser \
            and not request.user.groups.filter(name="moderator").exists():
        if request.user.username in sale_state:
            queryset = queryset.filter(
                offer_type="Продажа"
            )
        if request.user.username in rent_state:
            queryset = queryset.filter(
                offer_type="Аренда"
            )
        if broker_ids:
            queryset = queryset.filter(
                broker_id__in=broker_ids
            )
        if resp_id:
            queryset = queryset.filter(
                broker_id=int(request.user.username)
            )

    queryset = queryset.exclude(
        agency_name__startswith="Рентавик Сайт"
    )

    return queryset


def only_rentavik_ads(queryset, request):
    if not request.user.is_superuser \
            and request.user.groups.filter(name="moderator").exists():
        if request.user.username in sale_state:
            queryset = queryset.filter(
                offer_type="Продажа"
            )
        if request.user.username in rent_state:
            queryset = queryset.filter(
                offer_type="Аренда"
            )

    queryset = queryset.filter(agency_name__startswith='Рентавик Сайт')

    return queryset
