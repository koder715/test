from django.db.models import F
from django.contrib import admin
from .models import (
    AdsCount, TopsCount,
    TypesCount, TypesAndTopCount,
    AuctionCount, AdvertisingCount
)
from admin_funcs.formats import format_price


@admin.register(AdsCount)
class AdsCountAdmin(admin.ModelAdmin):
    list_display = ("company", "rent", "sale", "total_display", )

    def get_queryset(self, request):
        queryset = super().get_queryset(request).annotate(
            total=F('rent') + F('sale')
        )

        return queryset

    def total_display(self, obj):
        return obj.total

    total_display.short_description = "Итого"
    total_display.admin_order_field = "total"


@admin.register(TopsCount)
class TopsCountAdmin(admin.ModelAdmin):
    list_display = (
        'company',
        'top',
        'premium',
        'standart',
        'publication',
    )


@admin.register(TypesCount)
class TypesCountAdmin(admin.ModelAdmin):
    list_display = ('company', 'plain', 'multi')


@admin.register(TypesAndTopCount)
class TypesAndTopCountAdmin(admin.ModelAdmin):
    list_display = ('company', 'promotion_type', 'plain', 'multi')


@admin.register(AuctionCount)
class AuctionCountAdmin(admin.ModelAdmin):
    list_display = ('company', 'rent', 'sale', 'total_display')

    def get_queryset(self, request):
        queryset = super().get_queryset(request).annotate(
            total=F('rent') + F('sale')
        )

        return queryset

    def total_display(self, obj):
        return obj.total

    total_display.short_description = "Итого"
    total_display.admin_order_field = "total"


@admin.register(AdvertisingCount)
class AdvertisingCountAdmin(admin.ModelAdmin):
    list_display = (
        'company',
        'format_total',
        'unique_id',
        'multi_count',
        'mean_count',
    )

    def format_total(self, obj):
        return format_price(obj, 'total_cost')

    format_total.short_description = "Итоговая стоимость"
