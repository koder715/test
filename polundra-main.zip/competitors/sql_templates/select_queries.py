ads_count_select = """
    SELECT
        agency_name,
        SUM(CASE WHEN deal_type = 'sale' THEN 1 ELSE 0 END) AS total_sale_listings,
        SUM(CASE WHEN deal_type = 'rent' THEN 1 ELSE 0 END) AS total_rent_listings
"""

promotion_select = """
    SELECT
        agency_name,
        SUM(CASE WHEN deal_type = 'tot' THEN 1 ELSE 0 END) AS total_listings,
        SUM(CASE WHEN promotion IN ('top', 'top3') THEN 1 ELSE 0 END) AS total_top,
        SUM(CASE WHEN promotion IN ('premium') THEN 1 ELSE 0 END) AS total_premium,
        SUM(CASE WHEN promotion IN ('standart') THEN 1 ELSE 0 END) AS total_standart,
        SUM(CASE WHEN promotion IN ('none', 'paid', 'noPromotion') THEN 1 ELSE 0 END) AS total_public
"""

promotion_select_total = """
    SELECT
        agency_name,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') THEN 1 ELSE 0 END) AS total_listings,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND promotion IN ('top', 'top3') THEN 1 ELSE 0 END) AS total_top,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND promotion IN ('premium') THEN 1 ELSE 0 END) AS total_premium,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND promotion IN ('standart') THEN 1 ELSE 0 END) AS total_standart,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND promotion IN ('none', 'paid', 'noPromotion') THEN 1 ELSE 0 END) AS total_public
"""

object_type_select = """
    SELECT
        agency_name,
        SUM(CASE WHEN deal_type = 'tot' THEN 1 ELSE 0 END) AS total_listings,
        SUM(CASE WHEN object_type IN ('plain') THEN 1 ELSE 0 END) AS total_plain,
        SUM(CASE WHEN object_type IN ('multi') THEN 1 ELSE 0 END) AS total_multi
"""

object_type_select_total = """
    SELECT
        agency_name,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') THEN 1 ELSE 0 END) AS total_listings,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND object_type IN ('plain') THEN 1 ELSE 0 END) AS total_plain,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND object_type IN ('multi') THEN 1 ELSE 0 END) AS total_multi
"""

promotion_and_object_type_select = """
    SELECT
        agency_name,
        promotion,
        SUM(CASE WHEN object_type IN ('plain') THEN 1 ELSE 0 END) AS total_plain,
        SUM(CASE WHEN object_type IN ('multi') THEN 1 ELSE 0 END) AS total_multi
"""

promotion_and_object_type_select_total = """
    SELECT
        agency_name,
        promotion,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND object_type IN ('plain') THEN 1 ELSE 0 END) AS total_plain,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND object_type IN ('multi') THEN 1 ELSE 0 END) AS total_multi
"""

auctions_count_select = """
    SELECT
        agency_name,
        SUM(CASE WHEN deal_type = 'sale' THEN auction_bet ELSE 0 END) AS total_sale,
        SUM(CASE WHEN deal_type = 'rent' THEN auction_bet ELSE 0 END) AS total_rent
"""

costs_select = """
    SELECT
        agency_name,
        COUNT(DISTINCT CASE WHEN deal_type IN ('sale', 'rent') THEN cian_id END) AS total,
        COUNT(DISTINCT CASE WHEN deal_type IN ('sale', 'rent') AND object_type IN ('multi') THEN cian_id END) AS total_multi,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND promotion IN ('top', 'top3') THEN 1 ELSE 0 END) AS total_top,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND promotion IN ('premium') THEN 1 ELSE 0 END) AS total_premium,
        SUM(CASE WHEN deal_type IN ('sale', 'rent') AND promotion IN ('standart') THEN 1 ELSE 0 END) AS total_standart
"""
