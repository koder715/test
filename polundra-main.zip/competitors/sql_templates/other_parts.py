base_having = """
    HAVING
        total_listings >= 100
"""

ads_having = """
    HAVING
        SUM(CASE WHEN deal_type IN ('sale', 'rent') THEN 1 END) >= 100
"""

base_groupby = """
    GROUP BY
        agency_name
"""

total_groupby = """
    GROUP BY
        agency_name, promotion
"""