from django.urls import path
from .views import (
    CompetitorAnalysisView, TopsAnalysisView,
    TypesAnalysisView, TypesAndTopsAnalysisView,
    AuctionCountAnalysisView, AdvertisingCountView,
    generate_metrics_report_view
)

urlpatterns = [
    path('generate_report/', CompetitorAnalysisView.as_view(), name='generate_report'),
    path('tops_report/', TopsAnalysisView.as_view(), name='tops_report'),
    path('types_report/', TypesAnalysisView.as_view(), name='types_report'),
    path('types_and_top_report/', TypesAndTopsAnalysisView.as_view(), name='types_and_top_report'),
    path('auction_count_report/', AuctionCountAnalysisView.as_view(), name='auctioncount_report'),
    path('advertising_count_report/', AdvertisingCountView.as_view(), name='advertisingcount_report'),
    path('generate_metrics_report/', generate_metrics_report_view, name='generate_metrics_report'),
]
