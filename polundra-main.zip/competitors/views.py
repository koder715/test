import pandas as pd
from datetime import datetime, timedelta
from django.shortcuts import render, redirect
from django.urls import reverse
from django.http import HttpResponse
from django.views.generic import ListView
from .forms import (
    ReportForm, PromotionForm,
    AdverisingCountForm, MarketingMetrics
)
from .models import (
    AdsCount, TopsCount,
    TypesCount, TypesAndTopCount,
    AuctionCount, AdvertisingCount
)
from .make_sql_request import report_marketing_metrics
import competitors.utils as ut


class AnalysisBaseView(ListView):
    """Базовый класс представлений отчетов."""
    template_name = ''
    context_object_name = 'competitors'
    report_model = None
    report_form = None
    report_column = ''

    def get(self, request):
        form = self.report_form()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.report_form(request.POST)
        if form.is_valid():
            end_date = form.cleaned_data['end_date']

            if "start_date" in form.cleaned_data:
                start_date = form.cleaned_data['start_date']
            else:
                start_date = end_date - timedelta(days=30)

            if "table_name" in form.cleaned_data:
                table_name = form.cleaned_data['table_name']
            else:
                table_name = ""

            ut.clear_old_reports(self.report_model)

            date_difference = end_date - start_date

            rows = ut.get_report_rows(table_name, start_date, end_date, self.report_column)

            ut.create_report_objects(rows, date_difference, self.report_model)

            report_url = reverse(
                f'admin:{self.report_model._meta.app_label}'
                f'_{self.report_model._meta.model_name}_changelist'
            )

            return redirect(report_url)

        return render(request, self.template_name, {'form': form})


class CompetitorAnalysisView(AnalysisBaseView):
    template_name = 'competitor_analysis.html'
    report_model = AdsCount
    report_form = ReportForm
    report_column = "adscount"


class TopsAnalysisView(AnalysisBaseView):
    template_name = 'promotion_analysis.html'
    report_model = TopsCount
    report_form = PromotionForm
    report_column = "promotion"


class TypesAnalysisView(AnalysisBaseView):
    template_name = 'types_analysis.html'
    report_model = TypesCount
    report_form = PromotionForm
    report_column = "object_type"


class TypesAndTopsAnalysisView(AnalysisBaseView):
    template_name = 'types_and_top_analysis.html'
    report_model = TypesAndTopCount
    report_form = PromotionForm
    report_column = "promotion, object_type"


class AuctionCountAnalysisView(AnalysisBaseView):
    template_name = 'auction_count.html'
    report_model = AuctionCount
    report_form = ReportForm
    report_column = "auctioncount"


class AdvertisingCountView(AnalysisBaseView):
    template_name = 'advertising_count.html'
    report_model = AdvertisingCount
    report_form = AdverisingCountForm
    report_column = "advertising_costs"


def generate_metrics_report_view(request):
    if request.method == 'POST':
        form = MarketingMetrics(request.POST)
        if form.is_valid():
            start_date = form.cleaned_data['start_date']
            end_date = form.cleaned_data['end_date']
            offer_type = form.cleaned_data['offer_type']
            object_type = form.cleaned_data['object_type']

            # Получение данных из базы и генерация отчета
            df = report_marketing_metrics(
                start_date, end_date, offer_type, object_type
            )

            # Сохранение данных в Excel
            response = HttpResponse(content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="marketing_report.xlsx"'

            with pd.ExcelWriter(response, engine='xlsxwriter') as writer:
                df.to_excel(writer, sheet_name='Report', index=False)

            return response
    else:
        form = MarketingMetrics()

    return render(request, 'metrics_report_form.html', {'form': form})
