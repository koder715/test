from django import forms
from bootstrap_datepicker_plus.widgets import DatePickerInput


class ReportForm(forms.Form):
    """Форма для количества объявлений."""
    start_date = forms.DateField(
        label='Начальная дата',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )
    end_date = forms.DateField(
        label='Конечная дата (+1 день)',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )


class PromotionForm(forms.Form):
    """Форма для статистики по продвижениям."""
    DEAL_TYPE_CHOICES = [
        ('cian_parsed_rents', 'Аренда'),
        ('cian_parsed_sales', 'Продажа'),
        ('all', 'Всего'),
    ]

    start_date = forms.DateField(
        label='Начальная дата',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )
    end_date = forms.DateField(
        label='Конечная дата (+1 день)',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )
    table_name = forms.ChoiceField(
        label='Тип сделки',
        choices=DEAL_TYPE_CHOICES,
        widget=forms.Select(attrs={'placeholder': 'Выберите тип сделки'}),
    )


class AdverisingCountForm(forms.Form):
    """Форма для расчета пакета циан."""
    end_date = forms.DateField(
        label='Конечная дата',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )


class MarketingMetrics(forms.Form):
    """Форма для выгрузки таблицы эксель по метрикам."""
    OFFER_TYPE_CHOICES = [
        ('Rent', 'Аренда'),
        ('Sale', 'Продажа'),
        ('all', 'Все')
    ]
    OBJECT_TYPE_CHOICES = [
        ('plain', 'Обычные'),
        ('multi', 'Мульти'),
        ('all', 'Все')
    ]

    start_date = forms.DateField(
        label='Начальная дата',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )
    end_date = forms.DateField(
        label='Конечная дата (+1 день)',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )
    offer_type = forms.ChoiceField(
        label='Тип сделки',
        choices=OFFER_TYPE_CHOICES,
        widget=forms.Select(attrs={'placeholder': 'Выберите тип сделки'}),
    )
    object_type = forms.ChoiceField(
        label='Тип объявления',
        choices=OBJECT_TYPE_CHOICES,
        widget=forms.Select(attrs={'placeholder': 'Выберите тип объявления'}),
    )
