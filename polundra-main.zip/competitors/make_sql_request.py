from django.db import connections
import competitors.sql_templates.select_queries as sq
import competitors.sql_templates.other_parts as op
import pandas as pd


def agency_names_needed(start_date, end_date):
    with connections['analytics'].cursor() as cursor:
        query = f"""
            {sq.ads_count_select}
            FROM
                (
                    SELECT agency_name, 'sale' AS deal_type
                    FROM cian_parsed_sales
                    WHERE created_at BETWEEN %s AND %s

                    UNION ALL

                    SELECT agency_name, 'rent' AS deal_type
                    FROM cian_parsed_rents
                    WHERE created_at BETWEEN %s AND %s
                ) AS combined_data
            {op.base_groupby}
            {op.ads_having}
        """

        cursor.execute(query, (start_date, end_date, start_date, end_date))

        rows = cursor.fetchall()

        agency_names = [row[0] for row in rows]

        return tuple(agency_names)


def report_ads_count(start_date, end_date):
    """Функция запроса для подсчета объявлений."""
    with connections['analytics'].cursor() as cursor:
        query = f"""
            {sq.ads_count_select}
            FROM
                (
                    SELECT agency_name, 'sale' AS deal_type
                    FROM cian_parsed_sales
                    WHERE created_at BETWEEN %s AND %s

                    UNION ALL

                    SELECT agency_name, 'rent' AS deal_type
                    FROM cian_parsed_rents
                    WHERE created_at BETWEEN %s AND %s
                ) AS combined_data
            {op.base_groupby}
            {op.ads_having}
        """

        cursor.execute(query, (start_date, end_date, start_date, end_date))

        rows = cursor.fetchall()

        return rows


def report_rent_or_sale(table_name, start_date, end_date, param):
    """Функция подсчета отчетов по аренде или продаже."""
    with connections['analytics'].cursor() as cursor:
        base_query = f"""
            FROM
                (
                    SELECT agency_name, 'tot' AS deal_type, {param}
                    FROM {table_name}
                    WHERE created_at BETWEEN %s AND %s
                ) AS combined_data
            {op.base_groupby}
            {op.base_having}
        """

        if param == "promotion":
            query = f"""
                {sq.promotion_select}
                {base_query}
            """

            cursor.execute(query, (start_date, end_date))

        elif param == "object_type":
            query = f"""
                {sq.object_type_select}
                {base_query}
            """

            cursor.execute(query, (start_date, end_date))

        elif param == "promotion, object_type":
            agency_names = agency_names_needed(start_date, end_date)
            placeholders = ', '.join(['%s'] * len(agency_names))

            query = f"""
                {sq.promotion_and_object_type_select}
                FROM
                    (
                        SELECT agency_name, {param}
                        FROM {table_name}
                        WHERE created_at BETWEEN %s AND %s
                        AND agency_name IN ({placeholders})
                    ) AS combined_data
                {op.total_groupby}
            """

            cursor.execute(query, (start_date, end_date) + tuple(agency_names))

        rows = cursor.fetchall()

        return rows


def report_all(start_date, end_date, param):
    """Функция подсчета отчетов и аренды, и продажи."""
    with connections['analytics'].cursor() as cursor:
        base_query = f"""
            FROM
                (
                    SELECT agency_name, 'sale' AS deal_type, {param}
                    FROM cian_parsed_sales
                    WHERE created_at BETWEEN %s AND %s

                    UNION ALL

                    SELECT agency_name, 'rent' AS deal_type, {param}
                    FROM cian_parsed_rents
                    WHERE created_at BETWEEN %s AND %s
                ) AS combined_data
            {op.base_groupby}
            {op.base_having}
        """

        if param == "promotion":
            query = f"""
                {sq.promotion_select_total}
                {base_query}
            """

            cursor.execute(query, (start_date, end_date, start_date, end_date))

        elif param == "object_type":
            query = f"""
                {sq.object_type_select_total}
                {base_query}
            """

            cursor.execute(query, (start_date, end_date, start_date, end_date))

        elif param == "promotion, object_type":
            agency_names = agency_names_needed(start_date, end_date)
            placeholders = ', '.join(['%s'] * len(agency_names))

            query = f"""
                {sq.promotion_and_object_type_select_total}
                FROM
                    (
                        SELECT agency_name, 'sale' AS deal_type, {param}
                        FROM cian_parsed_sales
                        WHERE created_at BETWEEN %s AND %s
                        AND agency_name IN ({placeholders})

                        UNION ALL

                        SELECT agency_name, 'rent' AS deal_type, {param}
                        FROM cian_parsed_rents
                        WHERE created_at BETWEEN %s AND %s
                        AND agency_name IN ({placeholders})
                    ) AS combined_data
                {op.total_groupby}
            """

            cursor.execute(
                query, (start_date, end_date)
                + tuple(agency_names) + (start_date, end_date)
                + tuple(agency_names)
            )

        rows = cursor.fetchall()

        return rows


def report_auct_count(start_date, end_date):
    """Функция запроса для подсчета аукционов."""
    with connections['analytics'].cursor() as cursor:
        query = f"""
            {sq.auctions_count_select}
            FROM
                (
                    SELECT agency_name, 'sale' AS deal_type, auction_bet
                    FROM cian_parsed_sales
                    WHERE created_at BETWEEN %s AND %s

                    UNION ALL

                    SELECT agency_name, 'rent' AS deal_type, auction_bet
                    FROM cian_parsed_rents
                    WHERE created_at BETWEEN %s AND %s
                ) AS combined_data
            {op.base_groupby}
            {op.ads_having}
        """

        cursor.execute(query, (start_date, end_date, start_date, end_date))

        rows = cursor.fetchall()

        return rows


def report_advertising_costs(start_date, end_date):
    with connections['analytics'].cursor() as cursor:
        query = f"""
            {sq.costs_select}
            FROM
                (
                    SELECT agency_name, cian_id, 'sale' AS deal_type, object_type, promotion
                    FROM cian_parsed_sales
                    WHERE created_at BETWEEN %s AND %s

                    UNION ALL 

                    SELECT agency_name, cian_id, 'rent' AS deal_type, object_type, promotion
                    FROM cian_parsed_rents
                    WHERE created_at BETWEEN %s AND %s
                ) AS combined_data
            {op.base_groupby}
        """

        cursor.execute(query, (start_date, end_date, start_date, end_date))

        rows = cursor.fetchall()

        return rows


def get_sql_temp_marketing_metrics(offer_type, object_type):
    """Метод возвращает шаблон запроса для отчета по метрикам."""
    base_temp = """
        SELECT date, SUM(searches_count), SUM(shows_count),
            SUM(total_views), SUM(phone_shows)
        FROM statistics
        WHERE date BETWEEN %s AND %s
    """

    obj_type_temp = ""

    if object_type != 'all':
        obj_type_temp = f"AND ad_type = '{object_type}'"

    if offer_type != 'all':
        base_temp += f"""
            AND external_id IN (
            SELECT external_id
            FROM feed_objects
            WHERE object_type LIKE '%{offer_type}%'
            {obj_type_temp}
        )
        """

    base_temp += " GROUP BY date"

    return base_temp


def report_marketing_metrics(
    start_date, end_date,
    offer_type, object_type
):
    """Метод, получающий данные для отчета по маркетинговым метрикам."""

    query = get_sql_temp_marketing_metrics(offer_type, object_type)

    with connections['analytics'].cursor() as cursor:
        cursor.execute(query, (
            start_date, end_date,
        ))
        rows = cursor.fetchall()

    # Преобразование данных в DataFrame
    df = pd.DataFrame(rows, columns=[
        'date', 'searches_count',
        'shows_count', 'total_views', 'phone_shows'
    ])

    # Добавление столбца "день недели"
    df['день недели'] = pd.to_datetime(df['date']).dt.day_name()

    # Преобразование типов данных для правильного округления
    df['searches_count'] = df['searches_count'].astype(float)
    df['shows_count'] = df['shows_count'].astype(float)
    df['total_views'] = df['total_views'].astype(float)
    df['phone_shows'] = df['phone_shows'].astype(float)

    # Добавление столбца "охват"
    df['охват'] = (df['shows_count'] / df['searches_count'] * 100).round(2)

    # Добавление столбца "CV1"
    df['CV1'] = (df['total_views'] / df['shows_count'] * 100).round(2)

    # Добавление столбца "CV2"
    df['CV2'] = (df['phone_shows'] / df['total_views'] * 100).round(2)

    # Переименование столбцов
    df.rename(columns={
        'searches_count': 'участие в поиске',
        'shows_count': 'показов в поиске',
        'total_views': 'просмотров',
        'phone_shows': 'расхлопов',
        'date': 'дата'
    }, inplace=True)

    df = df.reindex(columns=[
        'день недели', 'дата', 'участие в поиске', 'охват', 'показов в поиске',
        'CV1', 'просмотров', 'CV2', 'расхлопов'
    ])

    return df
