from .make_sql_request import (
    report_ads_count,
    report_rent_or_sale,
    report_all,
    report_auct_count,
    report_advertising_costs
)


def clear_old_reports(report_model):
    report_model.objects.all().delete()


def get_report_rows(table_name, start_date, end_date, report_column):
    print(report_column)
    if report_column == "adscount":
        return report_ads_count(start_date, end_date)
    elif report_column == "auctioncount":
        return report_auct_count(start_date, end_date)
    elif report_column == "advertising_costs":
        return report_advertising_costs(start_date, end_date)
    else:
        if table_name in ["cian_parsed_rents", "cian_parsed_sales"]:
            return report_rent_or_sale(
                table_name, start_date, end_date, report_column
            )
        elif table_name == "all":
            return report_all(start_date, end_date, report_column)
        else:
            return []


def create_report_objects(rows, date_difference, report_model):
    if report_model._meta.model_name == "typesandtopcount":
        for row in rows:
            (
                agency_name, promotion, plain, multi
            ) = row

            if plain/date_difference.days >= 100\
                    or multi/date_difference.days >= 100:

                prom_type = promotion_detect(promotion)
                report_model.objects.get_or_create(
                    company=agency_name,
                    promotion_type=prom_type,
                    plain=plain/date_difference.days,
                    multi=multi/date_difference.days
                )

    elif report_model._meta.model_name in ["adscount", "auctioncount"]:
        for row in rows:
            agency_name, total_sale_listings, total_rent_listings = row
            sale_m = total_sale_listings/date_difference.days
            rent_m = total_rent_listings/date_difference.days
            if sale_m >= 100 or rent_m >= 100:
                report_model.objects.get_or_create(
                    company=agency_name,
                    sale=sale_m,
                    rent=rent_m,
                )

    elif report_model._meta.model_name == "advertisingcount":
        for row in rows:
            (
                agency_name, total, multi,
                top, premium, standart
            ) = row
            if total >= 100:
                total_price = total * 1800 + standart * 61 + premium * 205 + top * 430

                discount = discount_for_volume(total)

                discounted_price = int(float(total_price) * (1 - discount))

                general_discount = int(discounted_price * 0.8)

                multi_part = int((multi / total) * 100)

                markup = discount_for_multi(multi_part)

                final_price = int(general_discount * (1 + markup))

                report_model.objects.get_or_create(
                    company=agency_name,
                    total_cost=final_price,
                    unique_id=total,
                    multi_count=multi,
                    mean_count=(standart+premium+top)/30,
                )

    else:
        for row in rows:
            agency_name, total_listings, *field_values = row

            if (total_listings / date_difference.days) >= 100:
                data = {'company': agency_name}

                field_names = [
                    f.name for f in report_model._meta.get_fields() if f.name not in [
                        'id', 'company'
                    ]
                ]

                for name, value in zip(field_names, field_values):
                    data[name] = value / date_difference.days

                report_model.objects.get_or_create(
                    company=agency_name, defaults=data
                )


def promotion_detect(promotion):
    """Определение типа продвижения."""
    promotion_types = {
        "premium": "Премиум",
        "top3": "Топы",
        "none": "Публикации",
    }

    for key, value in promotion_types.items():
        if promotion == key:
            promotion = value

    return promotion


def discount_for_volume(total):
    """Расчет скидки за объем."""
    discount_rates = {
        (650, float('inf')): 0.46,
        (350, 650): 0.4,
        (130, 350): 0.33,
        (60, 130): 0.27,
        (30, 60): 0.22,
        (0, 30): 0
    }

    discount = next(
        rate for (lower, upper), rate in discount_rates.items() if lower <= total <= upper
    )

    return discount


def discount_for_multi(multi_part):
    markup_rates = {
        (0, 15): 0.06,
        (15, 25): 0.12,
        (25, 35): 0.17,
        (35, 50): 0.23,
        (50, 100): 0.35
    }

    markup = next(
        rate for (lower, upper), rate in markup_rates.items() if lower <= multi_part <= upper
    ) if multi_part != 0 else 0

    return markup
