from django.db import models


class BaseModel(models.Model):
    company = models.CharField(
        verbose_name="Конкурент",
        max_length=256,
        null=True,
        blank=True
    )

    class Meta:
        abstract = True


class TotalBaseCount(BaseModel):
    """Базовая модель для подсчета по аренде и продаже."""
    rent = models.IntegerField(
        verbose_name="Аренда",
        null=True,
        blank=True
    )
    sale = models.IntegerField(
        verbose_name="Продажа",
        null=True,
        blank=True
    )

    class Meta:
        abstract = True


class PromotionTypeBase(BaseModel):
    """Базовый класс с типами продвижения"""
    top = models.IntegerField(
        verbose_name="Топы",
        default=0,
    )
    premium = models.IntegerField(
        verbose_name="Премиумы",
        default=0,
    )
    standart = models.IntegerField(
        verbose_name="Стандарты",
        default=0,
    )
    publication = models.IntegerField(
        verbose_name="Публикации",
        default=0,
    )

    class Meta:
        abstract = True


class AdsCount(TotalBaseCount):

    class Meta:
        ordering = ["-rent"]
        verbose_name = "Количество объявлений конкурентов"
        verbose_name_plural = "Количество объявлений конкурентов"


class TopsCount(PromotionTypeBase):

    class Meta:
        verbose_name = "Анализ продвижения"
        verbose_name_plural = "Анализ продвижения"


class TypesCount(BaseModel):
    plain = models.IntegerField(
        verbose_name="Простые",
        default=0,
    )
    multi = models.IntegerField(
        verbose_name="Мульти",
        default=0,
    )

    class Meta:
        verbose_name = "Количество видов объявлений"
        verbose_name_plural = "Количество видов объявлений"


class TypesAndTopCount(BaseModel):
    promotion_type = models.CharField(
        verbose_name="Тип продвижения",
        max_length=256
    )
    plain = models.IntegerField(
        verbose_name="Простые",
        default=0,
    )
    multi = models.IntegerField(
        verbose_name="Мульти",
        default=0,
    )

    class Meta:
        verbose_name = "Количество видов объявлений с типами продвижения"
        verbose_name_plural = "Количество видов объявлений с типами продвижения"


class AuctionCount(TotalBaseCount):

    class Meta:
        ordering = ["-rent"]
        verbose_name = "Количество аукционов конкурентов"
        verbose_name_plural = "Количество аукционов конкурентов"


class AdvertisingCount(BaseModel):
    total_cost = models.IntegerField(
        verbose_name="Итоговая стоимость"
    )
    unique_id = models.IntegerField(
        verbose_name="К-во уник. ID"
    )
    multi_count = models.IntegerField(
        verbose_name="К-во мультиков"
    )
    mean_count = models.IntegerField(
        verbose_name="Ср. к-во в день"
    )

    class Meta:
        verbose_name = "Стоимость пакета циан"
        verbose_name_plural = "Стоимость пакета циан"
