from django.db import models


class BaseModel(models.Model):
    owner_id = models.IntegerField(
        verbose_name="ID собственника"
    )
    rate = models.FloatField(
        verbose_name="Ставка"
    )
    area = models.IntegerField(
        verbose_name="Площадь"
    )
    address = models.CharField(
        verbose_name="Адрес",
        max_length=256
    )
    img = models.IntegerField(
        verbose_name="К-во фото"
    )

    class Meta:
        abstract = True


class SummedAds(BaseModel):
    STATUS_CHOICES = [
        ('new', 'Новый'),
        ('not_created', 'Не создан'),
        ('created', 'Создан'),
    ]

    rent_block_ids = models.TextField(
        verbose_name="ID блоков",
    )
    status = models.CharField(
        verbose_name="Статус",
        max_length=15,
        choices=STATUS_CHOICES,
        default='new',
    )
    resp_id = models.IntegerField(
        verbose_name="Отвественный в БД",
        null=True,
        blank=True
    )
    resp_name = models.CharField(
        verbose_name="Имя отвественного",
        max_length=100,
        null=True,
        blank=True
    )

    def __str__(self) -> str:
        return str(self.owner_id)

    class Meta:
        verbose_name = 'Суммированный блок'
        verbose_name_plural = 'Суммированные блоки'


class AdsForSum(BaseModel):
    building_id = models.IntegerField(
        verbose_name="Здание в БД",
        default=0,
    )
    rent_block_id = models.IntegerField(
        verbose_name="ID блока"
    )
    floor = models.IntegerField(
        verbose_name="Этаж",
        null=True,
        blank=True
    )
    summed_ads = models.ForeignKey(
        SummedAds,
        on_delete=models.CASCADE,
        verbose_name="Сумма блоков"
    )

    def __str__(self) -> str:
        return str(self.rent_block_id)

    class Meta:
        verbose_name = 'Блок на сумму'
        verbose_name_plural = 'Блоки на сумму'
