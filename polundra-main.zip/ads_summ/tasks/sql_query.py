get_rec_for_summ = """
    SELECT rb.id, rb.common_block_id, cb.building_id,
        cb.owner_id, b.address_full,
        m.value, cb.max_area, ft.name,
        img.VALUE, b.broker_id,
        rbs.first_name, rbs.last_name
    FROM rent_blocks AS rb
    INNER JOIN common_blocks AS cb ON rb.common_block_id = cb.id
    INNER JOIN buildings as b ON cb.building_id = b.id
    INNER JOIN money AS m ON rb.price_meter_year_id = m.id
    INNER JOIN common_block_floor_type AS cft ON cb.id = cft.common_block_id
    INNER JOIN floor_types AS ft ON cft.floor_type_id = ft.id
    INNER JOIN responsible_brokers as rbs ON b.broker_id = rbs.user_id
    LEFT JOIN  (
        SELECT common_block_id, COUNT(common_block_id) AS VALUE
            FROM common_block_images
            WHERE common_block_images.image_type IN ('photo')
            GROUP BY common_block_id
    ) AS img ON cb.id = img.common_block_id
    WHERE cb.owner_id IS NOT NULL
    AND img.VALUE IS NOT NULL
    AND cb.is_export_markets = 1
    AND cb.is_export_sites = 1
    AND b.is_export_markets = 1
    AND b.is_export_sites = 1
    AND cb.is_available = 1
    ORDER BY cb.building_id, cb.owner_id
"""


get_single_info = """
    SELECT rb.id, cb.owner_id,
        cb.building_id, b.address_full,
        m.value, cb.max_area, ft.name,
        img.VALUE
    FROM rent_blocks AS rb
    INNER JOIN common_blocks AS cb ON rb.common_block_id = cb.id
    INNER JOIN buildings as b ON cb.building_id = b.id
    INNER JOIN money AS m ON rb.price_meter_year_id = m.id
    INNER JOIN common_block_floor_type AS cft ON cb.id = cft.common_block_id
    INNER JOIN floor_types AS ft ON cft.floor_type_id = ft.id
    LEFT JOIN  (
        SELECT common_block_id, COUNT(common_block_id) AS VALUE
            FROM common_block_images
            WHERE common_block_images.image_type IN ('photo')
            GROUP BY common_block_id
    ) AS img ON cb.id = img.common_block_id
"""
