import logging
import pandas as pd
from django.db import transaction
from mysql.connector import connect, Error
from interface.settings import (
    OFHOST, OFDATABASE, OFPASS, OFUSER
)
from .sql_query import get_rec_for_summ, get_single_info
from ads_summ.models import SummedAds, AdsForSum


logger = logging.getLogger(__name__)


class GetSummedAds:

    def process_data(self):
        rows = self.get_filtered_objects()

        df = pd.DataFrame(rows, columns=[
            'rb_id', 'cb_id', 'cb_building_id',
            'cb_owner_id', 'address', 'money',
            'area', 'floor', 'img', 'broker_id',
            'first_name', 'last_name'
        ]).drop_duplicates(subset=['rb_id'])

        df['money'] = df['money'].astype(int)
        df['username'] = df['first_name'] + ' ' + df['last_name']

        rb_id_counts = df.groupby('cb_owner_id')['rb_id'].count()

        df_filtered = df[df['cb_owner_id'].isin(rb_id_counts[rb_id_counts > 1].index)]

        agg_df = df_filtered.groupby(['cb_owner_id', 'address']).agg({
            'rb_id': lambda x: ', '.join(map(str, x)),
            'money': 'sum',
            'area': 'sum',
            'img': 'sum',
            'broker_id': 'first',
            'username': 'first'
        }).reset_index()

        agg_df = agg_df[agg_df['rb_id'].str.contains(',')]

        return agg_df

    def add_to_db_summed(self):
        data = self.process_data()
        try:
            with transaction.atomic():
                for _, row in data.iterrows():
                    rent_value = row['money'] * row['area'] / 12
                    if rent_value >= 600000:
                        obj, created = SummedAds.objects.update_or_create(
                            owner_id=row['cb_owner_id'],
                            address=row['address'],
                            defaults={
                                'rent_block_ids': row['rb_id'],
                                'rate': int(rent_value),
                                'area': row['area'],
                                'img': row['img'],
                                'resp_id': row['broker_id'],
                                'resp_name': row['username']
                            }
                        )

                        if created:
                            logger.info(
                                f"Объявления №{obj.rent_block_ids} объединены в блок!"
                            )

        except Exception as ex:
            logger.error(f"Возникла ошибка {ex} при добавлении в базу данных!")

    def add_to_db_single(self):
        summed_info = SummedAds.objects.all()
        for summed in summed_info:
            rb_ids = summed.rent_block_ids.split(", ")
            for rb_id in rb_ids:
                (rb_id, cb_owner_id,
                 cb_building_id, address,
                 money, area,
                 floor, img) = self.get_single_row_data(rb_id)
                if floor.isdigit():
                    floor = int(floor)
                else:
                    floor = 0
                obj, created = AdsForSum.objects.update_or_create(
                    rent_block_id=rb_id,
                    defaults={
                        'owner_id': cb_owner_id,
                        'building_id': cb_building_id,
                        'address': address,
                        'rate': int(int(money) * area / 12),
                        'area': area,
                        'floor': floor,
                        'img': img,
                        'summed_ads': summed
                    }
                )

                if created:
                    logger.info(
                        f"Объявление №{obj.rent_block_id} добавлен!"
                    )

    @classmethod
    def get_filtered_objects(cls):
        try:
            with connect(
                host=OFHOST,
                database=OFDATABASE,
                user=OFUSER,
                password=OFPASS,
            ) as connection:
                with connection.cursor(buffered=True) as cursor:
                    query = get_rec_for_summ

                    cursor.execute(query)

                    rows = cursor.fetchall()

                    return rows

        except Error as e:
            logger.error(e)

    @classmethod
    def get_single_row_data(cls, rb_id):
        try:
            with connect(
                host=OFHOST,
                database=OFDATABASE,
                user=OFUSER,
                password=OFPASS,
            ) as connection:
                with connection.cursor(buffered=True) as cursor:
                    query = f"""
                        {get_single_info}
                        WHERE rb.id = %s
                    """

                    cursor.execute(query, (rb_id, ))

                    rows = cursor.fetchone()

                    return rows

        except Error as e:
            logger.error(e)
