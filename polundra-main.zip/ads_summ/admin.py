from collections.abc import Sequence
from django.contrib import admin
from django.http import HttpRequest
from django.utils.html import format_html

from .models import AdsForSum, SummedAds
from admin_funcs.formats import format_price


class AdsForSumInline(admin.TabularInline):
    model = AdsForSum
    extra = 0
    fields = (
        'owner_id',
        'rent_block_url',
        'formatted_rate',
        'area',
        'address',
        'img',
        'floor',
    )
    readonly_fields = ('formatted_rate', 'rent_block_url')

    def get_formset(self, request, obj=None, **kwargs):
        self.request = request
        return super().get_formset(request, obj, **kwargs)

    def formatted_rate(self, obj):
        if self.request.user.is_superuser:
            return obj.rate
        return format_price(obj, 'rate')

    def rent_block_url(self, obj):
        if not self.request.user.is_superuser:
            url = (
                "https://base2.of.ru/building/"
                f"{obj.building_id}/rent-block/{obj.rent_block_id}"
            )
            return format_html(
                '<a href="{url}" target="_blank">{id}</a>',
                url=url, id=obj.rent_block_id
            )
        return obj.rent_block_id

    formatted_rate.short_description = 'Цена аренды'
    rent_block_url.short_description = 'ID блока'


@admin.register(AdsForSum)
class AdsForSumAdmin(admin.ModelAdmin):

    def get_model_perms(self, request):
        if request.user.is_superuser:
            return super().get_model_perms(request)
        else:
            return {}


@admin.register(SummedAds)
class SummedAds(admin.ModelAdmin):
    inlines = (AdsForSumInline, )

    list_display = (
        'pk',
        'owner_id',
        'address',
        'formatted_rate',
        'area',
        'img',
        'status',
    )

    list_editable = ('status', )

    list_filter = (
        'resp_name',
        'status',
    )

    def get_list_filter(self, request: HttpRequest) -> Sequence[str]:
        if request.user.is_superuser \
                or request.user.groups.filter(name="moderator").exists():
            return super().get_list_filter(request)
        else:
            return []

    def get_fieldsets(self, request, obj):
        fieldsets = super().get_fieldsets(request, obj)
        if not request.user.is_superuser:
            self.readonly_fields = (
                'owner_id',
                'address',
                'area',
                'rate',
                'img',
                'rent_block_ids',
                'resp_id',
                'resp_name'
            )
        return fieldsets

    def formatted_rate(self, obj):
        return format_price(obj, 'rate')

    formatted_rate.short_description = 'Стоимость'
