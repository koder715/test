import asyncio
from aiohttp import web
from aiogram import Bot
from aiogram.types import BotCommand
from aiogram.webhook.aiohttp_server import (
    SimpleRequestHandler, setup_application
)
from aiogram_dialog import setup_dialogs
from aiogram.filters import ExceptionTypeFilter
from aiogram_dialog.api.exceptions import UnknownIntent, UnknownState

import tgbot.config.config as cg
from tgbot.handlers.main_handler import main_router
from tgbot.launch_server import handle_webhook
from tgbot.handlers.error__handler import (
    on_unknown_intent,
    on_unknown_state
)


bot = cg.bot
dp = cg.dp


async def register_routers():
    dp.include_router(
        main_router
    )
    dp.errors.register(
        on_unknown_intent,
        ExceptionTypeFilter(UnknownIntent)
    )

    dp.errors.register(
        on_unknown_state,
        ExceptionTypeFilter(UnknownState),
    )

    setup_dialogs(dp)


async def set_bot_commands():
    await bot.set_my_commands(
        [
            BotCommand(command="/start", description="Запустить бота"),
        ]
    )


async def on_startup(bot: Bot):
    await register_routers()

    await set_bot_commands()

    if cg.RUNNING_MODE == cg.RunningMode.WEBHOOK:
        await bot.set_webhook(
            f"{cg.WEBHOOK_URL}{cg.WEBHOOK_PATH}",
            drop_pending_updates=True
        )
        print("Вебхук установлен!")


async def run_polling():
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


def run_webhook() -> None:
    app = web.Application()
    app.router.add_head('/cian_webhook', handle_webhook)
    app.router.add_post('/cian_webhook', handle_webhook)

    webhook_requests_handler = SimpleRequestHandler(
        dispatcher=dp,
        bot=bot,
    )
    webhook_requests_handler.register(app, path=cg.WEBHOOK_PATH)
    setup_application(app, dp, bot=bot)

    web.run_app(app, host=cg.WEB_SERVER_HOST, port=cg.WEB_SERVER_PORT)


def init_bot():
    dp.startup.register(on_startup)

    if cg.RUNNING_MODE == cg.RunningMode.LONG_POLLING:
        asyncio.run(run_polling())
    elif cg.RUNNING_MODE == cg.RunningMode.WEBHOOK:
        run_webhook()
    else:
        raise RuntimeError(f"Unknown running mode: {cg.RUNNING_MODE}")
