from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.filters.command import Command
from aiogram.types import Message, CallbackQuery
from aiogram_dialog import DialogManager, StartMode

from tgbot.config.use_case import CORE_USE_CASE
import tgbot.windows.dialog_windows as dw


main_router = Router()
main_router.include_routers(
    dw.dialog_marketing,
    dw.dialog_brokers,
    dw.common_dialog
)


@main_router.message(Command("start"))
async def cmd_start(
    message: Message, state: FSMContext, dialog_manager: DialogManager
):
    """Обработка команды /start."""

    await state.clear()

    if message.from_user is None:
        return

    tg_user = await CORE_USE_CASE.register_bot_user(
        user_id=message.from_user.id,
        chat_id=message.chat.id,
        username=message.from_user.username,
    )

    if tg_user is None:
        await message.answer("You don't have perms to the bot!")

    await dialog_manager.start(
        dw.CommonState.greeting_menu, mode=StartMode.RESET_STACK
    )


@main_router.callback_query(F.data.startswith("answer_notification"))
async def answer_notification(
    callback: CallbackQuery, dialog_manager: DialogManager, state: FSMContext
):
    """Обработка уведомлений."""
    await state.clear()

    await dialog_manager.start(
        dw.MarketingStates.check_notification, mode=StartMode.RESET_STACK,
        data=callback.data.split('_')[-1]
    )
