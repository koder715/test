import logging
from aiogram_dialog import (
    DialogManager,
    ShowMode,
    StartMode
)

from tgbot.windows.states.all_states import CommonState


async def on_unknown_intent(event, dialog_manager: DialogManager):
    """Хендлер обработки ошибки unknown_intent."""

    logging.error("Restarting dialog: %s", event.exception)
    await dialog_manager.start(
        CommonState.greeting_menu,
        mode=StartMode.RESET_STACK,
        show_mode=ShowMode.SEND,
    )


async def on_unknown_state(event, dialog_manager: DialogManager):
    """Хендлер обработки ошибки unknown_state."""

    logging.error("Restarting dialog: %s", event.exception)
    await dialog_manager.start(
        CommonState.greeting_menu,
        mode=StartMode.RESET_STACK,
        show_mode=ShowMode.SEND,
    )
