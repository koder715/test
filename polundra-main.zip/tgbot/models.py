from django.db import models
from django.contrib.auth import get_user_model


User = get_user_model()


class TGUser(models.Model):
    id = models.BigIntegerField(
        primary_key=True,
        verbose_name="Telegram User ID"
    )
    chat_id = models.BigIntegerField(verbose_name="Telegram Chat ID")
    username = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        verbose_name="Poloondra Username"
    )

    objects: models.manager.BaseManager["TGUser"]

    class Meta:
        db_table = "tg_user"
        verbose_name = "Пользователь ТГ"
        verbose_name_plural = "Пользователи ТГ"


class EndedChats(models.Model):
    chat_id = models.CharField(
        verbose_name="Id чата",
        max_length=256,
    )

    def __str__(self) -> str:
        return self.chat_id

    class Meta:
        verbose_name = "Зактрытый чат"
        verbose_name_plural = "Закрытые чаты"
