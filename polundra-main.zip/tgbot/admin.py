from django.contrib import admin
from .models import TGUser, EndedChats


@admin.register(TGUser)
class TGUserAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'chat_id',
        'username'
    )


@admin.register(EndedChats)
class EndedChatsAdmin(admin.ModelAdmin):
    list_display = (
        'chat_id',
    )
