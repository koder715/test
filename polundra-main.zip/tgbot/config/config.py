import os
from enum import Enum
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.redis import RedisStorage, DefaultKeyBuilder

from interface.settings import CELERY_BROKER_URL


class RunningMode(str, Enum):
    """Установка режима работы бота."""
    LONG_POLLING = "LONG_POLLING"
    WEBHOOK = "WEBHOOK"


def get_running_mode():
    """Получение работы бота."""
    running_mode_str = os.environ.get("RUNNING_MODE", "LONG_POLLING")
    print(running_mode_str)
    return RunningMode(running_mode_str)


RUNNING_MODE = get_running_mode()
TG_TOKEN = os.environ.get("TG_TOKEN", "")
WEBHOOK_URL = os.environ.get("WEBHOOK_URL", "")
WEBHOOK_PATH = os.environ.get("WEBHOOK_PATH", "")
WEB_SERVER_HOST = os.environ.get("WEB_SERVER_HOST", "")
WEB_SERVER_PORT = int(os.environ.get("WEB_SERVER_PORT", "1"))

# конфигурация бота
bot = Bot(
    token=TG_TOKEN,
    parse_mode="HTML"
)

# устновка хранилища FSM
storage = RedisStorage.from_url(
    url=CELERY_BROKER_URL,
    key_builder=DefaultKeyBuilder(with_destiny=True)
)

# диспетчер
dp = Dispatcher(storage=storage)
