from typing import Final
from ..models import TGUser
from django.contrib.auth import get_user_model
from asgiref.sync import sync_to_async


User = get_user_model()


class CoreUseCase:
    @staticmethod
    async def register_bot_user(
        user_id: int,
        chat_id: int,
        username: str | None,
    ) -> TGUser | None:
        """
        Класс, производящий авторизацию пользователя и
        определения его прав доступа.
        """

        if username:
            try:
                custom_user = await User.objects.aget(first_name=username)
                tg_user, _ = await TGUser.objects.aget_or_create(
                    username=custom_user,
                    defaults={'id': user_id, 'chat_id': chat_id}
                )
                return tg_user
            except User.DoesNotExist:
                pass

        return None

    @staticmethod
    async def get_user_group(
        username: str | None
    ):
        user = await User.objects.aget(first_name=username)
        # user_group = await user.groups.alast()
        # return user_group.name
        return await sync_to_async(list)(user.groups.all())


CORE_USE_CASE: Final[CoreUseCase] = CoreUseCase()
