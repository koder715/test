from django.core.management.base import BaseCommand
from tgbot.launch_server import register_webhook, register_avito_webhook


class Command(BaseCommand):
    """Установка вебхука cian_api по команде."""

    help = 'Starts the aiohttp server.'

    def handle(self, *args, **options):
        register_webhook()
        register_avito_webhook()
