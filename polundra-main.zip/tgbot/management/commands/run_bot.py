from django.core.management.base import BaseCommand
from tgbot.bot_initialization import init_bot


class Command(BaseCommand):
    """Запуск бота по команде"""

    help = 'Starts the Telegram bot.'

    def handle(self, *args, **options):
        init_bot()
