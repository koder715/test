import requests
import json
import asyncio
import logging
from aiohttp import web
from aiogram.methods.send_message import SendMessage
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardButton
from asgiref.sync import sync_to_async

from interface.settings import CIAN_KEY
from tgbot.config.config import WEBHOOK_URL
from tgbot.models import TGUser
from tgbot.config.config import bot
from tgbot.windows.avito_api_methods import AVITO_API_METHODS
from tgbot.windows.cian_api_methods import CIAN_API_METHODS
from tgbot.templates.text_templates import template_greeting


logger = logging.getLogger(__name__)


async def handle_webhook(request):
    """Обработка telegram_webhook."""

    if request.method == 'HEAD':
        return web.Response()
    elif request.method == 'POST':
        try:
            data = await request.json()
            logger.info(
                "Webhook Data:\n"
                f"{data}"
            )

            await data_preparation(data)

            return web.Response(
                text="Webhook received and processed successfully"
            )
        except Exception as e:
            logger.error(f"Error processing webhook data: {e}")
            return web.Response(
                text=f"Error processing webhook data: {str(e)}",
                status=500
            )
    else:
        return web.Response(status=405, text="Method Not Allowed")


def register_webhook():
    """Метод, устнаваливающий вебхук cian_api."""

    HEADERS = {
        'Authorization': f'Bearer {CIAN_KEY}',
        "Content-Type": "application/json"
    }

    url = "https://public-api.cian.ru/v2/subscribe-webhooks"

    data = {
        "url": f"{WEBHOOK_URL}/cian_webhook",
        "webhookTypes": ["offersMessagesIncoming"]
    }

    response = requests.post(url, headers=HEADERS, json=data)
    logger.info(
        "Webhook установлен со статусом "
        f"{response}"
    )
    logger.info(
        "Request Response data:\n"
        f"{response.json()}"
    )

    return response


def register_avito_webhook():
    """Метод, устнаваливающий вебхук avito_api."""

    token = asyncio.run(AVITO_API_METHODS.get_access_token())
    logger.info(
        f"Получен токен авито {token}"
    )

    url = "https://api.avito.ru/messenger/v3/webhook"

    data = {
        "url": f"{WEBHOOK_URL}/cian_webhook",
    }

    # Преобразуем JSON-объект в строку
    data_json = json.dumps(data)

    response = requests.post(url, headers=token, data=data_json)
    logger.info(
        "Webhook установлен со статусом "
        f"{response}"
    )
    logger.info(
        "Request Response data:\n"
        f"{response.json()}"
    )

    return response


async def data_preparation(data):
    """Метод обрабатывает данные полученного вебхука."""
    # проверка на циан
    check = data.get("offers")
    title = None
    url = None
    market = None
    # если не None, то уведомление из циана
    if check:
        title = check[0].get("title", " ")
        url = check[0].get("url", " ")
        market = "cian"
        chat_id = data["chats"][0].get("chatId", "")
        # проверка на начало диалога
        # если в диалоге есть OF RU, то мы уже отвечали,
        # значит не нужен автоответ
        dialog = await CIAN_API_METHODS.get_all_messages(chat_id)
        is_first = False if 'OF RU' in dialog else True
        # если True, значит выполняем автоответ
        if is_first:
            message = data["chats"][0]["messages"][0]["content"].get(
                "text", ""
            )
            is_number = await CIAN_API_METHODS.check_for_number(message)
            if not is_number:
                # здесь вызываю метод с ответным сообщением
                text = await sync_to_async(template_greeting)(market)
                await CIAN_API_METHODS.send_api_message(chat_id, text)

    else:
        market = "avito"
        chat_id = data.get("payload").get("value").get("chat_id")
        title = await AVITO_API_METHODS.get_chat_title(chat_id)
        url = await AVITO_API_METHODS.get_offer_link(chat_id)

    if title and url:
        logger.info("Отправляю сообщение маркетологу")
        await send_notification(title, url, market)


async def send_notification(title, url, market):
    """Отправка уведомления маркетологу."""
    text = (
        f"Пришло новое сообщение!\n{title}\n"
        f"Ссылка: {url}"
    )

    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(
        text="Перейти в диалог",
        callback_data=f"answer_notification_{market}")
    )

    user = await TGUser.objects.aget(
        # заменить на env
        username__username="diana"
    )

    await bot(SendMessage(
        chat_id=user.chat_id, text=text,
        parse_mode="HTML",
        reply_markup=builder.as_markup(),
        disable_web_page_preview=True
    ))
