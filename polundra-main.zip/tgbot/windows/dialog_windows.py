from aiogram_dialog import Dialog

from tgbot.windows.states.all_states import (
    MarketingStates, BrokerStates, CommonState
)
import tgbot.windows.windows as w

# Диалог авторизации/Приветственное меню
common_dialog = Dialog(
    w.BASE_DIALOG_METHODS.get_start_window()
)

# Диалог для общения с клиентами
dialog_marketing = Dialog(
    w.BASE_DIALOG_METHODS.choose_market_window(),
    w.BASE_DIALOG_METHODS.check_main_menu(),
    w.BASE_DIALOG_METHODS.dialogs_list("unread"),
    w.BASE_DIALOG_METHODS.process_dialog("unread"),
    w.BASE_DIALOG_METHODS.dialogs_list("read"),
    w.BASE_DIALOG_METHODS.process_dialog("read"),
    w.BASE_DIALOG_METHODS.answer_menu(),
    w.BASE_DIALOG_METHODS.sent_message_menu(),
    w.BASE_DIALOG_METHODS.finished_dialog_menu(),
    w.BASE_DIALOG_METHODS.get_notification_dialog(),
)

# Диалог поиска тегов контактов
dialog_brokers = Dialog(
    w.main_menu_brokers,
    w.get_contact_window,
    w.cadastr_state_window,
    w.tags_window,
    w.error_tags_window,
    w.choose_input_window,
    w.input_data_window,
    w.successful_input_window,
    w.error_input_window,
    w.waiting_result_window,
)
