import re
import asyncio
from math import ceil
from aiogram_dialog.widgets.input.text import ManagedTextInput
from aiogram_dialog import DialogManager, StartMode
from typing import Any

from aiogram.types import CallbackQuery, Message

import tgbot.windows.chat_infos_1 as ci
from tgbot.windows.states.all_states import (
    MarketingStates, BrokerStates
)
import tgbot.templates.text_templates as tp
from tgbot.config.use_case import CORE_USE_CASE
from tgbot.windows.parsing_cadastr import CadastreNumbers

from .dialog_methods_utils import get_method_result


async def switch_to_main_menu(
    msg: Message, widget: Any,
    manager: DialogManager
):
    """Проверка пользователя и начало соответствующего диалога."""

    groups = await CORE_USE_CASE.get_user_group(
        username=msg.from_user.username
    )

    for group in groups:
        if group.name == "marketing":
            await manager.start(
                MarketingStates.choose_market,
                mode=StartMode.RESET_STACK
            )

        elif group.name == "sales":
            await manager.start(
                BrokerStates.main_menu,
                mode=StartMode.RESET_STACK
            )


async def on_market_selected(
    callback: CallbackQuery, widget: Any,
    dialog_manager: DialogManager,
):
    """Выбор площадки для чата."""
    # устнавливаем площадку
    dialog_manager.dialog_data['market'] = callback.data.split('_')[0]
    await dialog_manager.switch_to(MarketingStates.main_menu)


async def main_menu_window_data(dialog_manager: DialogManager, **kwargs):
    """getter главного меню с обработкой ошибочного статуса."""
    market = dialog_manager.dialog_data.get('market')

    # получаем данные
    acquired_data = await get_method_result(
        market, "count_unread"
    )

    # если int, значит статус 200
    condition = isinstance(acquired_data, int)

    return {
        "unread_count": f"({acquired_data})" if condition else "(0)",
        "success": True if condition else False,
        "failure": True if not condition else False
    }


async def dialogs_window_data(dialog_manager: DialogManager, **kwargs):
    """Данные для вывода кнопок непрочитанных диалогов."""
    dialog_type = dialog_manager.event.data.split("_")[1]

    # получаем диалоги
    dialogs = await get_method_result(
        dialog_manager.dialog_data.get('market'),
        "get_dialogs_list",
        True if dialog_type == "unread" else None
    )

    return {
        "dialogs": dialogs
    }


async def on_chat_selected(
    callback: CallbackQuery, widget: Any,
    manager: DialogManager, item_id: str
):
    """on_click функция для перехода в диалог."""
    market = manager.dialog_data.get("market")

    state_id = callback.data.split(':')[0]
    state = {
        's_unread_dialog': MarketingStates.select_unread,
        's_read_dialog': MarketingStates.select_read
    }

    # получаем диалог по его chat_id
    messages = await get_method_result(
        market,
        "get_all_messages",
        item_id
    )
    # передаем сообщения для рендера
    manager.dialog_data['messages'] = messages
    manager.dialog_data['chatId'] = item_id
    if messages:
        manager.dialog_data['offer_link'] = await get_method_result(
            market, "get_offer_link", item_id
        )
        manager.dialog_data['dialog_messages'] = messages
        await manager.switch_to(state[state_id])


async def on_chat_selected_getter(
    dialog_manager: DialogManager, **kwargs
):
    """getter для обработки отсутствующего по id диалогу."""
    messages = dialog_manager.dialog_data.get("messages", None)
    return {
        "broken": True if not messages else False,
        "operable": True if messages else False
    }


async def answer_message(
    callback: CallbackQuery, widget: Any,
    manager: DialogManager
):
    """on_click для ожидания текста сообщения от пользователя."""
    manager.dialog_data['type_answer'] = "Напечатайте текст сообщения"
    await manager.switch_to(MarketingStates.type_answer)


async def send_message(
    msg: Message, _: ManagedTextInput[str],
    manager: DialogManager, data: str
):
    """on_click для отправки сообщения клиенту."""
    chat_id = manager.dialog_data['chatId']
    # вызываем метод отправки сообщения
    await get_method_result(
        manager.dialog_data.get("market"),
        "send_api_message",
        chat_id,
        msg.text
    )
    # await ci.send_api_cian_message(chat_id, msg.text)
    manager.dialog_data['message_sent'] = "Ваше сообщение отправлено!"
    await manager.switch_to(MarketingStates.message_sent)


async def send_message_template(
    callback: CallbackQuery, widget: Any,
    manager: DialogManager
):
    """Функция для формирования шаблонных сообщений."""
    chat_id = manager.dialog_data['chatId']
    template_dict = {
        "greeting_answer": tp.template_greeting(
            manager.dialog_data.get('market')
        ),
        "delegate_answer": tp.template_delegate,
        "template_greeting_1": tp.template_greeting_1,
        "template_info": tp.template_info,
    }
    text_answer = template_dict.get(callback.data, "")
    # вызываем метод отправки сообщения
    await get_method_result(
        manager.dialog_data.get('market'),
        "send_api_message",
        chat_id,
        text_answer
    )
    manager.dialog_data['message_sent'] = "Ваше сообщение отправлено!"
    await manager.switch_to(MarketingStates.message_sent)


async def finisih_dialog(
    callback: CallbackQuery, widget: Any,
    manager: DialogManager
):
    """Функция завершения диалога."""
    chat_id = manager.dialog_data['chatId']
    # вызываем метод отправки сообщения
    await get_method_result(
        manager.dialog_data.get('market'),
        "mark_as_read_dialog",
        chat_id
    )
    await manager.switch_to(MarketingStates.dialog_finished)


async def notification_getter(dialog_manager: DialogManager, **kwargs) -> dict:
    """getter информации об уведомлении."""
    # получаем market
    market = dialog_manager.start_data

    # вызываем метод отправки сообщения
    chatId, offer_link, messages = await get_method_result(
        market,
        "data_for_notification",
    )

    # объявляем market для остальных функций
    dialog_manager.dialog_data['market'] = market
    dialog_manager.dialog_data['chatId'] = chatId

    condition = chatId and offer_link and messages

    return {
        "dialog_messages": messages,
        "offer_link": offer_link,
        "success": True if condition else False,
        "failure": True if not condition else False
    }


async def get_tags(
    msg: Message, _: ManagedTextInput[str],
    manager: DialogManager, data: str
):
    """Функция для получения тегов контакта."""

    if msg.text.isdigit() and len(msg.text) == 11:
        tags_amount, tags_string = await ci.getcontact('+' + msg.text)
        manager.dialog_data["tags_amount"] = tags_amount
        manager.dialog_data["tags_string"] = tags_string
        await manager.switch_to(BrokerStates.get_tags)
    else:
        await manager.switch_to(BrokerStates.error_tags)


async def choose_block_type(
    callback: CallbackQuery, widget: Any,
    manager: DialogManager
):
    block_type = callback.data.split(':')[0]
    manager.dialog_data['block_type'] = block_type
    print(block_type)
    await manager.switch_to(BrokerStates.choose_input_state)


async def block_type_getter(
    dialog_manager: DialogManager,
    **kwargs
):

    block_type = dialog_manager.dialog_data.get('block_type', None)

    address = dialog_manager.dialog_data.get('address_data', None)
    square = dialog_manager.dialog_data.get('square_data', None)
    floor = dialog_manager.dialog_data.get('floor_data', None)

    ready = False

    # Отображение кнопки "готово" при указании всех параметров
    if block_type == 'room':
        if address and square and floor:
            ready = True

    if block_type == 'building':
        if address and square:
            ready = True

    return {
        'type': True if block_type == 'room' else False,
        'address': address,
        'square': square,
        'floor': floor,
        'ready': ready
    }


async def choose_input_switcher(
    callback: CallbackQuery, widget: Any,
    manager: DialogManager
):
    window = callback.data.split(':')[0]
    manager.dialog_data['window'] = window
    await manager.switch_to(BrokerStates.input_state)


async def input_window_getter(
    dialog_manager: DialogManager,
    **kwargs
):
    window = dialog_manager.dialog_data.get('window', None)

    block_type = {
        'address': 'адрес объекта',
        'square': 'площадь объекта',
        'floor': 'этаж объекта',
    }

    return {
        'block_type': block_type.get(window, None),
    }


async def input_method(
    msg: Message, _: ManagedTextInput[str],
    manager: DialogManager, data: str
):
    # проверяем вводимые численные значения
    pattern = r'^\d+(.\d+)?$'

    block_type = manager.dialog_data.get('window', None)

    # Стандартизируем адрес
    if block_type == 'address':
        c = CadastreNumbers(address=data)
        data = await c.clean_address()

    # Сохраняем в словарь результаты
    manager.dialog_data[f'{block_type}_data'] = data

    if block_type == 'square' or block_type == 'floor':
        check = bool(re.match(pattern, data))
        if check:
            await manager.switch_to(BrokerStates.sussess_input_state)
        else:
            await manager.switch_to(BrokerStates.error_input_state)

    else:
        await manager.switch_to(BrokerStates.sussess_input_state)


async def after_input_getter(
    dialog_manager: DialogManager,
    **kwargs
):
    block_type = dialog_manager.dialog_data.get('window', None)
    input_data = dialog_manager.dialog_data.get(f'{block_type}_data', None)
    print(dialog_manager.dialog_data)

    return {
        'input_data': input_data
    }


async def find_cadastre_number(
    callback: CallbackQuery, widget: Any,
    manager: DialogManager
):
    user_id = callback.from_user.id
    address = manager.dialog_data.get('address_data', None)
    square = manager.dialog_data.get('square_data', None)
    square = square.replace(',', '.')
    floor = manager.dialog_data.get('floor_data', None)

    c = CadastreNumbers(
        address=address,
        square=square,
        floor=floor,
        user_id=user_id
    )

    tasks = await c.find_all_numbers()
    task_time = len(tasks) / 10 * 6
    task_time_min = ceil(task_time / 60)

    manager.dialog_data['task_time_min'] = int(task_time_min)

    asyncio.create_task(c.send_result())

    await manager.switch_to(BrokerStates.finish_search)
