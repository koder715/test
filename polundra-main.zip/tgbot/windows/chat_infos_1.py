import asyncio
import aiohttp
from asgiref.sync import sync_to_async
from interface.settings import CIAN_KEY, CONTACT_TOKEN
from tgbot.models import EndedChats


# шаблон заголовков
HEADERS = {
        "Authorization": f"Bearer {CIAN_KEY}",
        "Content-Type": "application/json"
    }


async def get_chats():
    """Метод получающий все действующие чаты."""
    timeout = aiohttp.ClientTimeout(total=10)

    url = "https://public-api.cian.ru/v1/get-chats"

    params = {
        'page': 1,
        'pageSize': 20,
    }

    async with aiohttp.ClientSession(timeout=timeout) as session:
        try:
            async with session.get(url, headers=HEADERS, params=params) \
                    as response:

                print(response.status)
                if response.status == 200:
                    data = await response.json()
                    return data.get("result", {}).get("chats", None)
                elif response.status == 500:
                    return None
                else:
                    print(f"Unexpected status code: {response.status}")
                    return None

        except asyncio.TimeoutError:
            print("Timeout")
            return None


async def get_dialogs_list(status):
    """Метод, получающий список диалогов."""
    data = await get_chats()
    amount = []

    if status == "unread":

        name = 'OF RU - коммерческая недвижимость'

        # проверка на завершенные диалоги
        ended_chats_obj = await sync_to_async(list)(EndedChats.objects.all())
        ended_chats = [chat.chat_id for chat in ended_chats_obj]

        # непрочитанный диалог == диалог, последнее сообщение в котором
        # написал пользователь, а не агентство
        amount = [
            (message['chatId'],
             message['offer']['id'],
             message['lastMessage']['createdAt']) for message
            in data
            if message['lastMessage'] is not None
            and message['lastMessage']['user']['name'] != name
            and message['chatId'] not in ended_chats
        ]

    else:
        # Все диалоги
        amount = [
            (message['chatId'],
             message['offer']['id'],
             message['lastMessage']['createdAt']) for message
            in data
            if message['lastMessage'] is not None
        ]

    # обработка случая, когда нет непрочитанных сообщений
    if amount:
        # сортировка, чтобы сообщения шли по убыванию времени
        sorted_amount = sorted(
            amount, key=lambda x: x[2], reverse=True
        )

        # извлекаем id объявлений для получения тайтлов
        offer_ids = [offer_id[1] for offer_id in sorted_amount]
        titles = await get_chat_title(offer_ids)

        # присваивание тайтлов соответствующим диалогам
        # иногда апи выдает некорректную информацию, теряет тайтлы
        for i in range(min(len(sorted_amount), len(titles))):
            sorted_amount[i] = (sorted_amount[i][0], titles[i])

        return sorted_amount


async def get_chat_title(offer_ids: list):
    """Метод, получающий тайтлы объявлений по id."""

    url = 'https://public-api.cian.ru/v1/get-my-offers-detail'

    params = {
        'offerIds': offer_ids
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=HEADERS, params=params) \
                as response:
            data = await response.json()

    titles_info = [
        (title['id'], title['title'].replace('\xa0', ' '))
        for title in data['result']['offers']
        if 'title' in title
    ]

    data_dict = {item[0]: item[1] for item in titles_info}

    titles = [(id, data_dict[id]) for id in offer_ids if id in data_dict]

    sorted_titles = [title[1] for title in titles]

    return sorted_titles


async def get_all_messages(chat_id):
    """Метод, получающий историю переписки по id диалога."""
    url = "https://public-api.cian.ru/v1/get-messages"

    params = {
        "page": 1,
        "pageSize": 100,
        "chat_id": chat_id,
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=HEADERS, params=params) \
                as response:
            data = await response.json()

    # иногда api теряет сообщения, делаем проверку 
    if data['result']['messages']:
        formatted_messages = [
            ("<b>OF RU:\n</b>"
             f"<i>{message['content']['text']}</i>"
             if message['userId'] == 6807296
             else f"Клиент:\n{message['content']['text']}")
            for message in data['result']['messages']
        ][::-1]

        result_string = '\n\n'.join(formatted_messages)

        return result_string

    else:
        return False


async def send_api_cian_message(chat_id, message):
    """Метод, осуществляющий отправку сообщения пользователю."""

    url = 'https://public-api.cian.ru/v1/send-message'

    data = {
        'chatId': chat_id,
        'content': {
            'text': message,
        }
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=HEADERS, json=data) as response:
            code = await response.status
            print(f"Сообщение {chat_id} отправлено со статусом {code}!")


async def get_offer_link(chat_id):
    """Метод получающий ссылку на объявление."""

    url = f"https://public-api.cian.ru/v1/get-chat?chatId={chat_id}"

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=HEADERS) as response:
            data = await response.json()

    return data['result']['chat']['offer']['url']


async def mark_as_read_dialog(chat_id):
    """Метод, завершающий диалог."""

    url = 'https://public-api.cian.ru/v1/read-chat'

    params = {
        'chatId': chat_id,
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=HEADERS, params=params)\
                as response:
            print(f"Диалог {chat_id} завершен со статусом {response.status}!")

    # добавляем диалог в завершенные, чтобы исключить из всех диалогов
    await EndedChats.objects.aget_or_create(
        chat_id=chat_id,
    )


async def data_for_notification():
    """Данные для показа уведомления."""

    last_chat = await get_chats()
    chatId = last_chat[0].get("chatId")
    offer_link = await get_offer_link(chatId)
    messages = await get_all_messages(chatId)

    return chatId, offer_link, messages


async def getcontact(phone_number):
    """Метод, осуществляющий поиски тегов по контакту."""

    url = 'https://biz-api.getcontact.com/v1.1/tag-view'
    headers = {
        'X-Business-Token': CONTACT_TOKEN,
        'Content-Type': 'application/json'
    }
    data = {
        'phoneNumber': phone_number
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, json=data) as response:
            print(response.status)
            data = await response.json()

    tags_amount = data.get('result', '').get('tagCount', '')
    tags_string = '\n'.join(data.get('result', '').get('tags', ''))

    return tags_amount, tags_string
