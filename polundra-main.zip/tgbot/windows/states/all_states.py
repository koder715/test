from aiogram.filters.state import State, StatesGroup


# FSM состояния
class CommonState(StatesGroup):
    greeting_menu = State()


class MarketingStates(StatesGroup):
    start = State()
    choose_market = State()
    main_menu = State()
    unread = State()
    select_unread = State()
    get_all = State()
    select_read = State()
    type_answer = State()
    message_sent = State()
    dialog_finished = State()
    check_notification = State()


class BrokerStates(StatesGroup):
    start = State()
    main_menu = State()
    contact_state = State()
    cadastr_state = State()
    get_tags = State()
    error_tags = State()
    choose_input_state = State()
    input_state = State()
    sussess_input_state = State()
    error_input_state = State()
    finish_search = State()
