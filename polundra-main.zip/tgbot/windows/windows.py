from typing import Final
from aiogram_dialog.widgets.kbd import (
    Button, SwitchTo,
    Column, Select, Group,
    Url, ScrollingGroup
)
from aiogram_dialog.widgets.text import Const, Format
from aiogram_dialog import Window

from aiogram_dialog.widgets.input.text import TextInput
import operator

import tgbot.windows.dialog_methods as dm
from tgbot.windows.states.all_states import (
    MarketingStates, BrokerStates, CommonState
)
import tgbot.templates.text_templates as txt


class BaseDialogWindows:
    """Базовый класс чатов на площадках."""
    def get_start_window(self):
        """Функция для перехода в окно главного меню."""
        # приветственное меню
        start_menu = Window(
            Format(text=txt.start_menu),
            Button(
                    Const("Главное меню"),
                    id="start_menu",
                    on_click=dm.switch_to_main_menu,
                ),
            state=CommonState.greeting_menu,
        )

        return start_menu

    def choose_market_window(self):
        """Функция вывода меню выбора площадки."""
        choose_market = Window(
            Format(text=txt.market),
            Button(
                Const("Циан"),
                id="cian_get_chats",
                on_click=dm.on_market_selected,
            ),
            Button(
                Const("Авито"),
                id="avito_get_chats",
                on_click=dm.on_market_selected,
            ),
            state=MarketingStates.choose_market,
        )

        return choose_market

    def check_main_menu(self):
        """Окно главного меню с проверкой на 500."""
        menu = Window(
            Const(text=txt.exception_menu, when="failure"),
            Const(text=txt.main_menu, when="success"),
            Column(
                SwitchTo(
                    Format("Непрочитанные{unread_count}"),
                    id="_unread_list", state=MarketingStates.unread,
                ),
                SwitchTo(
                    Const("Просмотреть диалоги"),
                    id="_all_list", state=MarketingStates.get_all,
                ),
                when="success"
            ),
            SwitchTo(
                Const("Попробовать снова"),
                id="exception",
                state=MarketingStates.main_menu,
                when="failure"
            ),
            state=MarketingStates.main_menu,
            getter=dm.main_menu_window_data,
        )

        return menu

    def dialogs_list(self, status):
        """Окно с списком диалогов."""
        status_dict = {
            "unread": {
                "select_id": "s_unread_dialog",
                "group_id": "scrolling_unread_dialogs",
                "state": MarketingStates.unread
            },
            "read": {
                "select_id": "s_read_dialog",
                "group_id": "scrolling_read_dialogs",
                "state": MarketingStates.get_all
            }
        }

        menu = Window(
            Const(text=txt.pagination_menu),
            ScrollingGroup(
                Select(
                    Format("{item[1]}"),
                    id=status_dict[status]["select_id"],
                    item_id_getter=operator.itemgetter(0),
                    items="dialogs",
                    on_click=dm.on_chat_selected
                ),
                id=status_dict[status]["group_id"],
                width=1,
                height=5
            ),
            SwitchTo(
                    Const("Назад"),
                    id="from_unread_to_main",
                    state=MarketingStates.main_menu
                ),
            getter=dm.dialogs_window_data,
            state=status_dict[status]["state"],
        )

        return menu

    def get_process_buttons(self, status):
        """Кнопки для окна взаимодействия с диалогом."""
        buttons = [
            Group(
                Button(
                    Const("Ответить на сообщение"),
                    id="answer_message",
                    on_click=dm.answer_message
                ),
                Url(
                    Const("Перейти в объявление"),
                    Format("{dialog_data[offer_link]}")
                ),
                Button(
                    Const("Завершить диалог"),
                    id="finish_dialog",
                    on_click=dm.finisih_dialog
                ),
                SwitchTo(
                    Const("Назад"),
                    id="back_to_dialogs",
                    state=status
                ),
                SwitchTo(
                    Const("В главное меню"),
                    id="to_main_menu",
                    state=MarketingStates.main_menu
                ),
                when="operable",
            ),
            SwitchTo(
                Const("Вернуться к списку диалогов"),
                id="back_to_dialogs",
                state=status,
                when="broken"
            )
        ]

        return buttons

    def process_dialog(self, status):
        """Окно взаимодействия с диалогом."""
        status_dict = {
            "unread": {
                "back_state": MarketingStates.unread,
                "main_state": MarketingStates.select_unread,
            },
            "read": {
                "back_state": MarketingStates.get_all,
                "main_state": MarketingStates.select_read,
            },
        }

        buttons = self.get_process_buttons(
            status_dict[status]["back_state"]
        )

        menu = Window(
            Format(
                "{dialog_data[dialog_messages]}",
                when="operable"
            ),
            Const(
                text=txt.dialog_exception,
                when="broken"
            ),
            *buttons,
            state=status_dict[status]["main_state"],
            getter=dm.on_chat_selected_getter
        )

        return menu

    def answer_menu(self):
        """Метод создания меню для ответа на сообщение."""
        type_answer = Window(
            Format("{dialog_data[type_answer]}"),
            Group(
                Button(
                    Const("Добрый день! Я - менеджер"),
                    id="greeting_answer",
                    on_click=dm.send_message_template
                ),
                Button(
                    Const("Специалист свяжется"),
                    id="delegate_answer",
                    on_click=dm.send_message_template
                ),
                Button(
                    Const("Здравствуйте! Специалист свяжется"),
                    id="template_greeting_1",
                    on_click=dm.send_message_template
                ),
                Button(
                    Const("Здравствуйте! Спасибо за информацию"),
                    id="template_info",
                    on_click=dm.send_message_template
                ),
                width=2
            ),
            SwitchTo(
                    Const("Назад"),
                    id="from_reply_input",
                    state=MarketingStates.unread
                ),
            SwitchTo(
                    Const("В главное меню"),
                    id="from_reply_to_main_menu",
                    state=MarketingStates.main_menu
                ),
            TextInput(id="send_answer", on_success=dm.send_message),
            state=MarketingStates.type_answer,
        )

        return type_answer

    def sent_message_menu(self):
        """Метод создания меню для отправленного сообщения."""
        message_sent = Window(
            Format("{dialog_data[message_sent]}"),
            SwitchTo(
                    Const("Вернуться в меню"),
                    id="to_main_menu",
                    state=MarketingStates.main_menu
                ),
            state=MarketingStates.message_sent
        )

        return message_sent

    def finished_dialog_menu(self):
        """Метод создания меню оконченного диалога."""
        dialog_finished = Window(
            Const("Вы завершили диалог!"),
            SwitchTo(
                    Const("Вернуться в меню"),
                    id="to_main_menu",
                    state=MarketingStates.main_menu
                ),
            state=MarketingStates.dialog_finished
        )

        return dialog_finished
    
    def get_notification_dialog(self):
        """Метод получает окно уведомления."""
        notification_dialog = Window(
            Format("{dialog_messages}"),
            Button(
                Const("Ответить на сообщение"),
                id="answer_unread",
                on_click=dm.answer_message,
                when="success"
            ),
            Url(
                Const("Перейти в объявление"),
                Format("{offer_link}"),
                when="success"
            ),
            Button(
                Const("Завершить диалог"),
                id="finish_dialog",
                on_click=dm.finisih_dialog,
                when="success"
            ),
            Button(
                Const("В главное меню"),
                id="to_main_menu",
                on_click=dm.switch_to_main_menu,
                when="success"
            ),
            SwitchTo(
                Const("Попробовать снова"),
                id="exception",
                state=MarketingStates.check_notification,
                when="failure"
            ),
            getter=dm.notification_getter,
            state=MarketingStates.check_notification,
        )

        return notification_dialog


# создание экземпляра BaseDialog
BASE_DIALOG_METHODS: Final[BaseDialogWindows] = BaseDialogWindows()

# меню для поиска тегов контакта
main_menu_brokers = Window(
    Const("Выберите пункты меню"),
    SwitchTo(
        Const("Найти теги контакта"),
        id="contact_tags", state=BrokerStates.contact_state
    ),
    SwitchTo(
        Const("Найти кадастровый номер"),
        id="find_cadastr", state=BrokerStates.cadastr_state
    ),
    state=BrokerStates.main_menu,
)

# ввод номера для поиска контактов
get_contact_window = Window(
    Const("Укажите номер телефона\n"
          "Укажите номер в формате <b>'79111111111'</b>\n"
          "<i>Без пробелов, скобок и спец символов (всего 11 цифр)</i>"),
    SwitchTo(Const("Назад"), id="to_main_menu", state=BrokerStates.main_menu),
    TextInput(id="get_tags", on_success=dm.get_tags),
    state=BrokerStates.contact_state,
)

# окно с найденными тегами
tags_window = Window(
    Format("{dialog_data[tags_string]}\n"
           "<b>Итого тегов: {dialog_data[tags_amount]}</b>\n"
           "Нажмите на кнопку назад, чтобы найти теги другого номера"),
    SwitchTo(Const("Назад"), id="to_main_menu", state=BrokerStates.main_menu),
    state=BrokerStates.get_tags
)

# окно с неверно указанным номером
error_tags_window = Window(
    Const("Неверно указан номер!\n"
          "Укажите номер в формате <b>'79111111111'</b>\n"
          "<i>Без пробелов, скобок и спец символов (всего 11 цифр)</i>"),
    SwitchTo(
            Const("Попробовать снова"),
            id="get_tags",
            state=BrokerStates.contact_state
        ),
    state=BrokerStates.error_tags
)

cadastr_state_window = Window(
    Const(
        text=(
            "Укажите <b>тип объекта</b>, "
            "кадастровый номер которого необходимо найти"
        )
    ),
    Button(
        Const(text="Помещение"),
        id="room",
        on_click=dm.choose_block_type
    ),
    Button(
        Const(text="Здание"),
        id="building",
        on_click=dm.choose_block_type
    ),
    SwitchTo(
        Const("Назад"),
        id="to_broker_mm",
        state=BrokerStates.main_menu
    ),
    state=BrokerStates.cadastr_state
)

choose_input_window = Window(
    Const(
        text=(
            "Выберите 1 из предложенных пунктов и укажите инфомрацию о нем\n"
            "Указанная вами информация отобразится в сообщении\n"
            "<i>Чтобы скорректировать указанную информацию, "
            "повторите операцию</i>\n"
            "<b>Когда будут указаны все данные, появится кнопка "
            "'Начать поиск'\n</b>"
        )
    ),
    Format(
        "<i>Адрес: {address}</i>",
        when='address'
    ),
    Format(
        "<i>Площадь: {square}</i>",
        when='square'
    ),
    Format(
        "<i>Этаж: {floor}</i>",
        when='floor'
    ),
    Button(
        Const("Указать адрес"),
        id="address",
        on_click=dm.choose_input_switcher
    ),
    Button(
        Const("Указать площадь"),
        id="square",
        on_click=dm.choose_input_switcher
    ),
    Button(
        Const("Указать этаж"),
        id='floor',
        on_click=dm.choose_input_switcher,
        when='type'
    ),
    Button(
        Const("Начать поиск"),
        id="data_done",
        on_click=dm.find_cadastre_number,
        when='ready'
    ),
    SwitchTo(
        Const("Назад"),
        id="to_cadastr_state",
        state=BrokerStates.cadastr_state
    ),
    getter=dm.block_type_getter,
    state=BrokerStates.choose_input_state
)

input_data_window = Window(
    Format(
        text=(
            "Укажите {block_type}\n"
            "Напишите ответным сообщением данные\n"
            "<i>Пример ввода для адреса: <b>'Пресненская набережная 12'</b> "
            "(адрес автоматически скорректируется)\n\n"
            "Пример ввода для площади: <b>'258.9'</b> "
            "(дробное число пишется через точку)\n\n"
            "Этаж указывается как <b>целое число</b></i>"
        )
    ),
    SwitchTo(
        Const("Назад"),
        id="to_choose_input",
        state=BrokerStates.choose_input_state
    ),
    TextInput(
        id="type_obj_info",
        on_success=dm.input_method
    ),
    getter=dm.input_window_getter,
    state=BrokerStates.input_state,
)

successful_input_window = Window(
    Format(
        'Вы указали <b>{input_data}</b>\n'
    ),
    SwitchTo(
        Const('Указать остальные парамеры'),
        id="go_to_choose_inp",
        state=BrokerStates.choose_input_state
    ),
    getter=dm.after_input_getter,
    state=BrokerStates.sussess_input_state
)

error_input_window = Window(
    Format(
        '<b>Неверный формат ввода\n</b>'
        'Вы указали {input_data}\n'
    ),
    SwitchTo(
        Const('Попробовать снова'),
        id="try_again_input",
        state=BrokerStates.input_state
    ),
    getter=dm.after_input_getter,
    state=BrokerStates.error_input_state
)

waiting_result_window = Window(
    Format(
        text=(
            'Время ожидания поиска составит примерно '
            '<i>{dialog_data[task_time_min]} min </i>\n'
            '<b>По окончании поиска, вам придет сообщение с результатом</b>'
        )
    ),
    state=BrokerStates.finish_search
)
