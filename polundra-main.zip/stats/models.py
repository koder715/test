from django.db import models


class CianLeads(models.Model):
    promotion_type = models.CharField(
        verbose_name="Тип продвижения",
        max_length=256,
    )
    leads_count = models.IntegerField(
        verbose_name="Лид без спама"
    )
    deals_count = models.IntegerField(
        verbose_name="Качественные"
    )
    median = models.IntegerField(
        verbose_name="Медиана"
    )
    mean = models.IntegerField(
        verbose_name="Средний чек"
    )
    total = models.BigIntegerField(
        verbose_name="Сумма комиссии"
    )
    cv = models.FloatField(
        verbose_name="CV лид",
        default=0
    )
    b_700 = models.IntegerField(
        verbose_name="до 700"
    )
    b_700_2000 = models.IntegerField(
        verbose_name="700-2000"
    )
    m_2000 = models.IntegerField(
        verbose_name="от 2 млн."
    )

    class Meta:
        verbose_name = "Roistat"
        verbose_name_plural = "Roistat"


class XmlParser(models.Model):
    multiple = models.CharField(
        verbose_name="Тип",
        max_length=256,
    )
    offer_type = models.CharField(
        verbose_name="Сделка"
    )
    promotion_type = models.CharField(
        verbose_name="Продвижение",
        max_length=256,
    )
    type_counts = models.IntegerField(
        verbose_name="К-во объявлений"
    )
    auction_sum = models.IntegerField(
        verbose_name="Сумма аукционов"
    )
    added = models.DateField(
        verbose_name="Дата бэкапа"
    )

    class Meta:
        verbose_name = "Бэкап фидов"
        verbose_name_plural = "Бэкапы фидов"
