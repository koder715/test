import pandas as pd
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views.generic import ListView
from .forms import RoistatForm
from .models import CianLeads

import stats.utils as ut


class RoistatView(ListView):
    report_form = RoistatForm
    report_model = CianLeads
    template_name = "roistat.html"

    def get(self, request):
        form = self.report_form()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.report_form(request.POST)
        if form.is_valid():
            start_date = form.cleaned_data['start_date']
            end_date = form.cleaned_data['end_date']
            table_name = form.cleaned_data['table_name'].split(', ')
            offer_type = table_name[0]
            multitude = table_name[-1]
            print(start_date, end_date)

            # очищаем предыдущие данные
            self.report_model.objects.all().delete()

            # получаем данные
            response = ut.make_request(start_date, end_date)
            deals_df = ut.get_deals_df(response, offer_type, multitude)
            leads_df = ut.get_leads_df(response, offer_type, multitude)
            summary_df = pd.merge(leads_df, deals_df, on='Тип продвижения', how='outer')
            summary_df = summary_df.fillna(0)

            for _, row in summary_df.iterrows():
                self.report_model.objects.get_or_create(
                    promotion_type=row["Тип продвижения"],
                    leads_count=int(row["Лид без спама"]),
                    deals_count=int(row["Количество сделок"]),
                    median=int(row["Медиана сделок"]),
                    mean=int(row["Средний чек"]),
                    total=int(row["Общая сумма сделок"]),
                    cv=(
                        int(row["Количество сделок"])/int(row["Лид без спама"])*100
                    ),
                    b_700=int(row['до 700']),
                    b_700_2000=int(row['700-2000']),
                    m_2000=int(row['от 2 млн.'])
                )

            report_url = reverse(
                f'admin:{self.report_model._meta.app_label}'
                f'_{self.report_model._meta.model_name}_changelist'
            )

            return redirect(report_url)

        return render(request, self.template_name, {'form': form})
