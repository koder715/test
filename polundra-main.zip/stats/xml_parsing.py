import os
import paramiko
import pandas as pd
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta

from .models import XmlParser
from interface.settings import (
    XMLHOST, XMLPASS, XMLUSER, REMOTE_PATH
)


def parse_data(file_name):
    data_list = []

    tree = ET.parse(file_name)
    root = tree.getroot()

    for item in root.findall('object'):

        offer = item.find('Category').text
        keywords = ['Rent', 'Sale']
        for key in keywords:
            index = offer.find(key)
            if index != -1:
                offer = key

        external_id = item.find('ExternalId').text
        promotion_type = item.find('PublishTerms/PromotionType').text
        auction = 0
        auc_elem = item.find('Auction/Bet')
        if auc_elem is not None:
            auction = pd.to_numeric(auc_elem.text, errors='coerce')

        data_list.append({
            'id': external_id,
            'Сделка': offer,
            'Тип продвижения': promotion_type,
            'Аукционы': auction
        })

    df = pd.DataFrame(data_list)

    type_counts_df = df.groupby(['Тип продвижения', 'Сделка']).agg({
        'id': 'count',
        'Аукционы': 'sum'
    }).reset_index()

    type_counts_df.columns = ['Тип продвижения', 'Сделка', 'Количество объявлений', 'Сумма аукционов']

    return type_counts_df


def download_xml(multiple):
    """Выгрузка XML и обработка данных."""
    transport = paramiko.Transport((XMLHOST, 22))
    transport.connect(username=XMLUSER, password=XMLPASS)

    start_date = datetime(2023, 10, 24)
    end_date = datetime.now()
    date_range = [
        start_date + timedelta(days=x)
        for x in range((end_date - start_date).days + 1)
    ]

    for date in date_range:
        try:
            sftp = paramiko.SFTPClient.from_transport(transport)

            local_path = 'local_file.xml'
            form_date = str(date.date()).split('-')
            date_for_path = form_date[1] + form_date[-1]
            current_year = end_date.year % 100
            remote_path = REMOTE_PATH + f"{current_year}{date_for_path}_{multiple}_feed.xml"
            print(remote_path)
            sftp.get(remote_path, local_path)

            type_counts_df = parse_data(local_path)

            m_type = ""
            if multiple == "0600":
                m_type = "Обычные"
            elif multiple == "0700_multi":
                m_type = "Мульти"

            for _, row in type_counts_df.iterrows():
                XmlParser.objects.get_or_create(
                    multiple=m_type,
                    offer_type=row['Сделка'],
                    promotion_type=row['Тип продвижения'],
                    type_counts=row['Количество объявлений'],
                    auction_sum=row['Сумма аукционов'],
                    added=date.date()
                )
            sftp.close()

            os.remove(local_path)

        except Exception:
            print(
                f'{date.date()} - выходной! Фид отсутствует\n'
            )
            pass

    transport.close()

    print("Добавление в БД завершено")
