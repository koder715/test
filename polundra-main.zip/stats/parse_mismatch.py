import requests
import re
import xml.etree.ElementTree as ET

from interface.settings import TG_XML, CHAT_ID_XML


SEND_URL = f'https://api.telegram.org/bot{TG_XML}/sendMessage'


class DefectiveAds:
    """Поиск бракованных объявлений."""
    param_dict = {
        "Циан": {
            "root": "object",
            "offer": "Description",
            "offer_type": "Category",
            "off_exp": r"Rent|Sale",
            "rent": "Аренда",
            "sale": "Продажа",
            "res": "ExternalId"
        },
        "Авито": {
            "root": "Ad",
            "offer": "Description",
            "offer_type": "OperationType",
            "Сдам": "Аренда",
            "Продам": "Продажа",
            "res": "Id"
        }
    }

    exp = r'(ID объекта - \d+|ID \d+)'

    def lost_ads(self, param):
        """Объявления, в тексте которых отсутствует ID."""
        xml = self.get_xml(self.url, param)
        external_ids = []
        for item in xml:
            offer = item.find(self.param_dict[param]["offer"]).text
            matches = re.findall(self.exp, offer)

            # проверка на мульти
            only_multi_element = item.find("OnlyMulti")

            if not matches:
                if (
                    param == "Циан" and only_multi_element.text == "false"
                ) or param != "Циан":
                    external_id = item.find(self.param_dict[param]["res"]).text
                    external_ids.append(external_id)

        msg = "Потеряшки"
        self.send_telegram_notif(external_ids, param, msg)

    def mismatch(self):
        """Метод выводит объявления, которые есть на одной площадке,
        но отсутствуют на другой."""
        cian_ids = self.get_ids(self.cian_url, self.cian)
        avito_ids = self.get_ids(self.avito_url, self.avito)
        cian_uniq = [f"{ad[-1]}: {ad[0]}" for ad
                     in cian_ids if ad not in avito_ids]
        avito_uniq = [f"{ad[-1]}: {ad[0]}" for ad
                      in avito_ids if ad not in cian_ids]
        self.check_multi_avito(avito_uniq, self.cian)

        msg = "Уникальные объявления"

        if cian_uniq:
            self.send_telegram_notif(cian_uniq, self.cian, msg)
        if avito_uniq:
            self.send_telegram_notif(avito_uniq, self.avito, msg)

    def check_multi_avito(self, data, param) -> None:
        xml = self.get_xml(self.cian_url, self.cian)
        ids = []
        to_remove = []
        for item in xml:
            offer = item.find(self.param_dict[param]["offer"]).text
            re_match = re.findall(self.exp, offer)

            if re_match:
                matches = re_match[0].split()[-1]
                ids.append(matches)

        for i in range(len(data) - 1, -1, -1):
            for j in range(len(ids)):
                if ids[j] in data[i]:
                    to_remove.append(data[i])

        for value in to_remove:
            data.remove(value)

    @classmethod
    def get_xml(cls, url, param):
        """Получение xml с данными."""
        response = requests.get(url)
        root = ET.fromstring(response.text)
        return root.findall(cls.param_dict[param]["root"])

    @classmethod
    def get_ids(cls, url, param):
        """Получение id объявлений."""
        xml = cls.get_xml(url, param)
        ids = []
        for item in xml:
            # проверка на мульти
            only_multi_element = item.find("OnlyMulti")

            offer = item.find(cls.param_dict[param]["offer"]).text
            re_match = re.findall(cls.exp, offer)

            if re_match:
                matches = re_match[0].split()[-1]
                type_item = item.find(cls.param_dict[param]["offer_type"]).text

                if "off_exp" in cls.param_dict[param]:
                    exp = cls.param_dict[param]["off_exp"]
                    type_item = re.findall(exp, type_item)[0].lower()
                offer_type = cls.param_dict[param][type_item]

                if (
                    param == "Циан" and only_multi_element.text == "false"
                ) or param != "Циан":
                    ids.append((matches, offer_type))

        return ids

    @classmethod
    def send_telegram_notif(cls, data, param, msg):
        """Отправка сообщения в телеграм."""
        unpacked = '\n'.join(data)
        text = (
            f"{msg} {param}:\n"
            f"{unpacked}"
        )

        for chat_id in CHAT_ID_XML.split(","):
            data = {
                'chat_id': chat_id,
                'text': text
            }
            print(chat_id)

            print(text)

            response = requests.post(SEND_URL, json=data)
            print(response.status_code)
