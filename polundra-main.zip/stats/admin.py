from django.contrib import admin
from .models import CianLeads, XmlParser


@admin.register(CianLeads)
class CianLeadsAdmin(admin.ModelAdmin):
    list_display = (
        'promotion_type',
        'leads_count',
        'formatted_cv',
        'deals_count',
        'format_mean',
        'format_median',
        'format_total',
        'b_700',
        'b_700_2000',
        'm_2000'
    )

    def format_total(self, obj):
        formatted_price = "{:,}".format(int(obj.total)).replace(",", " ")
        return formatted_price
    
    def format_mean(self, obj):
        formatted_price = "{:,}".format(int(obj.mean)).replace(",", " ")
        return formatted_price
    
    def format_median(self, obj):
        formatted_price = "{:,}".format(int(obj.median)).replace(",", " ")
        return formatted_price
    
    def formatted_cv(self, obj):
        return '{:.2f}'.format(obj.cv)

    format_total.short_description = 'Сумма комиссии'
    format_mean.short_description = 'Медиана'
    format_median.short_description = 'Средний чек'
    formatted_cv.short_description = 'CV Лид'

@admin.register(XmlParser)
class XmlParserAdmin(admin.ModelAdmin):
    list_display = (
        'offer_type',
        'promotion_type',
        'type_counts',
        'auction_sum',
        'added'
    )
