from django.urls import path
from .views import RoistatView

urlpatterns = [
    path('roistat_report/', RoistatView.as_view(), name='roistat_report'),
]
