from django import forms
from bootstrap_datepicker_plus.widgets import DatePickerInput


class RoistatForm(forms.Form):
    """Форма для статистики по продвижениям."""
    DEAL_TYPE_CHOICES = [
        ('аренда, простое', 'Аренда - простые'),
        ('аренда, мульти', 'Аренда - мульти'),
        ('продажа, простое', 'Продажа - простые'),
        ('продажа, мульти', 'Продажа - мульти'),
    ]

    start_date = forms.DateField(
        label='Начальная дата',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )
    end_date = forms.DateField(
        label='Конечная дата (+1 день)',
        widget=DatePickerInput(attrs={'placeholder': 'Выберите дату'}),
    )
    table_name = forms.ChoiceField(
        label='Тип сделки',
        choices=DEAL_TYPE_CHOICES,
        widget=forms.Select(attrs={'placeholder': 'Выберите тип сделки'}),
    )
