import requests
import pandas as pd
from interface.settings import KEY, PR_NUMBER


def make_request(start_date, end_date):
    """Составление запроса в roistat."""
    print(start_date, end_date)
    headers = {
        'Content-type': 'application/json',
        'Api-key': f'{KEY}',
    }

    params = {
        "project": f"{PR_NUMBER}",
        "limit": 100000000,
        "offset": 0
    }

    data = {
        'filters': {
            'and': [
                ['creation_date', '>', str(start_date)],
                ['creation_date', '<', str(end_date)]
            ]
        }
    }

    url = "https://cloud.roistat.com/api/v1/project/integration/order/list"

    response = requests.post(
        url, headers=headers, params=params, json=data).json()

    return response


def get_leads_df(response, offer_type, multitude):
    """Получение информации по небракованным лидам."""
    data_list = []

    for record in response['data']:
        if "cian" in record['roistat'].split('_') \
                and "(Лиды)" in record['status']['name'].split(' ') \
                and not any(item in record['status']['name'].split(' ') for item in ["Спам", "собственника"]) \
                and "Тип продвижения для Roistat" in record['custom_fields'] \
                and record['roistat'].split('_')[1] == offer_type \
                and record['roistat'].split('_')[2] == multitude:

            data_list.append({
                'id': record['id'],
                'Тип продвижения': record['custom_fields']['Тип продвижения для Roistat'],
                'offer': record['roistat'].split('_')[1],
                'multituded': record['roistat'].split('_')[2]
            })

        elif "cian" in record['roistat'].split('_') \
                and "(Сделки)" in record['status']['name'].split(' ') \
                and "Тип продвижения для Roistat" in record['custom_fields'] \
                and record['roistat'].split('_')[1] == offer_type \
                and record['roistat'].split('_')[2] == multitude:

            data_list.append({
                'id': record['id'],
                'Тип продвижения': record['custom_fields']['Тип продвижения для Roistat'],
                'offer': record['roistat'].split('_')[1],
                'multituded': record['roistat'].split('_')[2]
            })

    df = pd.DataFrame(data_list)
    type_counts_leads = df['Тип продвижения'].value_counts()
    leads_df = pd.DataFrame({
        'Тип продвижения': type_counts_leads.index,
        'Лид без спама': type_counts_leads.values
    })

    return leads_df


def get_deals_df(response, offer_type, multitude):
    """Получение информации по сделкам."""
    deals_data_list = []

    for record in response['data']:
        if "cian" in record['roistat'].split('_') \
                and "(Сделки)" in record['status']['name'].split(' ') \
                and "Тип продвижения для Roistat" in record['custom_fields'] \
                and record['roistat'].split('_')[1] == offer_type \
                and record['roistat'].split('_')[2] == multitude:

            deals_data_list.append({
                'id': record['id'],
                'revenue': record['revenue'],
                'Тип продвижения': record['custom_fields']['Тип продвижения для Roistat'],
                'offer': record['roistat'].split('_')[1],
                'multituded': record['roistat'].split('_')[2]
            })

    deals_df = pd.DataFrame(deals_data_list)

    type_counts_deals = deals_df['Тип продвижения'].value_counts()

    total_revenue_by_type = deals_df.groupby('Тип продвижения')['revenue'].sum()

    deals_summary_df = pd.DataFrame({
        'Тип продвижения': total_revenue_by_type.index,
        'Количество сделок': total_revenue_by_type.index.map(type_counts_deals.get),
        'Общая сумма сделок': total_revenue_by_type.values,
        'Средний чек': deals_df.groupby('Тип продвижения')['revenue'].mean().values,
        'Медиана сделок': deals_df.groupby('Тип продвижения')['revenue'].median().values,
        'до 700': deals_df.groupby('Тип продвижения')['revenue'].apply(lambda x: (x <= 700000).sum()).values,
        '700-2000': deals_df.groupby('Тип продвижения')['revenue'].apply(lambda x: ((700000 < x) & (x <= 2000000)).sum()).values,
        'от 2 млн.': deals_df.groupby('Тип продвижения')['revenue'].apply(lambda x: (x >= 2000000).sum()).values,
    })

    return deals_summary_df
