from django.db import models


class BaseModel(models.Model):
    block_id = models.IntegerField(
        verbose_name="Блок в БД",
        null=True,
        blank=True
    )
    building_id = models.IntegerField(
        verbose_name="Здание в БД",
        default=0,
    )
    address = models.CharField(
        verbose_name="Адрес",
        max_length=256
    )
    area_max = models.IntegerField(
        verbose_name="Площадь"
    )
    rate = models.IntegerField(
        verbose_name="Ставка"
    )
    price = models.BigIntegerField(
        verbose_name="Стоимость"
    )
    offer_type = models.CharField(
        max_length=30,
        verbose_name="Тип сделки",
        default="rent"
    )


class PrescriptionControl(BaseModel):

    resp_id = models.IntegerField(
        verbose_name="Отвественный в БД",
        null=True,
        blank=True
    )
    resp_name = models.CharField(
        verbose_name="Имя отвественного",
        max_length=100,
        null=True,
        blank=True
    )
    owner_id = models.BooleanField(
        verbose_name="Собственник",
        default=False
    )
    updated_at = models.DateField(
        verbose_name="Актуализация в БД",
        null=True,
        blank=True
    )
    days_from_actualisation = models.IntegerField(
        verbose_name="Дней с актуализации",
        null=True,
        blank=True
    )
    outdated = models.BooleanField(
        verbose_name="Актуально",
        default=False
    )

    class Meta:
        verbose_name = 'Контроль давности'
        verbose_name_plural = 'Контроль давности'


class NoPhotos(BaseModel):
    floor = models.IntegerField(
        default=0,
        verbose_name="Этаж"
    )
    block_type = models.CharField(
        max_length=50,
        verbose_name="Тип помещения",
        null=True,
        blank=True
    )
    is_full_building = models.BooleanField(
        verbose_name="Здание целиком"
    )
    priority = models.CharField(
        max_length=30,
        verbose_name="Приоритет"
    )

    class Meta:
        verbose_name = 'Блок без фото'
        verbose_name_plural = 'Блоки без фото'


class ForPost(BaseModel):
    market = models.CharField(
        verbose_name="Площадка",
        max_length=15
    )
    block_type = models.CharField(
        max_length=50,
        verbose_name="Тип помещения",
        null=True,
        blank=True
    )

    class Meta:
        verbose_name = 'Блок на выгрузку'
        verbose_name_plural = 'Блоки на выгрузку'


class BlackList(models.Model):
    block_id = models.IntegerField(
        verbose_name="Блок в БД",
        null=True,
        blank=True
    )
    model_name = models.CharField(
        max_length=50,
        verbose_name="Имя модели"
    )


class PhotosUpdated(models.Model):
    STATUS_CHOICES = [
        ('new', 'Новый'),
        ('created', 'Создан'),
    ]

    block_id = models.IntegerField(
        verbose_name="Блок в БД",
        null=True,
        blank=True,
    )
    building_id = models.IntegerField(
        verbose_name="Здание в БД",
        null=True,
        blank=True,
    )
    offer_type = models.CharField(
        verbose_name="Тип сделки",
        max_length=15,
    )
    image_id = models.IntegerField(
        verbose_name="Фото",
        null=True,
        blank=True,
    )
    updated_at = models.DateTimeField(
        verbose_name="Дата обновления",
        blank=True,
        null=True,
    )
    image_type = models.CharField(
        verbose_name='Тип фотографии',
        max_length=15,
        default='photo',
    )
    status = models.CharField(
        verbose_name="Статус",
        max_length=10,
        choices=STATUS_CHOICES,
        default='new',
    )

    class Meta:
        ordering = ['-updated_at']
        verbose_name = "Обновление фоток"
        verbose_name_plural = "Обновление фоток"


class OnlyMulti(BaseModel):
    floor = models.IntegerField(
        default=0,
        verbose_name="Этаж"
    )
    block_type = models.CharField(
        max_length=50,
        verbose_name="Тип помещения",
        null=True,
        blank=True
    )

    class Meta:
        verbose_name = 'Онли-мульти без фото'
        verbose_name_plural = 'Онли-мульти без фото'
        ordering = ['address', 'building_id']


class OnlyActive(BaseModel):
    is_available_block = models.IntegerField(
        verbose_name="Блок активен",
        default=0
    )
    is_export_block = models.IntegerField(
        verbose_name="Выгрузка активна",
        default=0
    )
    is_export_building = models.IntegerField(
        verbose_name="Выгрузка активна",
        default=0
    )
    priority = models.CharField(
        max_length=30,
        verbose_name="Приоритет"
    )

    class Meta:
        verbose_name = 'Активный блок'
        verbose_name_plural = 'Активные блоки'
