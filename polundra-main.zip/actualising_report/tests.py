from django.test import TestCase
from actualising_report.models import OnlyActive


class OnlyActiveTestCase(TestCase):
    """
    Класс тестирования правильной выгрузки объектов
    по активным блокам с выключенными галкам на выгрузку у здания и/или блока.
    """

    def test_is_export(self):
        # получаем все объекты и галки на полях выгрузки
        for obj in OnlyActive.objects.all():
            variants = [
                [1, 1, 0],
                [1, 0, 1],
                [1, 0, 0]
            ]
            if not any(
                obj.is_available_block == v[0]
                and obj.is_export_building == v[1]
                and obj.is_export_block == v[2] for v in variants
            ):
                self.fail('None of the variants passed the check')
