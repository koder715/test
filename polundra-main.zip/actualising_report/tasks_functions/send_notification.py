import requests
import logging
from typing import Union, Dict, Any
from datetime import datetime, timedelta
from collections import defaultdict
from django.db import connections
from mysql.connector import Error
from actualising_report.models import ForPost
from actualising_report.sql_tempates.templates import SQLTemplates
from interface.settings import CHAT_ID_XML, TG_XML
from tgbot.models import TGUser
from actualising_report.models import PrescriptionControl


logger = logging.getLogger(__name__)


def make_api_req(bot, data):
    url = f'https://api.telegram.org/bot{bot}/sendMessage'
    response = requests.post(url, json=data)
    logger.info(f"сообщение отправлено со статусом {response.status_code}!")


def send_telegram_notif():
    records = ForPost.objects.all()
    ids = [(i.block_id, i.offer_type) for i in records]

    grouped_data = defaultdict(list)
    for block_id, offer_type in ids:
        grouped_data[offer_type].append(block_id)

    result_string = 'БЛОКИ НА ВЫГРУЗКУ\n\n'
    for offer_type, block_ids in grouped_data.items():
        result_string += f'{offer_type}:\n'
        for block_id in block_ids:
            result_string += f'{block_id}\n'
        result_string += '\n'

    user = CHAT_ID_XML.split(',')[0]

    data = {
        'chat_id': user,
        'text': result_string
    }

    make_api_req(TG_XML, data)


def make_request_for_notif(cursor, param, **kwargs):
    """Метод выполняет запрос к БД."""
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    hour_ago = (
        datetime.now() - timedelta(hours=1)
    ).strftime('%Y-%m-%d %H:%M:%S')

    # получение шаблона запроса к БД
    temp = SQLTemplates(
        **kwargs
    )
    sql_q = temp.block_changes(param, hour_ago, now)
    cursor.execute(sql_q)
    rows = cursor.fetchall()

    return rows if rows else None


def check_changes(block_value, param, value) -> str:
    """Метод производит сравнение измененного блока."""
    change = block_value != value
    logger.info(f"OLD: {block_value} NEW {value}, PARAM: {param}")
    if change and all([isinstance(i, int) for i in [block_value, value]]):
        res_string = f"{param} ⬆️" if value > block_value \
            else f"{param} ⬇️"
        return f"{res_string} на {'{:,}'.format(abs(value - block_value)).replace(',', ' ')}"


def check_changes_message(block_id, money, area, offer_type) -> str:
    """Метод получает результат изменения блока по его id."""
    # получение блока
    blocks = PrescriptionControl.objects.filter(
        block_id=block_id, offer_type=offer_type
    )

    if blocks.exists():
        logger.info(f"ID: {block_id}")
        # проверка изменения цены
        block = blocks.first()
        money_change = check_changes(block.rate, "Ставка", money)
        if money_change:
            return money_change

        # проверка изменения площади
        area_change = check_changes(block.area_max, "Площадь", area)
        if area_change:
            return area_change


def get_param(event_type) -> str:
    """
    Функция определяет тип обновления блока.
    1 - блок создан.
    5, 6 - изменена цена/площадь.
    9 - на рынке.
    10 - не на рынке.
    """
    # идем в обратном порядке по списку,
    # какое обновление было последним, то и возвращаем
    if event_type:
        for event in reversed(event_type):
            if event == 1:
                return "created"
            if event == 9:
                return "on_market"
            if event == 10:
                return None


def format_result_message(
    block_id, **kwargs
) -> Union[str, None]:
    """Метод формирует сообщение для уведомления."""
    param = get_param(kwargs.get('event_type', False))
    money = kwargs.get('money')
    money = int(money) if money else None
    area = kwargs.get('area')
    offer_type = kwargs.get('offer_type')
    metro = kwargs.get('metro', 'не указано')
    price = None
    result_string = None

    if offer_type and money and area:
        price = money * area if \
            offer_type == 'sale' else \
            int((money * area) // 12)

    if param == "created" or param == "on_market":
        result_string = "➕"

    if result_string:
        result_string += (
            f"\n{'{:,}'.format(area).replace(',', ' ') if area else 'не указана'} м2\n"
            f"{'{:,}'.format(money).replace(',', ' ') if money else 'не указана'} руб/м2\n"
            f"{'{:,}'.format(price).replace(',', ' ') if price else 'не указана'} руб\n"
            f"<a href='https://base2.of.ru/api/v1/images/{kwargs.get('image_id')}/-actions/cian'>---</a>\n"
            f"м. {metro if metro else 'Не указано'}\n"
            f"{kwargs.get('address')}\n"
            "https://base2.of.ru/building/"
            f"{kwargs.get('building_id')}/"
            f"{kwargs.get('offer_type')}-block/{block_id}"
        )

    return result_string


def format_rows(rows, offer_type) -> Dict[int, Dict[str, Any]]:
    """
    Функция обрабатывающая результат SQL запроса.
    Заводим словарь с ключом по block_id, чтобы не дублировать
    сообщения в телеграм. event_type - используется set для проверки
    всех обновлений по блоку.
    """
    updated_rows = {}

    for (
        block_id, building_id,
        address, area, money,
        block_type,
        created_at, image_id,
        metro, event_type
    ) in rows:
        if block_id not in updated_rows:
            updated_rows[block_id] = {
                "building_id": building_id,
                "address": address,
                "area": area,
                "money": money,
                "block_type": block_type,
                "created_at": created_at,
                "image_id": image_id,
                "metro": metro,
                "offer_type": offer_type,
                "event_type": [event_type]
            }
        else:
            updated_rows[block_id]["event_type"].append(event_type)

    return updated_rows


def send_block_changes_notif(
    param,
    table_name, table_param,
    tg_key,
    money_gt=None, market=None
):
    """Метод отправляет изменения по блокам/созданные блоки."""
    # получение типа сделки
    offer_type = table_name.split('_')[0]
    try:
        # подключение к БД
        with connections['base'].cursor() as cursor:
            rows = make_request_for_notif(
                cursor, param,
                table_name=table_name,
                table_param=table_param,
                money_gt=money_gt,
                market=market
            )

            users = TGUser.objects.filter(username__groups__name__in=[
                "рассылка по объявлениям"
            ])

            if rows:
                # вызов функции
                data = format_rows(rows, offer_type)

                logger.info(data)

                for key, value in data.items():
                    result_string = format_result_message(
                        block_id=key,
                        **value
                    )

                    if result_string:
                        logger.info(f"Успешно составил сообщение по блоку {key}!")

                        for user in users:
                            data = {
                                'chat_id': user.chat_id,
                                'text': result_string,
                                'parse_mode': 'HTML'
                            }
                            logger.info(
                                f"Отправка уведомления {user.username}!"
                            )

                            make_api_req(tg_key, data)

                    else:
                        logger.warning(
                            f"Не составил сообщение по блоку {key}"
                        )

    # обработка возможного исключения
    except Error as e:
        logger.error(f"Ошибка при подключении к БД {e}")


def send_notif_for_swap(tg_key, name):
    """Функция отправляет сообщение о смене ботов."""
    text = (
        "Данный бот больше не обслуживается, перейдите"
        f" по ссылке https://t.me/{name} и стартаните бота."
    )

    users = TGUser.objects.filter(username__groups__name__in=[
        "рассылка по объявлениям"
    ])

    for user in users:
        data = {
            'chat_id': user.chat_id,
            'text': text,
            'parse_mode': 'HTML'
        }
        logger.info(
            f"Отправка уведомления {user.username}!"
        )

        make_api_req(tg_key, data)
