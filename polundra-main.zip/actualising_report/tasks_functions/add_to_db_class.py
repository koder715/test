import logging
from typing import Union
from django.db.utils import DataError
from actualising_report.models import BlackList

from actualising_report.models import (
    ForPost, PrescriptionControl,
    NoPhotos, OnlyMulti
)


logger = logging.getLogger(__name__)


class AddToDb:
    """Класс добавления данных в БД."""

    def __init__(
        self, model_class: Union[
            ForPost, PrescriptionControl,
            NoPhotos, OnlyMulti
        ],
        update_field: str, update_offer_type: str,
        *args, **kwargs
    ) -> None:
        self.model_class = model_class
        self.update_field = update_field
        self.update_offer_type = update_offer_type
        self.defaults = kwargs

    def add_to_db(self, market: str = None):
        """Метод добавляющий данные."""

        update_field_value = self.defaults.pop(self.update_field, None)
        update_offer_type_value = self.defaults.pop(
            self.update_offer_type, None
        )
        # проверка на черный список
        model_class_name = self.model_class.__name__
        black_list_obj = BlackList.objects.filter(
            block_id=update_field_value,
            model_name=model_class_name
        )
        if black_list_obj:
            logger.info(
                f"Объект {update_field_value} в черном списке!"
            )
            return None

        try:
            # логика добавления данных для модели ForPost
            # для избегания дублей и сложения значения рынков
            if update_field_value is not None:
                obj = self.model_class.objects.filter(
                    **{self.update_field: update_field_value},
                    **{self.update_offer_type: update_offer_type_value}).first()
                if obj and market:
                    markets = obj.market.split(', ')
                    if market not in markets:
                        obj.market = f"{obj.market}, {market}"
                        obj.save()
                        logger.info(
                            "Значение поля market для объекта "
                            f"{update_field_value} обновлено в БД!"
                        )
                    self.defaults.pop('market', None)
                    self.update_fields(
                        update_field_value,
                        update_offer_type_value
                    )
                else:
                    self.update_fields(
                        update_field_value,
                        update_offer_type_value
                    )

        except DataError:
            logger.error(f"Ошибка при создании объекта {update_field_value}!")

    def update_fields(
        self, update_field_value: Union[int, None],
        update_offer_type_value: str
    ):
        """Метод, сохраняющий или обновляющий данные."""

        obj, created = self.model_class.objects.update_or_create(
            **{self.update_field: update_field_value},
            **{self.update_offer_type: update_offer_type_value},
            defaults=self.defaults
        )
        if created:
            logger.info(
                f"Объект {update_field_value} "
                f"{update_offer_type_value} создан в БД!"
            )
        else:
            logger.info(f"Объект {update_field_value} обновлен в БД!")
