import logging
from actualising_report.models import BlackList
from django.db import connections
from .cases import case1, case2, case3, case4


logger = logging.getLogger(__name__)


class BlackListTask:
    def __init__(
        self, table_name, param,
        market
    ) -> None:
        self.table_name = table_name
        self.param = param
        self.market = market

    def sql_template(self, block_id):
        temp = f"""
            SELECT tb.id, cb.is_available,
            b.is_export_markets, cb.is_export_markets,
            fe.is_active
            FROM {self.table_name} as tb
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN {self.market}_{self.param}_block as mpb ON tb.id = mpb.{self.param}_block_id
            INNER JOIN {self.market}_feed_elements as mfe ON mpb.{self.market}_feed_element_id = mfe.id
            INNER JOIN feed_elements as fe ON mfe.feed_element_id = fe.id
            WHERE (
                ({case1})
                OR ({case2})
                OR ({case3})
                OR ({case4})
            )
            AND tb.id = {block_id}
        """

        return temp

    def clear_blacklist(self, cursor):
        objs = BlackList.objects.filter(
            model_name="ForPost"
        )
        for obj in objs:
            block_id = obj.block_id
            sql_t = self.sql_template(block_id)
            cursor.execute(sql_t)
            row = cursor.fetchone()

            if row:
                logger.info(
                    f"Блок {block_id} удален из BlackList!"
                )
                obj.delete()
            else:
                logger.info(
                    f"У блока {block_id} нет изменений по галкам!"
                )

    def create_connection(self):
        with connections['base'].cursor() as cursor:
            self.clear_blacklist(cursor)
