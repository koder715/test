case1 = """
    b.is_export_markets = 1 AND cb.is_export_markets = 1 AND
    cb.is_available = 1 AND fe.is_active = 0
"""

case2 = """
    b.is_export_markets = 1 AND cb.is_export_markets = 1 AND
    cb.is_available = 0 AND fe.is_active = 1
"""

case3 = """
    b.is_export_markets = 1 AND cb.is_export_markets = 0 AND
    cb.is_available = 1 AND fe.is_active = 1
"""

case4 = """
    b.is_export_markets = 0 AND cb.is_export_markets = 1 AND
    cb.is_available = 1 AND fe.is_active = 1
"""
