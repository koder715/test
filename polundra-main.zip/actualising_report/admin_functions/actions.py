import logging
from django.contrib import admin
from actualising_report.models import BlackList


logger = logging.getLogger('default')


@admin.action(description="Добавить в черный список")
def black_list_func(
    modeladmin, request,
    queryset
):
    model_name = modeladmin.__dict__['model'].__name__
    for q in queryset:
        obj, created = BlackList.objects.get_or_create(
            block_id=q.block_id,
            model_name=model_name
        )

        if created:
            logger.info(f"{obj.block_id} добавлен в черный список!")

    queryset.delete()
