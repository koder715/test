import logging
from django.utils.timezone import make_aware
from mysql.connector import connect, Error
from interface.settings import (
    OFHOST, OFDATABASE, OFPASS, OFUSER
)

from actualising_report.models import PhotosUpdated


logger = logging.getLogger('default')


class UpdatedPhotosReport:
    def __init__(self, table_name) -> None:
        self.table_name = table_name
        self.offer_type = self.table_name.split('_')[0]

    def sql_template(self):
        temp = f"""
            SELECT tb.id, cb.building_id,
                img.image_id, img.updated_at,
                img.image_type
            FROM {self.table_name} as tb
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN (
                SELECT common_block_id, image_id, MAX(updated_at) AS max_updated_at
                FROM common_block_images
                GROUP BY common_block_id, image_id
            ) AS latest_images ON tb.common_block_id = latest_images.common_block_id
            INNER JOIN common_block_images AS img ON latest_images.image_id = img.image_id AND latest_images.max_updated_at = img.updated_at
            WHERE img.updated_at IS NOT NULL
            AND b.is_export_markets = 1
            AND cb.is_export_markets = 1
            AND cb.is_available = 1
        """

        return temp

    def make_req(self):
        try:
            with connect(
                host=OFHOST,
                database=OFDATABASE,
                user=OFUSER,
                password=OFPASS,
            ) as connection:
                with connection.cursor(buffered=True) as cursor:
                    temp = self.sql_template()
                    cursor.execute(temp)

                    rows = cursor.fetchall()

                    base_dict = [
                        {
                            'block_id': row[0],
                            'building_id': row[1],
                            'offer_type': "Аренда" if self.offer_type == 'rent' else "Продажа",
                            'image_id': row[2],
                            'updated_at': make_aware(row[3]),
                            'image_type': row[-1]
                        }
                        for row in rows
                    ]

                    return base_dict

        except Error as ex:
            logger.error(f"Возникла ошибка {ex} запросе к БД!")

    def add_to_db(self):
        data = self.make_req()

        for item in data:
            obj, created = PhotosUpdated.objects.update_or_create(
                block_id=item['block_id'],
                defaults={
                    'building_id': item['building_id'],
                    'offer_type': item['offer_type'],
                    'image_id': item['image_id'],
                    'updated_at': item['updated_at'],
                    'image_type': item['image_type']
                }
            )

            if created:
                logger.info(
                    f"Обект {obj.block_id} создан в БД!"
                )
