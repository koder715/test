from django.apps import AppConfig


class ActualisingReportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'actualising_report'
    verbose_name = 'Отчеты Актуализации'
