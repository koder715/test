from typing import Union


class SQLTemplates:
    coworking_seq = "AND tb.is_coworking = 0"

    def __init__(
        self, table_name: str, table_param: str,
        money_gt: Union[int, None], market: Union[str, None]
    ) -> None:
        self.table_name = table_name
        self.table_param = table_param
        self.money_gt = money_gt
        self.offer_type = self.table_name.split('_')[0]
        self.market = market
        self.divide = 12 if self.offer_type == "rent" else 1
        self.coworking = self.coworking_seq \
            if self.offer_type == "rent" else ';'

    def prescription_temp(self) -> str:
        temp = f"""
            SELECT tb.id, b.id,
                b.address_full, cb.max_area,
                m.value, b.broker_id,
                CONCAT(rbs.first_name, ' ', rbs.last_name) AS full_name,
                cb.owner_id,
                GREATEST(cb.created_at, act.max_created_at) AS max_created_at
            FROM {self.table_name} as tb
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN money AS m ON tb.{self.table_param} = m.id
            INNER JOIN responsible_brokers as rbs ON b.broker_id = rbs.user_id
            INNER JOIN (
                SELECT common_block_id, MAX(created_at) AS max_created_at
                FROM actualizations
                GROUP BY common_block_id
            ) AS act ON cb.id = act.common_block_id
        """

        return temp

    def no_photo_temp(self) -> str:
        temp = f"""
            SELECT tb.id, b.id,
                b.address_full, cb.max_area,
                m.value, ft.name, bl.name, cb.is_full_building,
                b.priority_type_id
            FROM {self.table_name} as tb
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN money AS m ON tb.{self.table_param} = m.id
            INNER JOIN common_block_floor_type AS cft ON cb.id = cft.common_block_id
            INNER JOIN floor_types AS ft ON cft.floor_type_id = ft.id
            INNER JOIN block_types as bl ON cb.block_type_id = bl.id
            LEFT JOIN  (
                SELECT common_block_id, COUNT(common_block_id) AS VALUE
                    FROM common_block_images
                    WHERE common_block_images.image_type IN ('photo')
                    GROUP BY common_block_id
            ) AS img ON cb.id = img.common_block_id
            WHERE img.VALUE is NULL
            AND b.is_export_markets = 1
            AND cb.is_export_markets = 1
            AND cb.is_available = 1
            AND m.value * cb.max_area / {self.divide} > {self.money_gt}
            {self.coworking}
        """

        return temp

    def for_post_temp(self) -> str:
        temp = f"""
            SELECT tb.id, b.id,
                b.address_full, cb.max_area,
                m.value, img.VALUE, bl.name
            FROM {self.table_name} as tb
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN money AS m ON tb.{self.table_param} = m.id
            INNER JOIN {self.market}_{self.offer_type}_block as market ON tb.id = market.{self.offer_type}_block_id
            INNER JOIN {self.market}_feed_elements as mfe ON market.{self.market}_feed_element_id = mfe.id
            INNER JOIN block_types as bl ON cb.block_type_id = bl.id
            INNER JOIN feed_elements as fe on mfe.feed_element_id = fe.id
            LEFT JOIN  (
                SELECT common_block_id, COUNT(common_block_id) AS VALUE
                    FROM common_block_images
                    WHERE common_block_images.image_type IN ('photo')
                    GROUP BY common_block_id
            ) AS img ON cb.id = img.common_block_id
            WHERE b.is_export_markets = 1
            AND img.VALUE IS NOT NULL
            AND cb.is_export_markets = 1
            AND cb.is_available = 1
            AND bl.name NOT IN ('склад', 'ПСН')
            AND m.value * cb.max_area / {self.divide} > {self.money_gt}
            AND fe.is_active = 0
            {self.coworking}
        """

        return temp

    def for_post_not_active_temp(self) -> str:
        temp = f"""
            SELECT tb.id, b.id,
                b.address_full, cb.max_area,
                m.value, img.VALUE, bl.name
            FROM {self.table_name} as tb
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN block_types as bl ON cb.block_type_id = bl.id
            INNER JOIN money AS m ON tb.{self.table_param} = m.id
            LEFT JOIN  (
                SELECT common_block_id, COUNT(common_block_id) AS VALUE
                    FROM common_block_images
                    WHERE common_block_images.image_type IN ('photo')
                    GROUP BY common_block_id
            ) AS img ON cb.id = img.common_block_id
            WHERE b.is_export_markets = 1
            AND NOT EXISTS (
                SELECT 1
                FROM {self.market}_{self.offer_type}_block as market
                WHERE tb.id = market.{self.offer_type}_block_id
            )
            AND img.VALUE IS NOT NULL
            AND cb.is_export_markets = 1
            AND cb.is_available = 1
            AND bl.name NOT IN ('склад', 'ритейл')
            AND m.value * cb.max_area / {self.divide} > {self.money_gt}
            {self.coworking}
        """

        return temp

    def only_multi_temp(self) -> str:
        temp = f"""
            SELECT tb.id, b.id,
                b.address_full, cb.max_area,
                m.value, ft.name, bl.name
            FROM {self.table_name} as tb
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN money AS m ON tb.{self.table_param} = m.id
            INNER JOIN common_block_floor_type AS cft ON cb.id = cft.common_block_id
            INNER JOIN floor_types AS ft ON cft.floor_type_id = ft.id
            INNER JOIN block_types AS bl ON cb.block_type_id = bl.id
            INNER JOIN cian_rent_block AS crb ON tb.id = crb.rent_block_id
            INNER JOIN cian_feed_elements AS cfe ON crb.cian_feed_element_id = cfe.id
            LEFT JOIN  (
                SELECT common_block_id, COUNT(common_block_id) AS VALUE
                    FROM common_block_images
                    WHERE common_block_images.image_type IN ('photo')
                    GROUP BY common_block_id
            ) AS img ON cb.id = img.common_block_id
            WHERE img.VALUE is NULL
            AND b.is_export_markets = 1
            AND cb.is_export_markets = 1
            AND cb.is_available = 1
            AND cb.is_full_building = 0
            AND cfe.only_multi = 0
            AND m.value * cb.max_area / {self.divide} > {self.money_gt}
            {self.coworking}
        """

        return temp

    def only_active_temp(self) -> str:
        """"Метод создает шаблон запроса для происка активных блоков."""
        temp = f"""
            SELECT tb.id, b.id,
                b.address_full, cb.max_area,
                m.value, ft.name, bl.name,
                cb.is_available, b.is_export_markets, cb.is_export_markets,
                b.priority_type_id
            FROM {self.table_name} as tb
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN money AS m ON tb.{self.table_param} = m.id
            INNER JOIN common_block_floor_type AS cft ON cb.id = cft.common_block_id
            INNER JOIN floor_types AS ft ON cft.floor_type_id = ft.id
            INNER JOIN block_types AS bl ON cb.block_type_id = bl.id
            WHERE (
                (b.is_export_markets = 1 AND cb.is_export_markets = 0)
                OR (b.is_export_markets = 0 AND cb.is_export_markets = 1)
                OR (b.is_export_markets = 0 AND cb.is_export_markets = 0)
            )
            AND cb.is_available = 1
            AND m.value * cb.max_area / {self.divide} > {self.money_gt}
            {self.coworking}
        """

        return temp

    def block_changes(self, param, hour_ago, now) -> str:
        """Шаблон запроса для получения только созданных объектов."""
        offer_type = self.table_name.split("_")[0]
        updates_table_name = f'updated_{offer_type}_blocks'

        temp = f"""
            SELECT tb.id, b.id,
                b.address_full, cb.max_area,
                m.value, bl.name,
                tb.{param}, (
                    SELECT bi.image_id
                    FROM building_image AS bi
                    WHERE bi.building_id = b.id
                    AND bi.sort_order >= 0
                    ORDER BY bi.sort_order ASC
                    LIMIT 1
                ) as image_id, (
                    SELECT metr.name
                    FROM building_metro AS bm
                    LEFT JOIN metros AS metr ON metr.id = bm.metro_id
                    WHERE bm.building_id = b.id
                    ORDER BY metr.id ASC
                    LIMIT 1
                ) as metro_name, upd.update_event_type_id
            FROM {updates_table_name} as upd
            INNER JOIN {self.table_name} as tb ON upd.{offer_type}_block_id = tb.id
            INNER JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            INNER JOIN buildings as b ON cb.building_id = b.id
            INNER JOIN money AS m ON tb.{self.table_param} = m.id
            INNER JOIN block_types AS bl ON cb.block_type_id = bl.id
            WHERE upd.{param} BETWEEN '{hour_ago}' AND '{now}'
        """

        return temp
