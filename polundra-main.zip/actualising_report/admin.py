from typing import List
from django.contrib import admin
from rangefilter.filters import (
    NumericRangeFilterBuilder,
    DateRangeFilterBuilder
)
from django.utils.html import format_html

from .models import (
    PrescriptionControl, NoPhotos,
    ForPost, BlackList, PhotosUpdated,
    OnlyMulti, OnlyActive
)
from .admin_functions.actions import black_list_func
from admin_funcs.formats import format_price, form_block_id


class BaseAdmin(admin.ModelAdmin):
    list_display: List[str] = [
        'building_id',
        'url_block_id',
        'address',
        'area_max',
        'format_rate',
        'format_price',
        'offer_type',
    ]

    list_filter: List[str] = [
        "offer_type",
        ("price", NumericRangeFilterBuilder()),
        ("rate", NumericRangeFilterBuilder()),
        ("area_max", NumericRangeFilterBuilder()),
    ]

    def url_block_id(self, obj):
        return form_block_id(obj)

    def format_price(self, obj):
        return format_price(obj, 'price')

    def format_rate(self, obj):
        return format_price(obj, 'rate')

    url_block_id.short_description = 'Блок в БД'
    format_price.short_description = 'Стоимость'
    format_rate.short_description = 'Ставка'

    url_block_id.admin_order_field = 'block_id'
    format_price.admin_order_field = 'price'
    format_rate.admin_order_field = 'rate'

    url_block_id.allow_tags = True
    format_price.allow_tags = True
    format_rate.allow_tags = True


@admin.register(PrescriptionControl)
class PrescriptionControlAdmin(BaseAdmin):
    list_display_ = BaseAdmin.list_display.copy()
    list_display_[2] = 'colored_address'
    list_display_ = list_display_ + [
        'resp_name',
        'owner_id',
        'updated_at',
        'days_from_actualisation',
        'outdated',
    ]
    list_display = list_display_

    list_filter = BaseAdmin.list_filter + [
        ("days_from_actualisation", NumericRangeFilterBuilder()),
        ("updated_at", DateRangeFilterBuilder()),
        'resp_name',
    ]

    search_fields = (
        'block_id',
    )

    def colored_address(self, obj):
        if not obj.outdated:
            return format_html(
                '<span style="color: red;">{}</span>', obj.address
            )
        else:
            return obj.address

    colored_address.short_description = 'Адрес'
    colored_address.admin_order_field = 'address'
    colored_address.allow_tags = True


@admin.register(NoPhotos)
class NoPhotosAdmin(BaseAdmin):
    list_display = BaseAdmin.list_display + [
        'floor',
        'block_type',
        'is_full_building',
        'priority'
    ]
    list_filter = BaseAdmin.list_filter + [
        'priority'
    ]

    actions = [black_list_func]


@admin.register(OnlyMulti)
class OnlyMultiAdmin(BaseAdmin):
    list_display = BaseAdmin.list_display + [
        'floor',
        'block_type',
    ]

    list_filter = BaseAdmin.list_filter[1:]


@admin.register(ForPost)
class ForPostAdmin(BaseAdmin):
    list_display = BaseAdmin.list_display + [
        'market',
    ]

    list_filter = BaseAdmin.list_filter + [
        "market",
    ]

    actions = [black_list_func]


@admin.register(OnlyActive)
class OnlyActiveAdmin(BaseAdmin):
    actions = [black_list_func]
    list_display = BaseAdmin.list_display + [
        "priority"
    ]
    list_filter = BaseAdmin.list_filter + [
        "priority",
    ]


@admin.register(BlackList)
class BlackListAdmin(admin.ModelAdmin):
    list_display = (
        'pk',
        'block_id',
        'model_name',
    )


@admin.register(PhotosUpdated)
class PhotosUpdatedAdmin(admin.ModelAdmin):
    list_display = (
        'pk',
        'url_block_id',
        'offer_type',
        'image_id',
        'image_type',
        'updated_at',
        'status'
    )

    list_filter = (
        'offer_type',
    )

    list_editable = (
        'status',
    )

    def url_block_id(self, obj):
        return form_block_id(obj)

    url_block_id.short_description = 'Блок в БД'
    url_block_id.admin_order_field = 'block_id'
    url_block_id.allow_tags = True
