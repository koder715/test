import os
import pickle
import logging
from datetime import datetime
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


logger = logging.getLogger(__name__)

# Определение областей доступа
SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly']


class TrackChanges:

    def __init__(self, m_key, obj_id) -> None:
        self.service = self.authenticate_google_drive()
        self.method = self.get_method(m_key)
        self.obj_id = obj_id

    def get_method(self, m_key):
        methods = {
            'folder': self.get_latest_modification,
            'file': self.get_sheet_last_modified_time,
        }

        return methods.get(m_key)

    def authenticate_google_drive(self):
        creds = None

        # Загружаем токен, если он уже существует
        if os.path.exists('token.pickle'):
            with open('token.pickle', 'rb') as token:
                creds = pickle.load(token)

        # Если токена нет или он недействителен,
        # инициируем новый процесс авторизации
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(
                    'credentials.json', SCOPES)
                creds = flow.run_local_server(port=0)

            # Сохраняем токен для последующего использования
            with open('token.pickle', 'wb') as token:
                pickle.dump(creds, token)

        return build('drive', 'v3', credentials=creds)

    def get_latest_modification(self, folder_id=None):
        if folder_id is None:
            folder_id = self.obj_id

        latest_time = None

        query = f"'{folder_id}' in parents and trashed = false"

        results = self.service.files().list(
            q=query, fields="files(id, name, mimeType, modifiedTime)"
        ).execute()

        files = results.get('files', [])

        if not files:
            logger.error("Папка пуста или нет доступа.")
            return None

        for file in files:
            file_modified_time = datetime.fromisoformat(
                file['modifiedTime'].replace('Z', '+00:00')
            )

            if latest_time is None or file_modified_time > latest_time:
                latest_time = file_modified_time

            if file['mimeType'] == 'application/vnd.google-apps.folder':
                # Рекурсивно проверяем содержимое папки
                subfolder_latest_time = self.get_latest_modification(
                    file['id']
                )

                if latest_time is None or (
                    subfolder_latest_time and
                    subfolder_latest_time > latest_time
                ):
                    latest_time = subfolder_latest_time

        return latest_time

    def get_sheet_last_modified_time(self):
        try:
            file = self.service.files().get(
                fileId=self.obj_id, fields='id, name, modifiedTime'
            ).execute()

            recent_time = datetime.strptime(
                file['modifiedTime'], "%Y-%m-%dT%H:%M:%S.%fZ"
            )
            return recent_time

        except HttpError:
            logger.info(
                f'Ошибка доступа к файлу {self.obj_id}!'
            )
            return None
