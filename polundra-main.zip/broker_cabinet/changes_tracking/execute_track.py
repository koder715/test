import logging
from .track import TrackChanges
from .selenium_track import YaTracker
from broker_cabinet.models import BrokerCabinet


logger = logging.getLogger(__name__)


class Execute:

    def define_instance(self, string: str, file_id: str):
        if 'yandex' in string:
            return YaTracker(file_id)

        if 'google' in string:
            if 'spreadsheets' in string or 'file' in string:
                return TrackChanges('file', file_id)
            else:
                return TrackChanges('folder', file_id)

    def execute(self):
        objects = BrokerCabinet.objects.all()
        for obj in objects:
            instance = self.define_instance(
                obj.url, obj.file_id.strip()
            )

            updated_at = instance.method()

            BrokerCabinet.objects.filter(pk=obj.pk).update(
                updated_at=updated_at
            )

            obj.refresh_from_db()

            logger.info(
                f'Обновил поля у {obj.pk}'
            )
