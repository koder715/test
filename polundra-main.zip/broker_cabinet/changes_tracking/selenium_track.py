from time import sleep
from typing import List
from datetime import datetime
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.firefox.options import Options


class ProcessData:
    def __init__(self, repo_id) -> None:
        self.repo_id = repo_id

    def get_page(self, driver: webdriver.Remote, url=None):
        url = f'https://disk.yandex.ru/d/{self.repo_id}'

        driver.get(url)

    def extract_data(self, page_source):
        last_date = None

        soup = BeautifulSoup(page_source, 'html.parser')

        dates = soup.find_all(
            'div',
            class_='listing-item__column listing-item__column_date'
        )

        if dates:
            last_date = (
                max(
                    datetime.strptime(date.text, "%d.%m.%Y").date()
                    for date in dates
                )
            )

        return last_date


class ClickElements:
    def find_clickable_folders(self, source):
        soup = BeautifulSoup(source, 'html.parser')
        click_names: List[BeautifulSoup] = soup.find_all(
            'div',
            class_=(
                'listing-item listing-item_theme_row listing-item_size_m '
                'listing-item_type_dir js-prevent-deselect'
            )
        )

        return [
            elem.find(
                'div',
                class_='listing-item__title listing-item__title_overflow_clamp'
            )['aria-label'] for elem in click_names
        ]

    def is_element_in_viewport(self, element, driver: webdriver.Remote) -> bool:
        # Этот JavaScript код проверяет, находится ли элемент в пределах видимой области (viewport)
        return driver.execute_script("""
            var rect = arguments[0].getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        """, element)

    def click_folder(self, folder_name, driver: webdriver.Remote):
        # Ожидание, пока элемент с нужным aria-label станет кликабельным
        element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable(
                (
                    By.CSS_SELECTOR,
                    f"div[aria-label='{folder_name}']"
                )
            )
        )

        # Проверка, находится ли элемент в пределах видимой области
        if not self.is_element_in_viewport(element, driver):
            driver.execute_script("arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", element)
            sleep(1)

        actions = ActionChains(driver)
        actions.double_click(element).perform()

        sleep(1)

    def call_back(self, driver: webdriver.Remote):
        driver.back()


class YaTracker(ClickElements, ProcessData):
    folder_dict = {}

    def __init__(self, repo_id) -> None:
        super().__init__(repo_id)
        self.method = self.start_selenium

    def get_browser_options(self):
        browser_options = Options()
        browser_options.set_capability("browserVersion", "124.0")
        browser_options.set_capability(
            "selenoid:options", {
                "enableVNC": True,
                "enableVideo": False
            }
        )

        browser_options.add_argument("--no-sandbox")
        browser_options.add_argument("--disable-gpu")
        browser_options.add_argument("--start-maximized")

        return browser_options

    def process_folders(self, driver: webdriver.Remote, max_date=None):
        page_source = driver.page_source
        folders = self.find_clickable_folders(page_source)

        if folders:
            for folder in folders:
                self.click_folder(folder, driver)
                current_date = self.process_folders(driver, max_date)
                self.call_back(driver)

                if current_date \
                        and (max_date is None or current_date > max_date):
                    max_date = current_date

        else:
            current_folder_date = self.extract_data(page_source)

            if current_folder_date \
                    and (max_date is None or current_folder_date > max_date):
                max_date = current_folder_date

        return max_date

    def start_selenium(self):
        browser_options = self.get_browser_options()

        with webdriver.Remote(
            command_executor='http://selenoid:4444/wd/hub',
            options=browser_options
        ) as driver:

            self.get_page(driver)

            max_date = self.process_folders(driver)

            return max_date
