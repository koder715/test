import logging
import pandas as pd

from broker_cabinet.models import Owners, BrokerCabinet


logger = logging.getLogger(__name__)


def get_data():
    file_path = 'cabinets.xlsx'
    df = pd.read_excel(file_path)

    data = df.to_dict('records')

    return data


def upload_owners_data():
    # Загрузка данных из Excel-файла
    data = get_data()

    for row in data:
        obj, created = Owners.objects.get_or_create(
            owner_id=row['ID собственника'],
            defaults={
                "owner_name": row['Назвние собственника в битрикс']
            }
        )

        if created:
            logger.info(
                f'Создал собственника {obj}'
            )

    logger.info(
        'Закончил добавление собственников кабинета в БД!'
    )


def upload_cabinets_data():
    data = get_data()

    for row in data:
        url = row['Ссылка на диск/кабинет брокера']
        file_id = url.split('/')[-1]
        obj, created = BrokerCabinet.objects.get_or_create(
            url=url,
            defaults={
                "owner": Owners.objects.get(
                    owner_id=row['ID собственника']
                ),
                "file_id": file_id
            }
        )

        if created:
            logger.info(
                f'Создал новый кабинет брокера {obj}'
            )

    logger.info(
        'Закончил добавление кабинетов брокера!'
    )
