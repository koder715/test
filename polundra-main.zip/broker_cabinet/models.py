from django.db import models


class Owners(models.Model):
    owner_id = models.IntegerField(
        verbose_name="ID собственника",
        default=0
    )
    owner_name = models.CharField(
        max_length=255,
        verbose_name="Название собственника",
        default=None
    )

    def __str__(self) -> str:
        return self.owner_name


class BrokerCabinet(models.Model):
    owner = models.ForeignKey(
        Owners,
        on_delete=models.CASCADE,
        related_name="owners",
        verbose_name="Собственник"
    )
    object_name = models.CharField(
        max_length=255,
        verbose_name="Название файла/папки",
        default=None,
        null=True
    )
    file_id = models.CharField(
        max_length=255,
        verbose_name="ID файла/папки",
        default=None,
        null=True
    )
    url = models.URLField(
        verbose_name="Ссылка на кабинет"
    )
    updated_at = models.DateField(
        verbose_name="Последнее обновление",
        null=True,
        default=None
    )

    def __str__(self) -> str:
        return self.object_name if self.object_name \
            else self.owner.owner_name
