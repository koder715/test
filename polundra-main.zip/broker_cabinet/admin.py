from django.contrib import admin
from django.utils.html import format_html
from broker_cabinet.models import Owners, BrokerCabinet


# Register your models here.
@admin.register(Owners)
class OwnersAdmin(admin.ModelAdmin):
    list_display = (
        'owner_id',
        'owner_name'
    )


@admin.register(BrokerCabinet)
class BrokerCabinetAdmin(admin.ModelAdmin):
    list_display = (
        'owner',
        'form_url',
        'updated_at'
    )

    def form_url(self, obj):
        return format_html(
            '<a href="{url}" target="_blank">ссылка</a>',
            url=obj.url
        )
