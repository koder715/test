from django.apps import AppConfig


class BrokerCabinetConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'broker_cabinet'
    verbose_name = 'Кабинеты брокера'
