from django.contrib import admin
from django.contrib.contenttypes.admin import GenericTabularInline
from django.utils.html import format_html
from more_admin_filters import MultiSelectFilter
from rangefilter.filters import (
    DateRangeFilterBuilder, NumericRangeFilterBuilder
)

from interface.settings import AGENCY_NAME
from .admin_functions.val import statuses_kim
from .for_tasks.resp_ids import other_state, assist_state
from .admin_functions.copy_text import copy_to_clipboard
from .models import (
    Status, Comments,
    BlackList, ProxyMyBlocks,
    ProxyAssistBlocks, ProxyDiffRespBr,
    ProxyNewData, ProxyMyBlocksRentavik,
    ProxyNewDataRentavik
)
from admin_funcs.formats import (
    form_cian_id, form_building_id, format_price,
    form_rentavik_id, exclude_rentavik_ads,
    only_rentavik_ads, form_block_id
)


@admin.register(BlackList)
class BlackListAdmin(admin.ModelAdmin):
    list_display = ('pk', 'address', 'added')


@admin.register(Status)
class StatusAdmin(admin.ModelAdmin):
    list_display = ('pk', 'name', )

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        if not request.user.is_superuser:
            if not request.user.groups.filter(name="kim").exists():
                queryset = queryset.exclude(name="Фейк-обработан")
            if request.user.groups.filter(name="kim").exists():
                statuses = statuses_kim
                queryset = queryset.filter(name__in=statuses)

        return queryset


@admin.register(Comments)
class CommentsAdmin(admin.ModelAdmin):
    list_display = ('pk', 'text', 'pub_date', )

    def get_model_perms(self, request):
        if request.user.is_superuser:
            return super().get_model_perms(request)
        else:
            return {}


class CommentsInline(GenericTabularInline):
    model = Comments
    extra = 1
    readonly_fields = ('pub_date', )

    def get_formset(self, request, obj=None, **kwargs):
        formset = super().get_formset(request, obj, **kwargs)
        formset.form.base_fields['author'].initial = request.user
        if not request.user.is_superuser:
            formset.form.base_fields['author'].disabled = True
        return formset


class CustomStatusFilter(admin.SimpleListFilter):
    title = 'Статус'
    parameter_name = 'status'

    def lookups(self, request, model_admin):
        if request.user.is_superuser:
            all_statuses = Status.objects.values_list('name', flat=True)
            return [(status, status) for status in all_statuses]
        elif request.user.groups.filter(name="kim").exists():
            allowed_statuses = statuses_kim
            return [(status, status) for status in allowed_statuses]
        elif not request.user.is_superuser:
            all_statuses = Status.objects.values_list(
                'name', flat=True).exclude(name='Фейк-обработан')
            return [(status, status) for status in all_statuses]

    def queryset(self, request, queryset):
        value = self.value()
        if value:
            return queryset.filter(status__name=value)
        else:
            return queryset


class BaseNewDataAdmin(admin.ModelAdmin):
    list_display = (
        'pk',
        'url_cian_id',
        'url_building_id',
        'offer_type',
        'block_type',
        'area_max',
        'format_price',
        'format_total_price',
        'floor',
        'address',
        'agency_name',
        'status',
        'added'
    )

    list_editable = ('status', )

    search_fields = ('address', )

    def format_price(self, obj):
        return format_price(obj, 'rate')

    def url_building_id(self, obj):
        return form_building_id(obj)

    def url_cian_id(self, obj):
        return form_cian_id(obj)

    def format_total_price(self, obj):
        return format_price(obj, 'total_price')

    list_filter = (
        "offer_type",
        "status",
        ("block_type", MultiSelectFilter),
        ("rate", NumericRangeFilterBuilder()),
        ("total_price", NumericRangeFilterBuilder()),
        ("area_max", NumericRangeFilterBuilder()),
        ("floor", NumericRangeFilterBuilder()),
        ('added', DateRangeFilterBuilder()),
    )

    url_cian_id.short_description = 'id в Циан'
    format_price.short_description = 'Ставка'
    url_building_id.short_description = 'Здание в БД'
    format_total_price.short_description = 'Полная цена'


class BaseCompetitiveAdmin(BaseNewDataAdmin):
    list_display = (
        'pk',
        'url_block_id',
        'url_building_id',
        'offer_type',
        'updated_at',
        'owner_count',
        'url_cian_id',
        'area_max',
        'format_price',
        'format_total_price',
        'address',
        'floor',
        'colored_agency_name',
        'status',
        'status_update',
        'comments_count',
        'added',
        'building_priority'
    )

    list_filter = (
        'offer_type',
        CustomStatusFilter,
        ('added', DateRangeFilterBuilder()),
        ("rate", NumericRangeFilterBuilder()),
        ("total_price", NumericRangeFilterBuilder()),
        ("area_max", NumericRangeFilterBuilder()),
        'broker_name',
        'building_priority'
    )

    actions = [copy_to_clipboard]

    inlines = [
        CommentsInline,
    ]

    def get_fieldsets(self, request, obj):
        if request.user.is_superuser:
            fieldsets = super().get_fieldsets(request, obj)
        else:
            fieldsets = (
                ('Отвественный', {'fields': ('broker_id', 'broker_name')}),
                ('Дата добавления блока на Циане', {
                    'fields': ('cian_created',)
                })
            )
            self.readonly_fields = ('broker_id', 'broker_name', 'cian_created')
        return fieldsets

    def colored_agency_name(self, obj):
        if any(r.strip() == AGENCY_NAME for r in obj.agency_name.split(',')):
            return format_html(
                '<span style="color: red;">{}</span>',
                obj.agency_name
            )
        else:
            return format_html(
                '<span style="color: white;">{}</span>',
                obj.agency_name
            )

    def comments_count(self, obj):
        count = obj.comments.all().count()
        if count:
            return format_html('<span style="color:green;">&#x2713;</span>')
        else:
            return format_html('<span style="color:red;">&#x2717;</span>')

    def url_block_id(self, obj):
        return form_block_id(obj)

    url_block_id.short_description = 'Блок в БД'
    comments_count.short_description = 'Комментарий'
    colored_agency_name.short_description = 'Агентство'


@admin.register(ProxyMyBlocks)
class ProxyMyBlocksAdmin(BaseCompetitiveAdmin):
    def get_queryset(self, request):
        queryset = super().get_queryset(request)

        queryset = exclude_rentavik_ads(queryset, request, resp_id=True)

        return queryset


@admin.register(ProxyAssistBlocks)
class ProxyAssistBlocksAdmin(BaseCompetitiveAdmin):
    def get_queryset(self, request):
        queryset = super().get_queryset(request)

        queryset = exclude_rentavik_ads(queryset, request, assist_state)

        return queryset


@admin.register(ProxyDiffRespBr)
class ProxyDiffRespBrAdmin(BaseCompetitiveAdmin):
    def get_queryset(self, request):
        queryset = super().get_queryset(request)

        queryset = exclude_rentavik_ads(queryset, request, other_state)

        return queryset


@admin.register(ProxyNewData)
class ProxyNewDataAdmin(BaseNewDataAdmin):
    def get_queryset(self, request):
        queryset = super().get_queryset(request)

        queryset = exclude_rentavik_ads(queryset, request)

        return queryset


@admin.register(ProxyMyBlocksRentavik)
class ProxyMyBlocksRentavikAdmin(BaseCompetitiveAdmin):
    def url_cian_id(self, obj):
        return form_rentavik_id(obj)

    def get_queryset(self, request):
        queryset = super().get_queryset(request)

        queryset = only_rentavik_ads(queryset, request)

        return queryset

    url_cian_id.short_description = 'id Рентавик'


@admin.register(ProxyNewDataRentavik)
class ProxyNewDataRentavikAdmin(BaseNewDataAdmin):
    def url_cian_id(self, obj):
        return form_rentavik_id(obj)

    def get_queryset(self, request):
        queryset = super().get_queryset(request)

        queryset = only_rentavik_ads(queryset, request)

        return queryset

    url_cian_id.short_description = 'id Рентавик'


admin.site.index_title = "Актуализация"
admin.site.site_header = "Актуализация"
admin.site.site_title = "Актуализация"
