from django.test import TestCase
from django.db import connections

from analysis.models import NewRentBlocks
from interface.settings import (
    RENT_TABLE, SALE_TABLE,
    RENT_PARAM, SALE_PARAM
)


class NewRentBlocksTestCase(TestCase):
    """
    Класс тестирования новых блоков.
    """
    def make_test_request(self, cursor, **kwargs):
        temp = f"""
            SELECT rb.id, b.is_export_markets, cb.is_export_markets, fe.is_active,
                cb.is_available
            FROM {kwargs['table_param']} AS rb
            INNER JOIN common_blocks AS cb ON rb.common_block_id = cb.id
            INNER JOIN buildings AS br ON cb.building_id = br.id
            INNER JOIN {kwargs['feed_table']} AS cbl ON rb.id = cbl.rent_block_id
            INNER JOIN cian_feed_elements AS cfe ON cbl.cian_feed_element_id = cfe.id
            INNER JOIN feed_elements AS fe ON cfe.feed_element_id = fe.id
            WHERE br.id = {kwargs['building_id']}
            AND ABS(max_area - {kwargs['area_max']}) / max_area <= 0.05
        """

    def test_existance_in_db(self):
        """Тест проверяет новые блоки на наличие в БД."""
        # получаем все объекты и галки на полях выгрузки
        try:
            # подключение к БД
            with connections['base'].cursor() as cursor:
                for obj in NewRentBlocks.objects.all():
                    pass

        except Exception:
            pass
