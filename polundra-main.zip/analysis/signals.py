from django.db.models.signals import pre_save
from django.dispatch import receiver
from django.utils import timezone
from .models import (
    SortedData, BlackList
)


@receiver(pre_save, sender=(SortedData))
def update_status_change_date(sender, instance, **kwargs):
    try:
        previous_instance = sender.objects.get(pk=instance.pk)
    except sender.DoesNotExist:
        previous_instance = None

    if previous_instance and previous_instance.status != instance.status:
        instance.status_update = timezone.now()


@receiver(pre_save, sender=SortedData)
def update_black_list(sender, instance, **kwargs):
    if instance.status and instance.status.name == "Черный список":
        BlackList.objects.get_or_create(address=instance.address)
