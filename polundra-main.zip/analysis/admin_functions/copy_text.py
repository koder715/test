from django.http import HttpResponse
import json


def copy_to_clipboard(modeladmin, request, queryset):
    """Метод отвечающий за копирование текста в буфер обмена в админке."""
    text = ""

    for obj in queryset:
        amount = obj.cian_id.split(", ")
        url = ""
        for u in range(0, len(amount)):
            if obj.offer_type == "Аренда":
                url = f"https://www.cian.ru/rent/commercial/{amount[u]}/"
            else:
                url = f"https://www.cian.ru/sale/commercial/{amount[u]}/"
            text += (
                f"{url}\n"
                f"{obj.agency_name.split(', ')[u]}\n"
                f"КОКОН\nФейк\n\n"
            )

    json_text_to_copy = json.dumps(text.strip())

    js_code = f"""
        var textToCopy = {json_text_to_copy};
        navigator.clipboard.writeText(textToCopy)
            .then(function() {{
                window.location.href = window.location.href;
            }})
            .catch(function(err) {{
                console.error('Не удалось скопировать текст: ', err);
            }});
    """

    return HttpResponse(f"<script>{js_code}</script>")


copy_to_clipboard.short_description = "Копировать в буфер обмена"
