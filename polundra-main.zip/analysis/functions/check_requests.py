import logging
import pandas as pd
from typing import Tuple, Any, Dict, List

from .save_last_parsing import SaveLastParsing
from interface.settings import AGENCY_NAME


logger = logging.getLogger(__name__)


class GetDataFromParsing:
    """
    Класс, получающий данные из парсинга
    и обрабатывающий их.
    """
    def __init__(self, parsing_table) -> None:
        self.parsing_table = parsing_table
        self.offer_type = self.parsing_table.split('_')[-1][0:4]

    def execute_query(
        self, cursor, query: str,
        yesterday, today
    ) -> Tuple[Any]:
        """Метод, осуществляющий запрос к БД."""
        cursor.execute(query, (
            AGENCY_NAME,
            yesterday, today,
            yesterday, today,
        ))
        return cursor.fetchall()

    def make_dict_from_data(self, data: Tuple[Any]) -> Dict[str, Any]:
        """Базовый метод конвертирующий кортеж в словарь."""
        (coords, area_max, rate,
         floor, cian_id, address,
         agency_name, updated_at, object_purpose) = data

        return {
            'coords': coords,
            'area_max': area_max,
            'rate': rate,
            'floor': floor,
            'cian_id': cian_id,
            'address': address,
            'agency_name': agency_name,
            'updated_at': updated_at,
            'object_purpose': object_purpose,
        }

    def make_dataframe(self, data: List[Dict[str, Any]]) -> pd.DataFrame:
        """Метод, формирующий dataframe из данных."""
        return pd.DataFrame(data)

    def exclude_objects_from_parsing(
        self, cursor, query: str,
        records: List[Dict[str, Any]],
        yesterday, today
    ) -> List[Dict[str, Any]]:
        """Метод, выполняющий запрос по поиску совпадений."""

        # находим дубликаты записей
        to_remove = []

        for record in records:
            address = record.get('address')
            floor = record.get('floor')
            area_max = record.get('area_max')

            logger.info(
                f"Передаю объект {address}, "
                f"{floor}, {area_max} на проверку \n"
            )

            cursor.execute(query, (
                address, floor,
                area_max, AGENCY_NAME,
                yesterday, today
            ))

            row = cursor.fetchone()

            if row:
                logger.warning(
                    "Найден объект "
                    f"{address}, {floor}, {area_max}\n"
                )

                to_remove.append(record)

        # удаляем дубликаты
        for row in to_remove:
            records.remove(row)

        logger.info("Проверка данных на совпадения завершена!")

        return records

    def get_parsing_data(self) -> List[Dict[str, Any]]:
        """Получение данных из парсинга для составления запроса."""
        parsed_rows = SaveLastParsing(
            self.parsing_table,
            self.offer_type
        )

        parsing_data = parsed_rows.extract_parsing_data()

        make_dict: List[Dict[str, Any]] = [
            self.make_dict_from_data(row) for row in parsing_data
        ]

        make_df = self.make_dataframe(make_dict)

        parsing_result = make_df.to_dict('records')

        logger.info(
            f"Всего объектов: {len(parsing_data)}"
        )

        return parsing_result
