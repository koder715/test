import logging
from mysql.connector import Error
from django.db import connections
from typing import Union, List

from analysis.models import (
    SophieResultRent, SophieResultSale,
    CianAdresses
)
from interface.settings import AGENCY_NAME


logger = logging.getLogger(__name__)


class SaveSophie:
    """Класс, сохраняющий БД sophie в pg DB."""
    def __init__(self, table_name, table_param) -> None:
        self.table_name = table_name
        self.table_param = table_param
        self.offer_type = self.table_name.split('_')[0]
        self.model_object = self.get_model_object()

    def get_model_object(self) -> Union[SophieResultRent, SophieResultSale]:
        model_dict = {
            'rent': SophieResultRent,
            'sale': SophieResultSale
        }

        return model_dict.get(self.offer_type)

    def query_template(self):
        """Метод, формирующий шаблон запроса."""
        temp = f"""
            SELECT tb.id, cb.id, b.id,
                ROUND(JSON_EXTRACT(b.address_json, '$.data.geo_lat'), 4) AS lat,
                ROUND(JSON_EXTRACT(b.address_json, '$.data.geo_lon'), 4) AS lon,
                cb.max_area,
                m.value,
                b.broker_id,
                CONCAT(rbs.first_name, ' ', rbs.last_name) AS full_name,
                CASE
                    WHEN cb.owner_id = 35 THEN 0
                    WHEN cb.owner_id IS NULL THEN 0
                    ELSE cb.owner_id
                END AS owner_id,
                GREATEST(cb.created_at, act.max_created_at) AS max_created_at,
                CASE
                    WHEN ft.name IN ('Подвальный', 'Мансардный', 'Цокольный') THEN -1
                    WHEN ft.name IS NULL THEN 0
                    ELSE ft.name
                END AS floor,
                CASE
                    WHEN fe.is_active IS NULL THEN 0 ELSE fe.is_active
                END AS cian_active,
                cb.is_available, cb.is_export_markets,
                b.is_export_markets, b.priority_type_id
            FROM {self.table_name} as tb
            LEFT JOIN common_blocks AS cb ON tb.common_block_id = cb.id
            LEFT JOIN buildings as b ON cb.building_id = b.id
            LEFT JOIN money AS m ON tb.{self.table_param} = m.id
            LEFT JOIN responsible_brokers as rbs ON b.broker_id = rbs.user_id
            LEFT JOIN (
                SELECT common_block_id, MAX(created_at) AS max_created_at
                FROM actualizations
                GROUP BY common_block_id
            ) AS act ON cb.id = act.common_block_id
            LEFT JOIN common_block_floor_type AS cft ON cb.id = cft.common_block_id
            LEFT JOIN floor_types AS ft ON cft.floor_type_id = ft.id
            LEFT JOIN cian_{self.offer_type}_block AS crb ON tb.id = crb.{self.offer_type}_block_id
            LEFT JOIN cian_feed_elements AS cfe ON crb.cian_feed_element_id = cfe.id
            LEFT JOIN feed_elements AS fe ON cfe.feed_element_id = fe.id
        """

        return temp

    def make_request(self):
        try:
            with connections['base'].cursor() as cursor:
                query = self.query_template()
                cursor.execute(query)
                rows = cursor.fetchall()
                return rows

        # обработка возможного исключения
        except Error as e:
            logger.error(f"Ошибка при подключении к БД {e}")

    def get_building_priority(self, building_priority):
        """Метод возвращает название приоритета по его id."""
        priority_dict = {
            1: "Высокий",
            2: "Средний",
            3: "Низкий"
        }

        return priority_dict.get(building_priority, 'Не указан')

    def save_sophie_result(self):
        logger.info(f'started saving {self.offer_type} sophie data')

        data = self.make_request()

        objects_to_create = [
            self.model_object(
                block_id=block_id,
                common_block_id=common_block_id,
                building_id=building_id,
                lat=lat,
                lon=lon,
                area_max=area_max,
                rate=rate,
                broker_id=broker_id,
                broker_name=broker_name,
                owner_id=owner_id,
                callback_date=callback_date,
                floor=floor,
                cian_active=cian_active,
                common_block_active=common_block_active,
                common_block_export=common_block_export,
                building_export=building_export,
                building_priority=self.get_building_priority(
                    building_priority
                )
            )
            for (
                block_id,
                common_block_id,
                building_id,
                lat,
                lon,
                area_max,
                rate,
                broker_id,
                broker_name,
                owner_id,
                callback_date,
                floor,
                cian_active,
                common_block_active,
                common_block_export,
                building_export,
                building_priority
            ) in data
        ]

        self.model_object.objects.bulk_create(
            objects_to_create, batch_size=5000
        )

        logger.info(f'Saved {self.offer_type} sophie result')

    def delete_sophie_result(self):
        models: List[
            Union[
                SophieResultRent, SophieResultSale
            ]
        ] = [SophieResultRent, SophieResultSale]

        for mod in models:
            mod.objects.all().delete()

        logger.info("Deleted Sophie result from pg DB!")

    def get_cian_addresses(self):
        """Метод, получающий id здания и определяющий его адрес циана."""
        query = f"""
            SELECT
                s.building_id, p.address
            FROM {self.table_name} AS s
            INNER JOIN (
                SELECT address, agency_name,
                (regexp_matches(description, 'ID объекта - (\\d+)|ID (\\d+)', 'g'))[1]::int AS block_id
                FROM parsing_{self.offer_type}_result
            ) AS p ON s.block_id = p.block_id
            WHERE p.agency_name = '{AGENCY_NAME}'
            GROUP BY s.building_id, p.address
        """

        with connections['default'].cursor() as cursor:
            cursor.execute(query)
            rows = cursor.fetchall()

        for building_id, address in rows:
            obj, created = CianAdresses.objects.get_or_create(
                building_id=building_id,
                defaults={
                    'address': address
                }
            )

            if created:
                logger.info(
                    f"Добавил новый адрес здания {building_id}: "
                    f"{address}"
                )
