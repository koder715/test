import logging
from mysql.connector import Error
from django.db import connections
from datetime import date, timedelta
from typing import Union, List

from analysis.models import ParsingResultRent, ParsingResultSale
from interface.settings import AGENCY_NAME


logger = logging.getLogger(__name__)


class SaveLastParsing:
    """
    Класс сохраняющий результаты парсинга прошедшего дня
    на сервер pgsql.
    """

    def __init__(self, table_name, offer_type) -> None:
        self.table_name = table_name
        self.offer_type = offer_type
        self.model_object = self.get_model_object()

    def get_model_object(self) -> Union[ParsingResultRent, ParsingResultSale]:
        """Метод возвращает необходимую модель."""
        model_dict = {
            'rent': ParsingResultRent,
            'sale': ParsingResultSale
        }

        return model_dict.get(self.offer_type)

    def get_parsing_temp(self):
        """Метод составляющий шаблон запроса для получения данных парсинга."""
        temp = f"""
            SELECT coords, area_max, rate, floor, cian_id,
                address, agency_name, updated_at, object_purpose,
                description
            FROM {self.table_name}
            WHERE created_at BETWEEN %s AND %s
        """

        return temp

    def make_parsing_request(self):
        """Метод получающий данные прошедшего дня."""
        temp = self.get_parsing_temp()
        today = date.today()
        yesterday = today - timedelta(days=1)
        try:
            with connections['analytics'].cursor() as cursor:
                cursor.execute(temp, (yesterday, today))
                rows = cursor.fetchall()

            return rows

        # обработка возможного исключения
        except Error as e:
            logger.error(f"Ошибка при подключении к БД {e}")

    def save_parsing_data(self):
        """Метод сохраняющий данные парсинга в pgsql."""
        rows = self.make_parsing_request()
        for coords, area_max, rate, floor, \
                cian_id, address, agency_name, \
                updated_at, object_purpose, description in rows:
            created = self.model_object.objects.create(
                coords=coords,
                area_max=area_max,
                rate=rate,
                floor=floor,
                cian_id=cian_id,
                address=address,
                agency_name=agency_name,
                created_at=updated_at,
                object_purpose=object_purpose,
                description=description
            )

            print(f'Saved {created.cian_id}')

        logger.info(f'Done saving {self.offer_type} parsing data!')

    def extract_parsing_data(self):
        """Метод достает отфильтрованные данные из pg БД."""
        with connections['default'].cursor() as cursor:
            exclude_query = f"""
                SELECT area_max, address
                FROM parsing_{self.offer_type}_result
                WHERE agency_name = '{AGENCY_NAME}'
            """

            query = f"""
                SELECT cpr.coords, cpr.area_max, cpr.rate, cpr.floor,
                    STRING_AGG(DISTINCT cpr.cian_id, ', ') AS cian_ids,
                    cpr.address,
                    STRING_AGG(DISTINCT cpr.agency_name, ', ') AS agency_names,
                    cpr.created_at, cpr.object_purpose
                FROM parsing_{self.offer_type}_result cpr
                WHERE (cpr.area_max, cpr.address) NOT IN (
                    {exclude_query}
                )
                GROUP BY cpr.coords, cpr.area_max,
                    cpr.rate, cpr.floor, cpr.address, cpr.created_at,
                    cpr.object_purpose
            """

            cursor.execute(query)

            rows = cursor.fetchall()

            return rows

    def delete_parsing_data(self):
        """Метод удаляет данные парсинга."""
        models: List[Union[ParsingResultRent, ParsingResultSale]] = [
            ParsingResultRent, ParsingResultSale
        ]

        for mod in models:
            mod.objects.all().delete()

        logger.info('Deleted parsing data from pg DB!')
