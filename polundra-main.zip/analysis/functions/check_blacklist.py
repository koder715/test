from analysis.models import BlackList


def blacklist(address):
    """Проверка записи на присутствии в черном списке."""
    return BlackList.objects.filter(address=address).exists()
