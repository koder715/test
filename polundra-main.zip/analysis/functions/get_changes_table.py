import logging
from datetime import date, timedelta
import pandas as pd
from django.db import connections


logger = logging.getLogger(__name__)


def get_template(offer_type, start_date, end_date):
    temp = f"""
        SELECT updated.{offer_type}_block_id, types.name, updated.updater_id,
            CONCAT(users.first_name, ' ', users.last_name) AS full_name,
            updated.updated_at, common_blocks.building_id
        FROM updated_{offer_type}_blocks as updated
        INNER JOIN update_event_types AS types ON updated.update_event_type_id = types.id
        INNER JOIN {offer_type}_blocks AS blocks ON updated.{offer_type}_block_id = blocks.id
        INNER JOIN common_blocks AS common_blocks ON blocks.common_block_id = common_blocks.id
        LEFT JOIN responsible_brokers AS users ON updated.updater_id = users.user_id
        WHERE updated.updated_at BETWEEN '{start_date}' AND '{end_date}'
    """

    return temp


def make_block_url(offer_type, building_id, block_id):
    return f'https://base2.of.ru/building/{building_id}/{offer_type}-block/{block_id}'


def make_dict(data, offer_type):
    block_id, change, user_id, \
        user, updated_at, building_id = data
    return {
        'ID блока': block_id,
        'Изменение': change,
        'ID пользователя': user_id,
        'Пользователь': user,
        'Дата': updated_at,
        'Ссылка': make_block_url(offer_type, building_id, block_id)
    }


def make_df(data):
    return pd.DataFrame(data)


def make_sql_request(offer_type):
    with connections['base'].cursor() as cursor:
        end_date = date.today()
        start_date = end_date - timedelta(days=30)
        temp = get_template(offer_type, start_date, end_date)

        cursor.execute(temp)

        rows = cursor.fetchall()

    return rows


def save_changes_to_xlsx(offer_type):
    rows = make_sql_request(offer_type)

    dicts = [
        make_dict(row, offer_type) for row in rows
    ]

    df = make_df(dicts)

    df.to_excel(f'{offer_type}_changes.xlsx', index=False, engine='xlsxwriter')

    logger.info('Сохранил изменения в эксель')
