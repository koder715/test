import logging


logger = logging.getLogger(__name__)


class ParsingSQLTemp:
    """Класс составления запросов к результатам парсинга."""

    def __init__(self, **kwargs) -> None:
        self.template_data = kwargs
        self.parsing_table = self.template_data.get('parsing_table')
        self.agency_name = self.template_data.get('agency_name')
        self.yesterday = self.template_data.get('yesterday')
        self.today = self.template_data.get('today')

        # проверка на ключи
        if not all(
            [
                self.parsing_table,
                self.agency_name,
                self.yesterday,
                self.today
            ]
        ):
            logger.error("Ключи не были переданы для составления шаблона!")
            raise KeyError

    def query_to_remove_duplicates(self) -> str:
        """Метод формирующий запрос на проверку совпадений объявлений."""
        temp = """
            SELECT cian_id
            FROM {table} t1
            WHERE address = %s
            AND floor = %s
            AND ABS(area_max - %s) / area_max <= 0.05
            AND agency_name IN (%s)
            AND created_at BETWEEN %s AND %s
        """.format(table=self.parsing_table)

        return temp

    def base_template(self) -> str:
        """Метод формирующий базовый шаблон."""
        temp = """
                SELECT t1.coords, t1.area_max, t1.rate, t1.floor, t1.cian_id,
                    t1.address, t1.agency_name, t1.updated_at, t1.object_purpose
                FROM {table} t1
                LEFT JOIN (
                    SELECT area_max, rate, floor, address, agency_name
                    FROM {table}
                    WHERE agency_name IN (%s)
                    AND created_at BETWEEN %s AND %s
                ) t2 ON t1.agency_name != t2.agency_name
                AND t1.address = t2.address
            """.format(table=self.parsing_table)

        return temp

    def parsing_query_template(self) -> str:
        """Метод формирующий запрос к парсингу (разные этажи)."""
        base = self.base_template()
        temp = """
            WHERE t1.floor != t2.floor
            AND t1.created_at BETWEEN %s AND %s
        """

        return base + temp

    def parsing_query_same_floor_template(self) -> str:
        """Метод формирующий запрос к парсингу (одинаковые этажи)."""
        base = self.base_template()
        temp = """
            WHERE t1.floor = t2.floor
            AND ABS(t1.area_max - t2.area_max) / t1.area_max >= 0.05
            AND t1.created_at BETWEEN %s AND %s
        """

        return base + temp


class SophieSQLTemp:
    """Класс составления запросов к БД Софи."""
    def __init__(self, *args, **kwargs) -> None:
        # используем кварги, чтобы передавать неограниченное к-во переменных
        self.template_data = kwargs
        self.offer_type = self.template_data['table'].split('_')[0]

        # проверяем наличие обязательных ключей
        if not self.check_keys():
            raise ValueError(
                "Не переданы все необходимые ключи для создания шаблона"
            )

    def check_keys(self):
        """Метод проверяет переданные данные для составления шаблона."""

        required_keys = [
            'table', 'param', 'rate',
            'area_max', 'lat', 'lon', 'floor'
        ]
        if all(key in self.template_data for key in required_keys):
            return True
        else:
            logger.error("Ключи не были переданы для составления шаблона!")
            return False

    def create_template_competitive(self) -> str:
        """
        Метод создает шаблон для поиска объявлений в софи.
        """

        temp = f"""
            WITH exact_matches AS (
                SELECT rb.block_id, rb.common_block_id, rb.building_id,
                    rb.owner_id,
                    rb.broker_id,
                    rb.broker_name,
                    rb.common_block_active,
                    rb.callback_date
                FROM {self.template_data['table']} AS rb
                LEFT JOIN cian_adresses AS ca ON ca.building_id = rb.building_id
                WHERE (
                    rb.common_block_active = 0
                    OR rb.common_block_export = 0
                    OR rb.building_export = 0
                )
                AND
                ((
                    ca.address IS NOT NULL
                    AND ca.address = '{self.template_data['address']}'
                )
                OR
                (
                    ABS({self.template_data['lat']} - lat) <= 0.0002
                    AND
                    ABS({self.template_data['lon']} - lon) <= 0.0002
                ))
                AND rb.area_max = {self.template_data['area_max']}
                AND (
                    rb.floor = {self.template_data['floor']}
                    OR {self.template_data['floor']} IS NULL
                )
            ),
            approximate_matches AS (
                SELECT rb.block_id, rb.common_block_id, rb.building_id,
                    rb.owner_id,
                    rb.broker_id,
                    rb.broker_name,
                    rb.common_block_active,
                    rb.callback_date
                FROM {self.template_data['table']} AS rb
                LEFT JOIN cian_adresses AS ca ON ca.building_id = rb.building_id
                WHERE (
                    rb.common_block_active = 0
                    OR rb.common_block_export = 0
                    OR rb.building_export = 0
                )
                AND
                ((
                    ca.address IS NOT NULL
                    AND ca.address = '{self.template_data['address']}'
                )
                OR
                (
                    ABS({self.template_data['lat']} - lat) <= 0.0002
                    AND
                    ABS({self.template_data['lon']} - lon) <= 0.0002
                ))
                AND ABS(rb.area_max - {self.template_data['area_max']}) / NULLIF(CAST(rb.area_max AS numeric), 0) <= 0.05
                AND (
                    rb.floor = {self.template_data['floor']}
                    OR {self.template_data['floor']} IS NULL
                )
            )
            SELECT * FROM exact_matches
            UNION ALL
            SELECT * FROM approximate_matches
            WHERE NOT EXISTS (SELECT 1 FROM exact_matches)
        """

        return temp

    # def create_template_new(self) -> str:
    #     """Метод создает шаблон для поиска новых объявлений."""

    #     temp = f"""
    #         SELECT rb.id, rb.common_block_id, cb.building_id,
    #             rb.updated_at, COUNT(cb.owner_id) AS owner_count, broker_id
    #         FROM {self.template_data['table']} AS rb
    #         INNER JOIN common_blocks AS cb ON rb.common_block_id = cb.id
    #         INNER JOIN money AS m ON rb.{self.template_data['param']} = m.id
    #         INNER JOIN common_block_floor_type AS cft ON cb.id = cft.common_block_id
    #         INNER JOIN floor_types AS ft ON cft.floor_type_id = ft.id
    #         INNER JOIN buildings AS br ON cb.building_id = br.id
    #         INNER JOIN (
    #             SELECT id AS block_id
    #             FROM common_blocks
    #             WHERE
    #                 ABS(max_area - {self.template_data['area_max']}) / max_area <= 0.05
    #                 AND
    #                 building_id IN (
    #                     SELECT id
    #                     FROM buildings
    #                     WHERE
    #                         ROUND(JSON_EXTRACT(address_json, '$.data.geo_lat'), 4) = {self.template_data['lat']}
    #                         AND
    #                         ROUND(JSON_EXTRACT(address_json, '$.data.geo_lon'), 4) = {self.template_data['lon']}
    #                 )
    #             ) AS cb2 ON rb.common_block_id = cb2.block_id
    #         GROUP BY rb.id
    #         ORDER BY m.value
    #     """

    #     return temp

    def create_find_resp_template(self) -> str:
        temp = f"""
            SELECT b.building_id, b.broker_id,
                b.broker_name
            FROM {self.template_data['table']} AS b
            LEFT JOIN cian_adresses AS ca ON ca.building_id = b.building_id
            WHERE
                (
                    ca.address IS NOT NULL
                    AND ca.address = '{self.template_data['address']}'
                )
                OR
                (
                    ca.address IS NULL AND
                    ABS({self.template_data['lat']} - lat) <= 0.0002
                    AND
                    ABS({self.template_data['lon']} - lon) <= 0.0002
                )
        """

        return temp

    def create_check_block_template(self) -> str:
        """Метод, создающий шаблон запроса для проверки блока в БД."""
        temp = f"""
                SELECT rb.block_id, rb.building_id
                FROM {self.template_data['table']} AS rb
                LEFT JOIN cian_adresses AS ca ON ca.building_id = rb.building_id
                WHERE
                ((
                    ca.address IS NOT NULL
                    AND ca.address = '{self.template_data['address']}'
                )
                OR
                (
                    ABS({self.template_data['lat']} - lat) <= 0.0002
                    AND
                    ABS({self.template_data['lon']} - lon) <= 0.0002
                ))
                AND ABS(rb.area_max - {self.template_data['area_max']}) / NULLIF(CAST(rb.area_max AS numeric), 0) <= 0.05
                AND (
                    rb.floor = {self.template_data['floor']}
                    OR {self.template_data['floor']} IS NULL
                )
            """

        return temp


def create_is_available_template(table_name, block_id):
    """Функция создает шаблон, проверяющий галочку 'на рынке'."""
    temp = f"""
        SELECT common_block_active
        FROM {table_name}_blocks
        WHERE block_id = {block_id}
    """

    return temp
