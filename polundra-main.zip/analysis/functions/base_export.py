import json
import logging
import pandas as pd
import numpy as np
from typing import Tuple, List, Dict, Any
from django.db import connections

from .check_requests import GetDataFromParsing
from .sql_templates import SophieSQLTemp
from .check_blacklist import blacklist
from analysis.for_tasks.add_to_db import AddToDb


logger = logging.getLogger(__name__)


class ProcessParsingData:
    """
    Базовый класс для обработки данных из парсинга.
    """
    competitive_keys: List[str] = [
        'block_id',
        'common_block_id',
        'building_id',
        'owner_count',
        'broker_id',
        'broker_name',
        'is_active'
    ]
    offer_type_dict: Dict[str, str] = {
        'rent': 'Аренда',
        'sale': 'Продажа',
    }

    def __init__(
        self, table_name: str,
        table_param: str, parsing_table: str
    ) -> None:
        self.table_name = table_name
        self.table_param = table_param
        self.parsing_table = parsing_table
        self.offer_type = self.offer_type_dict.get(
            self.table_name.split('_')[0], None
        )

    def standartize_parsing(
        self, parsing_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Функция стандартизирует полученные данные из парсинга
        для составления запроса к БД.
        """
        try:
            # Извлекаем координаты
            coords = json.loads(parsing_data['coords'])
            # Округление координат до 4 знаков после запятой
            lng = round(coords['lng'], 4)
            lat = round(coords['lat'], 4)

            # Стандартизация цены и площади
            price = round(float(parsing_data['rate']), 2)
            area = int(round(float(parsing_data['area_max'])))

            # Проверка на наличие объекта в черном списке
            if not blacklist(parsing_data['address']):
                return {
                    'rate': price,
                    'area_max': area,
                    'lat': lat,
                    'lon': lng,
                    'floor': (
                        parsing_data['floor']
                        if isinstance(parsing_data['floor'], int) else 0
                    ),
                    'cian_id': parsing_data['cian_id'],
                    'address': parsing_data['address'],
                    'agency_name': parsing_data['agency_name'],
                    'cian_created': parsing_data['updated_at'],
                    'block_type': parsing_data['object_purpose'],
                    'offer_type': self.offer_type,
                }
            else:
                logger.warning(
                    f"Адрес {parsing_data[5]} находится в черном списке!"
                )

        except (IndexError, KeyError, ValueError) as e:
            logger.error(
                f"Ошибка при стандартизации данных из парсинга: {e}",
                exc_info=True
            )

    def get_and_process_parsing_data(self, parsing_model=GetDataFromParsing):
        """Метод получает и обрабатывает данные парсинга."""
        # получение данных парсинга
        get_data = parsing_model(
            self.parsing_table
        )
        parsing_data = get_data.get_parsing_data()

        # стандартизация данных парсинга
        processed_parsing_data = [
            self.standartize_parsing(row) for row in parsing_data
        ]

        return processed_parsing_data

    def execute_query(self, cursor, query: str) -> Tuple[Any]:
        cursor.execute(query)
        return cursor.fetchone()

    def find_resp(
        self, cursor, template_instance: SophieSQLTemp
    ) -> Dict[str, Any]:
        """Метод находит ответственного по координатам в БД."""
        query = template_instance.create_find_resp_template()
        row = self.execute_query(cursor, query)

        # инициализация словаря с данными об ответственном
        broker_info = {}
        broker_info.update(
            {
                'building_id': row[0] if row else None,
                'broker_id': row[1] if row else None,
                'broker_name': row[-1] if row else None,
            }
        )

        return broker_info

    def unite_dicts(
        self, row: Tuple[Any],
        keys: List[str],
        **record: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Метод создает объединенный словарь с данными парсинга и базы.
        """

        for key, value in zip(keys, row):
            record[key] = value

        record['updated_at'] = row[7]

        return record

    def process_new_rows(
        self, cursor, template_instance,
        record
    ):
        is_resp = self.find_resp(cursor, template_instance)

        for key, value in is_resp.items():
            record[key] = value

        if not is_resp['building_id']:
            logger.warning(
                "Ответственный по блоку "
                f"{record['cian_id']}\n"
                f"по координатам {record['lat']} "
                f"- {record['lon']} "
                "не найден!\n"
            )

        else:
            logger.info(
                "Ответственный по блоку "
                f"{record['cian_id']}\n"
                f"по координатам {record['lat']} "
                f"- {record['lon']} "
                "успешно найден!\n"
            )

    def get_agg_params(self, param):
        """Метод получает данные для аггрегации датафрейма."""

        groupby = None
        agg = None

        if param == 'competitive':
            groupby = 'block_id'
            agg = {
                'common_block_id': 'first',
                'building_id': 'first',
                'updated_at': 'first',
                'owner_count': 'first',
                'is_active': 'first',
                'broker_id': 'first',
                'broker_name': 'first',
                'cian_id': ', '.join,
                'area_max': 'first',
                'rate': 'first',
                'address': 'first',
                'floor': 'first',
                'agency_name': ', '.join,
                'cian_created': 'first',
                'offer_type': 'first',
            }

        if param == 'new':
            groupby = [
                'address',
                'area_max',
                'floor'
            ]
            agg = {
                'cian_id': ', '.join,
                'building_id': 'first',
                'agency_name': ', '.join,
                'rate': 'first',
                'broker_id': 'first',
                'broker_name': 'first',
                'block_type': 'first',
                'offer_type': 'first',
            }

        return groupby, agg

    def process_merged_data(
        self, merged_dicts, param, update_field
    ) -> pd.DataFrame:
        """
        Метод обрабатывает объединенные данные конкурентных объявлений.
        """
        # Объединение полученных данных и создание датафрейма
        final_df = pd.DataFrame(merged_dicts)
        gr_by, aggregate = self.get_agg_params(param)

        final_df = final_df.groupby(gr_by).agg(aggregate).reset_index()

        logger.info('Датафреймы объединены!')

        final_df = final_df.replace({np.nan: None})

        add_data = AddToDb(
            param=param,
            df=final_df
        )

        add_data.add_to_db(update_field=update_field)

    def check_objects_sophie(
        self, cursor,
        template_instance: SophieSQLTemp,
        record
    ):
        """Метод, проверяющий наличие блоков в Софи."""
        temp = template_instance.create_check_block_template()
        cursor.execute(temp)
        row = cursor.fetchone()

        if row:
            logger.info(
                f'Нашел блок в базе: {record["address"]} '
                f'{row}'
            )

        return True if row else False


class GetCompetitiveAds(ProcessParsingData):
    def __init__(
        self, table_name: str,
        table_param: str, parsing_table: str
    ) -> None:
        super().__init__(table_name, table_param, parsing_table)

    def process_merged_competitive_data(
        self, merged_dicts, param, update_field
    ) -> pd.DataFrame:
        """
        Метод обрабатывает объединенные данные конкурентных объявлений.
        """
        # Объединение полученных данных и создание датафрейма
        final_df = pd.DataFrame(merged_dicts)
        gr_by, aggregate = self.get_agg_params(param)

        final_df = final_df.groupby(gr_by).agg(aggregate).reset_index()

        logger.info('Датафреймы объединены!')

        final_df = final_df.replace({np.nan: None})

        add_data = AddToDb(
            param=param,
            df=final_df
        )

        add_data.add_to_db(update_field=update_field)

    # подумать над этим методом
    def get_competitive_objects(self) -> None:
        """Метод осуществляет запрос к БД и формирует данные."""
        merged_competitive_dicts: List[Dict[str, Any]] = []
        merged_new_dicts: List[Dict[str, Any]] = []

        # получение данных парсинга
        processed_parsing_data = self.get_and_process_parsing_data()

        # подключение к БД
        with connections['default'].cursor() as cursor:
            for record in processed_parsing_data:
                # инициализация SQLTemp
                template_instance = SophieSQLTemp(
                    table=self.table_name,
                    param=self.table_param,
                    **record
                )
                # получение шаблона запроса
                query = template_instance.create_template_competitive()
                # выполнение запроса
                row = self.execute_query(cursor, query)
                # добавление данных в список датафреймов
                if row:
                    united_dict = self.unite_dicts(
                        row,
                        self.competitive_keys,
                        **record
                    )

                    logger.info(row)

                    merged_competitive_dicts.append(united_dict)

                if not row and not self.check_objects_sophie(
                    cursor, template_instance, record
                ):
                    self.process_new_rows(
                        cursor, template_instance, record
                    )

                    merged_new_dicts.append(record)

        if merged_competitive_dicts:
            self.process_merged_data(
                merged_competitive_dicts,
                'competitive',
                'block_id'
            )

        if merged_new_dicts:
            self.process_merged_data(
                merged_new_dicts,
                'new',
                'cian_id'
            )
