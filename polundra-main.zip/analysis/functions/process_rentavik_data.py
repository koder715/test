import logging
from typing import List, Dict, Any
from django.db import connections

from .rentavik import RentavikParser
from .base_export import ProcessParsingData
from .sql_templates import SophieSQLTemp


logger = logging.getLogger(__name__)


class GetRentavikData(ProcessParsingData):
    def __init__(
        self, table_name: str,
        table_param: str, parsing_table: str
    ) -> None:
        super().__init__(table_name, table_param, parsing_table)

    def get_competitive_objects(self) -> None:
        """Метод осуществляет запрос к БД и формирует данные."""
        merged_competitive_dicts: List[Dict[str, Any]] = []
        merged_new_dicts: List[Dict[str, Any]] = []

        # получение данных парсинга
        processed_parsing_data = self.get_and_process_parsing_data(
            RentavikParser
        )

        # подключение к БД
        with connections['default'].cursor() as cursor:
            for record in processed_parsing_data:
                # инициализация SQLTemp
                template_instance = SophieSQLTemp(
                    table=self.table_name,
                    param=self.table_param,
                    **record
                )
                # получение шаблона запроса
                query = template_instance.create_template_competitive()
                # выполнение запроса
                row = self.execute_query(cursor, query)
                # добавление данных в список датафреймов
                if row:
                    united_dict = self.unite_dicts(
                        row,
                        self.competitive_keys,
                        **record
                    )

                    logger.info(row)

                    merged_competitive_dicts.append(united_dict)

                if not row and not self.check_objects_sophie(
                    cursor, template_instance, record
                ):
                    self.process_new_rows(
                        cursor, template_instance, record
                    )

                    merged_new_dicts.append(record)

        if merged_competitive_dicts:
            self.process_merged_data(
                merged_competitive_dicts,
                'competitive',
                'block_id'
            )

        if merged_new_dicts:
            self.process_merged_data(
                merged_new_dicts,
                'new',
                'cian_id'
            )
