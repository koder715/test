import requests
import re
import logging
from time import sleep
from json import dumps, dump, load, JSONDecodeError
from datetime import datetime
from bs4 import BeautifulSoup
from typing import List, Dict, Any


logger = logging.getLogger(__name__)


class RentavikParser:
    def __init__(self, pasring_type) -> None:
        self.parsing_type = pasring_type

    def keep_only_digits(self, input_string):
        # Используем регулярное выражение для поиска всех цифр в строке
        return ''.join(re.findall(r'\d', input_string))

    def extract_coordinates(self, input_string):
        # Регулярное выражение для поиска координат
        pattern = r"showInmap\('([\d.]+),([\d.]+)'.*"

        # Поиск совпадений
        match = re.search(pattern, input_string)

        if match:
            latitude = match.group(1)
            longitude = match.group(2)
            return dumps(
                {
                    'lat': float(latitude),
                    'lng': float(longitude)
                }
            )
        else:
            return None

    def make_rentavik_req(self, page=1):
        cookies = {
            'YnwHDM': 'sXpFZWIugSCJHthPURcmVfLqlOkdxw',
            '_ym_uid': '169139756388530593',
            '_ym_d': '1723187027',
            '_ga': 'GA1.2.114722090.1723187027',
            'BX_USER_ID': '8c509dea71fd25c2d9d3cfe7d75fbc65',
            'sXpFZWIugSCJHthPURcmVfLqlOkdxw': '2eb0f4df30c79cf383c359e1d65f3b67-1724662078',
            'PHPSESSID': '4qk4o1181vdk5ch3kjskc5ppi5',
            '_gid': 'GA1.2.784573740.1725347178',
            '_gat': '1',
            '_clck': '297l3j%7C2%7Cfov%7C0%7C1682',
            '_ym_visorc': 'w',
            '_ym_isad': '1',
            'YnwHDM_hits': '2',
            '_ga_NP2CY18NT7': 'GS1.2.1725347178.14.1.1725347189.0.0.0',
            '_clsk': '16w5ty5%7C1725347189902%7C2%7C1%7Cp.clarity.ms%2Fcollect',
            'cf_clearance': 'XuGYDUp83pgvqXOj9_wAb6vEENs10TTbE7O9GqI9XM8-1725347194-1.2.1.1-pkVqG6DLphwz2idgDl9xSUFFtwn83az.LZF5udtEkPi2ievAf6sqEF7xqvVTKTKQ55myRFom.BunX3J13b9VnoheZG_64Ry0HKoswLlvSmZbaclC_Gj4a4nU1m9cPBtq2kXUHgCI9544ofPZVZSZW8Ob.YYKhhcAhc4QmgCnZs889YR7XQzbYfBxsm6eG8lnIm1kmgIe2tj_NrMslAM9tOslXkqSqd2LqTliNRXwfnNi3a2NNFUbIbIzzHaXqSKjDDZx1KSain5R56sXRilosyeu0fR5YZCfGwOkpPc_Zn1iMQir_a5RMQG87ohdNhZtZtMctkCjLAl28dvc9baTDpkOwM34xVZsJTBtdc1DYb6O2T_U7K8SX_yI.Va.ROT.0.wtWFrcU..WtM8699PNy4d69mEyXfFDKBRoZRmIjHQ',
        }

        headers = {
            'accept': '*/*',
            'accept-language': 'ru,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            # 'cookie': 'YnwHDM=sXpFZWIugSCJHthPURcmVfLqlOkdxw; _ym_uid=169139756388530593; _ym_d=1723187027; _ga=GA1.2.114722090.1723187027; BX_USER_ID=8c509dea71fd25c2d9d3cfe7d75fbc65; sXpFZWIugSCJHthPURcmVfLqlOkdxw=2eb0f4df30c79cf383c359e1d65f3b67-1724662078; PHPSESSID=4qk4o1181vdk5ch3kjskc5ppi5; _gid=GA1.2.784573740.1725347178; _gat=1; _clck=297l3j%7C2%7Cfov%7C0%7C1682; _ym_visorc=w; _ym_isad=1; YnwHDM_hits=2; _ga_NP2CY18NT7=GS1.2.1725347178.14.1.1725347189.0.0.0; _clsk=16w5ty5%7C1725347189902%7C2%7C1%7Cp.clarity.ms%2Fcollect; cf_clearance=XuGYDUp83pgvqXOj9_wAb6vEENs10TTbE7O9GqI9XM8-1725347194-1.2.1.1-pkVqG6DLphwz2idgDl9xSUFFtwn83az.LZF5udtEkPi2ievAf6sqEF7xqvVTKTKQ55myRFom.BunX3J13b9VnoheZG_64Ry0HKoswLlvSmZbaclC_Gj4a4nU1m9cPBtq2kXUHgCI9544ofPZVZSZW8Ob.YYKhhcAhc4QmgCnZs889YR7XQzbYfBxsm6eG8lnIm1kmgIe2tj_NrMslAM9tOslXkqSqd2LqTliNRXwfnNi3a2NNFUbIbIzzHaXqSKjDDZx1KSain5R56sXRilosyeu0fR5YZCfGwOkpPc_Zn1iMQir_a5RMQG87ohdNhZtZtMctkCjLAl28dvc9baTDpkOwM34xVZsJTBtdc1DYb6O2T_U7K8SX_yI.Va.ROT.0.wtWFrcU..WtM8699PNy4d69mEyXfFDKBRoZRmIjHQ',
            'origin': 'https://rentavik.ru',
            'priority': 'u=1, i',
            'referer': 'https://rentavik.ru/',
            'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "YaBrowser";v="24.7", "Yowser";v="2.5"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 YaBrowser/24.7.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }

        params = {
            'isAjax': 'true',
            'city_code': 'spb',
            'globalFilter': 'true',
            'PAGEN_1': str(page),
        }

        data = {
            'office[TYPE_OFFICE]': '1' if self.parsing_type == "arenda" else '2',
            'building[nearType]': '1',
            'only_actual': '1',
            'office[price-type]': '1',
            'office[nds]': 'false',
            'office[arenda_okupaemost]': '0',
        }

        response = requests.post(
            'https://rentavik.ru/',
            headers=headers,
            cookies=cookies,
            data=data,
            params=params,
        )

        return response.text

    def find_pagen(self, page_source: BeautifulSoup):
        pagen = page_source.find(
            'div', class_='filterresults-pagging pagging'
        )['data-count']

        return pagen

    def extract_offer_data(self, offer_prices: List[BeautifulSoup]):
        for value in offer_prices:
            square_src, rate_src, price_src = value.find_all(
                'div', class_='filterresults-offer-prices__value'
            )

            offer_type = square_src.text.strip().split('-')[0].strip()
            square = self.keep_only_digits(square_src.text)[:-1]
            rate = self.keep_only_digits(rate_src.text)[:-1]

            return [offer_type, square, rate]

    def extract_reference_data(self, offer_references: List[BeautifulSoup]):
        for reference in offer_references:
            offer_id_src = reference.find(
                'div', class_='cell u-edit-card__item-main'
            )

            floor_src = reference.find(
                'div', class_='u-edit-card__items-section'
            )

            offer_id = self.keep_only_digits(offer_id_src.text)
            floor = self.keep_only_digits(floor_src.text)

            return [offer_id, floor if floor else 0]

    def process_obj_params(self, obj_params: List[BeautifulSoup], ads: list):
        """Метод выводит параметры объекта."""
        for obj in obj_params:
            # здесь f-string на аренду или продажу
            params: List[BeautifulSoup] = obj.find_all(
                'div', class_=f'filterresults-offer u-edit-card {self.parsing_type}'
            )

            for param in params:
                try:
                    # данный цикл собирает ставку и площадь объектов
                    offer_prices: List[BeautifulSoup] = param.find_all(
                        'div', class_='row full u-filterresults-offer-prices'
                    )

                    data = self.extract_offer_data(offer_prices)

                    offer_references: List[BeautifulSoup] = param.find_all(
                        'div', class_='filterresults-offer-params u-edit-card__list'
                    )

                    references = self.extract_reference_data(offer_references)

                    ads.append(references + data)

                except Exception:
                    pass

    def load_parsing_data(self, page) -> List[Dict[str, Any]]:
        res = []

        response = self.make_rentavik_req(page)

        soup = BeautifulSoup(response, 'html.parser')

        buildings: List[BeautifulSoup] = [
            x for x in soup.find_all(
                'div', class_='filterresults-item row'
            )
        ]

        for row in buildings:
            ads = []
            address = row.find(
                'div', class_='filterresults-header__value'
            )

            url_head = 'https://rentavik.ru'

            url_head += row.find(
                'div', class_='filterresults-item__title'
            ).find('a')['href']

            coords = row.find(
                'div', class_='filterresults-header-table tbott'
            ).find('a', class_='filterresults-header__map fancybox')['onclick']

            obj_params: List[BeautifulSoup] = [
                x for x in row.find_all(
                    'div',
                    class_='filterresults-item-offers'
                )
            ]

            self.process_obj_params(obj_params, ads)

            for (
                offer_id, floor,
                offer_type, square, rate
            ) in ads:
                offer = {
                    'cian_id': offer_id,
                    'floor': int(floor),
                    'object_purpose': offer_type,
                    'rate': rate,
                    'area_max': square,
                    'url': url_head+offer_id,
                    'address': address.text,
                    'coords': self.extract_coordinates(coords),
                    'agency_name': 'Рентавик Сайт',
                    'updated_at': datetime.today().date().isoformat()
                }

                res.append(offer)

        return res

    def save_parsing_res(self):
        res = []
        response = self.make_rentavik_req()
        soup = BeautifulSoup(response, 'html.parser')
        # получение количества страниц
        pagen = self.find_pagen(soup)

        for page in range(1, int(pagen) + 1):
            data = self.load_parsing_data(page)
            res += data
            logger.info(f'Сохранил результаты страницы {page}!')
            sleep(4)

        with open(
            f'{self.parsing_type}_parsing_data.json',
            'w', encoding='utf-8'
        ) as f:
            dump(res, f, ensure_ascii=False, indent=4)

    def get_parsing_data(self) -> List[Dict[str, Any]]:
        try:
            with open(
                f'{self.parsing_type}_parsing_data.json',
                'r', encoding='utf-8'
            ) as f:
                data = load(f)
            return data
        except FileNotFoundError:
            logger.info(f"Файл {self.parsing_type}_parsing_data не найден.")
            return []
        except JSONDecodeError:
            logger.info("Ошибка при декодировании JSON.")
            return []

    def update_floor_to_int(self):
        data = self.get_parsing_data()

        for item in data:
            if 'floor' in item:
                try:
                    item['floor'] = int(item['floor'])
                except ValueError:
                    logger.info(
                        "Не удалось преобразовать floor в int "
                        f"для записи: {item}"
                    )

        with open(
            f'{self.parsing_type}_parsing_data.json',
            'w', encoding='utf-8'
        ) as f:
            dump(data, f, ensure_ascii=False, indent=4)
