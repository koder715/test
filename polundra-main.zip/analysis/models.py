import logging
from django.db import models
from django.contrib.contenttypes.fields import (
    GenericForeignKey, GenericRelation
)
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import get_user_model


User = get_user_model()
logger = logging.getLogger(__name__)


class Status(models.Model):
    """Класс статуса актуализации."""
    name = models.CharField(
        verbose_name="Статус",
        max_length=20
    )

    class Meta:
        verbose_name = "Статус"
        verbose_name_plural = "Статусы"

    def __str__(self) -> str:
        return self.name


class BaseModel(models.Model):
    """Базовая модель."""
    building_id = models.IntegerField(
        verbose_name="Здание в БД",
        null=True,
        default=None,
    )
    cian_id = models.TextField(
        verbose_name="id в Циан",
        default=None,
    )
    area_max = models.IntegerField(
        verbose_name="Площадь",
        default=None,
    )
    rate = models.FloatField(
        verbose_name="Ставка",
        default=None,
    )
    address = models.CharField(
        verbose_name="Адрес",
        max_length=256,
        default=None,
    )
    floor = models.IntegerField(
        verbose_name="Этаж",
        null=True,
        blank=True
    )
    agency_name = models.TextField(
        verbose_name="Агентство",
        default=None,
    )
    offer_type = models.CharField(
        max_length=30,
        verbose_name="Тип сделки",
        default=None,
    )
    status = models.ForeignKey(
        Status,
        on_delete=models.SET_NULL,
        verbose_name="Статус",
        null=True,
        blank=True
    )
    broker_id = models.IntegerField(
        verbose_name="Отвественный в БД",
        null=True,
        blank=True
    )
    broker_name = models.CharField(
        verbose_name="Имя отвественного",
        max_length=100,
        null=True,
        blank=True
    )
    added = models.DateField(
        auto_now_add=True,
        verbose_name="Дата добавления в базу данных",
        null=True,
        blank=True
    )
    total_price = models.FloatField(
        verbose_name="Полная цена",
        blank=True,
        null=True
    )

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if self.offer_type == "Аренда":
            self.total_price = (self.area_max * self.rate) / 12
        elif self.offer_type == "Продажа":
            self.total_price = self.area_max * self.rate
        else:
            self.total_price = 0

        super().save(*args, **kwargs)


class ActualisingData(BaseModel):
    """Модель блоков для аналитики."""
    block_id = models.IntegerField(
        verbose_name="Блок в БД",
        null=True,
        blank=True
    )
    common_block_id = models.IntegerField(
        verbose_name="id общего блока в БД",
        null=True,
        blank=True
    )
    updated_at = models.DateField(
        verbose_name="Актуализация в БД",
        null=True,
        blank=True
    )
    owner_count = models.IntegerField(
        verbose_name="K-во собст.",
        null=True,
        blank=True
    )
    is_active = models.IntegerField(
        verbose_name="Выгрузка Циан",
        default=0,
    )
    updated = models.DateField(
        verbose_name="Дата обновления в базе данных",
        null=True,
        blank=True
    )
    status_update = models.DateTimeField(
        verbose_name="Дата обновления статуса",
        null=True,
        blank=True
    )
    cian_created = models.DateField(
        verbose_name="Дата добавления на Циан",
        default="1970-01-01"
    )

    class Meta:
        abstract = True

    def __str__(self) -> str:
        return str(self.block_id)


class Comments(models.Model):
    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.CASCADE,
        limit_choices_to={
            'model__in': (
                    'sorteddata', 'assistblocks', 'diffrespbr',
                    'myblocks', 'newrentblocks'
                ),
        },
        related_name='comments',
        default=None,
    )
    object_id = models.PositiveIntegerField(
        null=True,
        default=None,
    )
    content_object = GenericForeignKey('content_type', 'object_id')
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        verbose_name='Автор',
        related_name='comments',
    )
    text = models.TextField(
        verbose_name='Текст комментария',
    )
    pub_date = models.DateTimeField(
        verbose_name='Дата добавления',
        auto_now_add=True,
        db_index=True,
        null=True,
        blank=True,
    )

    class Meta:
        verbose_name = 'Комментарий'
        verbose_name_plural = 'Комментарии'
        ordering = ['-pub_date']


class SortedData(ActualisingData):
    comments = GenericRelation(Comments)
    building_priority = models.CharField(
        max_length=25,
        default="Не указан",
        verbose_name='Приоритет'
    )

    class Meta:
        verbose_name = 'П. Блок на актуализацию'
        verbose_name_plural = 'П. Блоки на актулизацию'
        ordering = ['-added']

    def save(self, *args, **kwargs):
        if SortedData.objects.filter(pk=self.pk).exists():
            old_instance = SortedData.objects.get(pk=self.pk)
            if old_instance.status != self.status:
                print(
                    f"Status changed for SortedData#{self.pk} "
                    f"from {old_instance.status} to {self.status}"
                )

        super().save(*args, **kwargs)


class ProxyMyBlocks(SortedData):

    class Meta:
        proxy = True
        verbose_name = 'Мои блоки'
        verbose_name_plural = 'Мои блоки'
        ordering = ['-added']


class ProxyMyBlocksRentavik(SortedData):

    class Meta:
        proxy = True
        verbose_name = 'Мои блоки Рентавик'
        verbose_name_plural = 'Мои блоки Рентавик'
        ordering = ['-added']


class ProxyAssistBlocks(SortedData):

    class Meta:
        proxy = True
        verbose_name = 'Блок на Ассистенте'
        verbose_name_plural = 'Блоки на Ассистенте'
        ordering = ['-added']


class ProxyDiffRespBr(SortedData):

    class Meta:
        proxy = True
        verbose_name = 'Блок с разными ответственными'
        verbose_name_plural = 'Блоки с разными ответственными'
        ordering = ['-added']


class NewData(BaseModel):
    block_type = models.CharField(
        max_length=30,
        verbose_name="Тип помещения",
        null=True,
        default=None
    )

    class Meta:
        verbose_name = 'П. Новое объявление'
        verbose_name_plural = 'П. Новые объявления'
        ordering = ['-added']

    def save(self, *args, **kwargs):
        if NewData.objects.filter(pk=self.pk).exists():
            old_instance = NewData.objects.get(pk=self.pk)
            if old_instance.status != self.status:
                print(
                    f"Status changed for NewData#{self.pk} "
                    f"from {old_instance.status} to {self.status}"
                )

        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return str(self.cian_id)


class ProxyNewData(NewData):

    class Meta:
        proxy = True
        verbose_name = "Новый блок"
        verbose_name_plural = "Новые блоки"
        ordering = ['-added']


class ProxyNewDataRentavik(NewData):

    class Meta:
        proxy = True
        verbose_name = "Новый блок Рентавик"
        verbose_name_plural = "Новые блоки Рентавик"
        ordering = ['-added']


class BlackList(models.Model):
    address = models.CharField(
        verbose_name="Забаненный адрес",
        max_length=256,
    )
    added = models.DateField(
        auto_now_add=True,
        verbose_name="Дата добавления",
    )

    class Meta:
        verbose_name = 'Черный список'
        verbose_name_plural = 'Черный список'
        ordering = ['-added']


class ParsingResult(models.Model):
    """Модель для хранения результатов парсинга прошлого дня."""
    coords = models.CharField(
        max_length=255,
        default=None
    )
    area_max = models.DecimalField(
        max_digits=12,
        decimal_places=2
    )
    rate = models.DecimalField(
        max_digits=16,
        decimal_places=2
    )
    floor = models.SmallIntegerField(
        default=1
    )
    cian_id = models.CharField(
        max_length=255
    )
    address = models.CharField(
        max_length=255
    )
    agency_name = models.CharField(
        max_length=255,
        default=None
    )
    created_at = models.DateField(
        default=None
    )
    object_purpose = models.CharField(
        max_length=255,
        default=None
    )
    description = models.TextField(
        default=None
    )

    class Meta:
        abstract = True


class ParsingResultRent(ParsingResult):
    class Meta:
        db_table = 'parsing_rent_result'


class ParsingResultSale(ParsingResult):
    class Meta:
        db_table = 'parsing_sale_result'


class SophieResult(models.Model):
    block_id = models.IntegerField(
        default=0
    )
    common_block_id = models.IntegerField(
        default=0
    )
    building_id = models.IntegerField(
        default=0
    )
    lat = models.FloatField(
        default=0,
        null=True
    )
    lon = models.FloatField(
        default=0,
        null=True
    )
    area_max = models.IntegerField(
        default=0,
    )
    rate = models.FloatField(
        default=0,
        null=True,
    )
    broker_id = models.IntegerField(
        default=0
    )
    broker_name = models.CharField(
        max_length=100,
        default=None
    )
    owner_id = models.IntegerField(
        default=0
    )
    callback_date = models.DateField(
        null=True,
        blank=True
    )
    floor = models.IntegerField(
        default=1
    )
    cian_active = models.IntegerField(
        default=0
    )
    common_block_active = models.IntegerField(
        default=0
    )
    common_block_export = models.IntegerField(
        default=0
    )
    building_export = models.IntegerField(
        default=0
    )
    building_priority = models.CharField(
        max_length=25,
        default="Не указан"
    )

    class Meta:
        abstract = True


class SophieResultRent(SophieResult):
    class Meta:
        db_table = 'rent_blocks'


class SophieResultSale(SophieResult):
    class Meta:
        db_table = 'sale_blocks'


class CianAdresses(models.Model):
    building_id = models.IntegerField(
        default=0
    )
    address = models.CharField(
        max_length=255,
        default=None
    )

    class Meta:
        db_table = 'cian_adresses'
