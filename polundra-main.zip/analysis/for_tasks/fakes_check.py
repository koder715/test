from mysql.connector import Error
from django.db import connections
from datetime import date, timedelta
from django.db.models import F, Value, CharField
from django.db.models.functions import Concat

from analysis.models import SortedData
from interface.settings import AGENCY_NAME


def process_fakes(parsing_table):
    """Отработка фейков."""
    statuses = ["Авто-фейк", "Фейк", "Фейк-обработан"]
    records = SortedData.objects.filter(status__name__in=statuses)
    for record in records:
        if record_check(record.agency_name):
            if check_our_fakes(
                parsing_table, record.address, record.floor, record.area_max
            ):
                update_condition = Concat(
                    F('agency_name'),
                    Value(', '),
                    Value(AGENCY_NAME),
                    output_field=CharField()
                )
                SortedData.objects.filter(id=record.id).update(
                    agency_name=update_condition
                )

                print(f"{record.pk} - является нашим фейком!")

            else:
                print(f"{record.pk} не является фейком")


def check_our_fakes(parsing_table, address, floor, area_max):
    try:
        with connections['analytics'].cursor() as cursor:
            agency_name = AGENCY_NAME
            today = date.today()
            yesterday = today - timedelta(days=1)
            query = """
                SELECT cian_id, address, agency_name
                FROM {table}
                WHERE agency_name = %s
                AND address = %s
                AND floor = %s
                AND area_max = %s
                AND created_at BETWEEN %s AND %s
            """.format(table=parsing_table)

            cursor.execute(
                query, (
                    agency_name, address, floor,
                    area_max, yesterday, today
                )
            )
            rows = cursor.fetchone()
            print()

            if rows:
                return True
            else:
                return False

    except Error as e:
        print(e)


def record_check(agency_name):
    """Проверка на агентство."""
    statement = True
    for r in agency_name.split(', '):
        if r == AGENCY_NAME:
            statement = False
            break

    return statement
