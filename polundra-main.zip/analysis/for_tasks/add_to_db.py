import logging
import pandas as pd
from random import randint
from typing import Union, Dict, Any
from django.db import transaction, connections
from django.utils.timezone import make_aware
from datetime import datetime, timedelta

from analysis.models import (
    SortedData, Status, NewData,
    SophieResultRent, SophieResultSale
)
from analysis.functions.sql_templates import create_is_available_template


logger = logging.getLogger(__name__)


class AddToDb:
    model_instance_dict: Dict[str, Dict[Any, Any]] = {
        'competitive': SortedData,
        'new': NewData
    }

    sophie_instance_dict = {
        'Аренда': SophieResultRent,
        'Продажа': SophieResultSale
    }

    def __init__(self, param: str, df: pd.DataFrame) -> None:
        self.param = param
        self.df = df

    def get_table_instance(self) -> Union[SortedData, NewData]:
        """Метод определяет в какую модель сохранять данные."""
        return self.model_instance_dict.get(self.param)

    def block_is_available(self, offer_type, block_id):
        """Метод проверяет галочку 'на рынке'."""
        offer_type_dict: Dict[str, str] = {
            'Аренда': 'rent',
            'Продажа': 'sale'
        }
        with connections['default'].cursor() as cursor:
            temp = create_is_available_template(
                offer_type_dict.get(offer_type), block_id
            )

            cursor.execute(temp)
            row = cursor.fetchone()

        if row[0] == 0:
            logger.info(
                f'Блок {block_id} не на рынке!'
            )
            return True

        return False

    def get_building_priority(self, obj: SortedData) -> str:
        """Метод получает приоритет здания для SortedData."""
        sophie_model = self.sophie_instance_dict.get(
            obj.offer_type
        )

        priority = sophie_model.objects.filter(
            building_id=int(obj.building_id)
        ).first().building_priority

        return priority

    def auto_fake(self, obj):
        if obj.updated_at is not None \
                and self.block_is_available(obj.offer_type, obj.block_id):

            if obj.cian_created - obj.updated_at <= timedelta(days=5):
                obj.status = Status.objects.get(name="Авто-фейк")
                logger.info(
                    f"Объявление №{obj.block_id} является фейком!"
                )

    def add_to_db(self, update_field: str):
        data = self.df.to_dict('records')

        try:
            with transaction.atomic():
                for row in data:
                    # получение поля для апдейта
                    # если нет блока, то это новый блок
                    update_value = row.get(update_field)

                    model_instance = self.get_table_instance()

                    # если здание есть, то это SortedData
                    if model_instance == NewData \
                            and row.get('building_id') is not None:
                        model_instance = SortedData
                        logger.info(
                            f'Определено здание, заменил на {model_instance}'
                        )

                    # проверка на лишний ключ
                    if model_instance != NewData \
                            and 'block_type' in row.keys():
                        logger.info("Удалил block_type")
                        row.pop('block_type')

                    logger.info(
                        f'Определена модель {model_instance}'
                    )

                    # извлечение поля для обновления
                    row.pop(update_field)

                    logger.info(
                        "Производится проверка объекта "
                        f"{update_field} - {update_value} "
                        "на наличие в БД"
                    )

                    # проверяем, существует ли уже объект с таким уникальным полем
                    obj = model_instance.objects.filter(
                        **{update_field: update_value}
                    ).first()

                    if obj:
                        logger.info(
                            f'Объект {update_field} - {update_value} '
                            'найден!'
                        )

                        # если объект существует, обновляем его
                        for key, value in row.items():
                            setattr(obj, update_field, update_value)
                            setattr(obj, key, value)

                        # если блок обновлен то выставляется дата обновления
                        if hasattr(obj, 'updated'):
                            obj.updated = datetime.now().date()

                        obj.save()
                        logger.info(
                            f'Объект {model_instance} {update_value} '
                            'был найден и обновлен в БД!\n'
                        )

                    else:
                        # если объект не существует, создаем новый с уникальным первичным ключом
                        custom_id = randint(1, 100000)
                        while model_instance.objects.filter(pk=custom_id).exists():
                            custom_id = randint(1, 100000)

                        logger.info(f"Сгенерировал уникальный ключ {custom_id}!")

                        obj = model_instance(pk=custom_id, **{update_field: update_value}, **row)
                        obj.status = Status.objects.get(name='Новое')
                        obj.status_update = make_aware(datetime.now())
                        if update_field == 'block_id':
                            self.auto_fake(obj)

                        if isinstance(obj, SortedData):
                            obj.building_priority = self.get_building_priority(obj)
                            logger.info(
                                f'Определил приоритет у блока {obj.block_id} '
                                f'{obj.building_priority}'
                            )

                        obj.save()
                        logger.info(
                            f'Объект {model_instance} {update_value} '
                            'был создан в БД!\n'
                        )

                logger.info("Задача по добавлению объектов завершена!")
        except Exception as ex:
            logger.error(ex, exc_info=True)
