import logging
from random import randint
from typing import List, Union
from django.forms import model_to_dict
from django.db.utils import IntegrityError
from analysis.models import (
    SortedData, Status,
    MyBlocks, AssistBlocks,
    DiffRespBr, NewRentBlocks,
    NewData
)


logger = logging.getLogger('__name__')


class Transfer:
    """Класс для трансфера объявлений из SortedData."""

    def transfer_my_ads(self, instance, param):
        models_dict = {
            'myblocks': [MyBlocks, AssistBlocks, DiffRespBr],
            'newblocks': [NewRentBlocks],
            'sorted_data': SortedData,
            'newdata': NewData
        }

        to_exclude = [
            'block_id', 'common_block_id', 'updated_at',
            'owner_count', 'is_active', 'updated',
            'status_update', 'cian_created'
        ] if instance == 'newdata' else []

        # список моделей
        models: List[Union[
            MyBlocks, AssistBlocks,
            DiffRespBr, NewRentBlocks
        ]] = models_dict.get(param)

        model_instnance: Union[
            SortedData, NewData
        ] = models_dict.get(instance)

        # получаем объекты моделей
        for model in models:
            ads = model.objects.all()

            for ad in ads:
                # получаем статус
                status = ad.status 
                # данные записи
                kwargs = model_to_dict(ad, exclude=['pk', 'status', *to_exclude])
                print(kwargs)

                custom_id = randint(1, 100000)

                # проверяем, существует ли уже объект с таким первичным ключом
                while model_instnance.objects.filter(pk=custom_id).exists():
                    custom_id = randint(1, 100000)

                logger.info(f"Сгенерировал уникальный ключ {custom_id}!")

                try:
                    new_instance = model_instnance.objects.create(
                        pk=custom_id,
                        **kwargs
                    )
                    new_instance.status = status
                    new_instance.save()

                    logger.info(
                        f"Объявление {new_instance.pk} добавлено"
                    )

                except AttributeError:
                    logger.error(f"Ошибка с атрибутом {ad.pk}", exc_info=True)

                except new_instance.MultipleObjectsReturned:
                    logger.error(f"Ошибка с cian_id у модели {ad.pk}", exc_info=True)

                except IntegrityError:
                    logger.error(f"Ошибка в создании первичного ключа!", exc_info=True)
