from mysql.connector import connect, Error
from analysis.models import SortedData
from interface.settings import (
    OFHOST, OFDATABASE,
    OFUSER, OFPASS
)


def make_sql_temp(building_id):
    """Формирование запроса."""
    temp = f"""
        SELECT b.broker_id,
            CONCAT(rb.first_name, ' ', rb.last_name) AS full_name
        FROM buildings AS b
        INNER JOIN responsible_brokers as rb ON b.broker_id = rb.user_id
        WHERE b.id = {building_id}
    """

    return temp


def sql_request(temp):
    """Отправка запроса и получение результата."""
    try:
        with connect(
            host=OFHOST,
            database=OFDATABASE,
            user=OFUSER,
            password=OFPASS,
        ) as connection:
            with connection.cursor(buffered=True) as cursor:
                query = temp

                cursor.execute(query, )

                res = cursor.fetchone()

                if res:
                    return res
                else:
                    return (None, None)

    except Error as e:
        print(e)


def update_resp():
    """Обновление ответственных в записях."""
    blocks = SortedData.objects.all()

    for b in blocks:
        temp = make_sql_temp(b.building_id)
        resp_id, resp_name = sql_request(temp)
        print(resp_id, resp_name)

        b.resp_id = resp_id
        b.resp_name = resp_name
        b.save()
