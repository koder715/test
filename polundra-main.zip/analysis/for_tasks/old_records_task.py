import logging
from typing import List, Union
from datetime import date, timedelta
from django.db import connections
from mysql.connector import Error

from analysis.models import (
    SortedData, NewData
)


logger = logging.getLogger(__name__)


def delete_fakes():
    objs = SortedData.objects.filter(
        status__name__in=[
            "Фейк", "Фейк-Сдано", "Фейк-Вымышленный блок",
            "Отправлено в чат", "Отправить жалобу"
        ]
    )

    for obj in objs:
        today = date.today()
        if obj.status_update - today >= timedelta(days=30):
            obj.delete()


def request_template_not_in_parsing(table):
    temp = """
        SELECT cian_id
        FROM {table}
        WHERE created_at BETWEEN %s AND %s
    """.format(table=table)

    return temp


def request_template_change_id(table, address, area, floor):
    temp = """
        SELECT cian_id, agency_name
        FROM {table}
        WHERE address = '{address}'
        AND ABS(area_max - {area}) / area_max <= 0.05
        AND floor = {floor}
        AND created_at BETWEEN %s AND %s
    """.format(
        table=table,
        address=address,
        area=area,
        floor=floor
    )

    return temp


# функция, удаляющая все записи со статусом "Новое"
def delete_not_in_parsing(
    table, param,
    model_intance: Union[SortedData, NewData]
):
    """Удаление устаревших объявлений."""
    objs = model_intance.objects.filter(
        offer_type=param
    ).exclude(agency_name__startswith="Рентавик Сайт")

    # здесь надо делать запрос, вне цикла
    try:
        with connections['analytics'].cursor() as cursor:
            today = date.today()
            yesterday = today - timedelta(days=1)

            sql_t = request_template_not_in_parsing(table)
            cursor.execute(sql_t, (yesterday, today))
            rows = cursor.fetchall()
            ids = [row[0] for row in rows]

            for obj in objs:
                if obj.cian_id.split()[0].replace(',', '') not in ids:
                    obj.delete()
                    logger.info(f"Объект {obj.cian_id} удален!")

                else:
                    logger.info(f"Объект {obj.cian_id} актуален!")

    # обработка возможного исключения
    except Error as e:
        logger.error(f"Ошибка при подключении к БД {e}")


def form_masterpiece(row):
    cian_ids = ''
    agency_names = ''

    for cian_id, agency_name in row:
        if len(cian_ids) < 245 and agency_name not in agency_names:
            cian_ids = cian_ids + ', ' + str(cian_id) \
                if cian_ids else cian_ids + str(cian_id)
            agency_names = agency_names + ', ' + str(agency_name) \
                if agency_names else agency_names + str(agency_name)

    return cian_ids, agency_names


def change_id_records(
    table, param,
    model_intance: Union[SortedData, NewData]
):
    # получаем все записи
    objs = model_intance.objects.filter(offer_type=param)
    today = date.today()
    yesterday = today - timedelta(days=1)

    try:
        with connections['analytics'].cursor() as cursor:
            for obj in objs:
                logger.info(
                    f"Адрес: {obj.address}\n"
                    f"Метраж: {obj.area_max}\n"
                    f"Этаж: {obj.floor}"
                )

                if obj.floor is not None:
                    sql_t = request_template_change_id(
                        table,
                        obj.address,
                        obj.area_max,
                        obj.floor
                    )

                    cursor.execute(sql_t, (yesterday, today))
                    row = cursor.fetchall()
                    old_id = obj.cian_id

                    if row:
                        logger.info(
                            "Успешно нашел свежую запись из парсинга "
                            f"{obj.pk}"
                        )
                        cian_id, agency_name = form_masterpiece(row)
                        obj.cian_id = cian_id
                        obj.agency_name = agency_name
                        obj.save()
                        logger.info(
                            f"Заменил параметры у {obj.pk}\n"
                            f"Старый: {old_id}; Новый: {cian_id}\n"
                        )

            logger.info("Закончил работы по замене!")

    # обработка возможного исключения
    except Error as e:
        logger.error(f"Ошибка при подключении к БД {e}")


def delete_status_new():
    models: List[Union[SortedData, NewData]] = [SortedData, NewData]
    for model in models:
        model.objects.filter(status__name__in=[
            "Новое", "Авто-фейк"
        ]).exclude(agency_name__startswith="Рентавик Сайт").delete()
        logger.info(
            f"Объекты {model} со статусом 'Новое' удалены!"
        )


def delete_rentavik_new():
    models: List[Union[SortedData, NewData]] = [SortedData, NewData]
    for model in models:
        query = model.objects.filter(status__name__in=[
            "Новое", "Авто-фейк"
        ])
        query = query.filter(agency_name__startswith="Рентавик Сайт")
        query.delete()
        logger.info(
            f"Объекты Рентавика {model} со статусом 'Новое' удалены!"
        )
