from django.conf import settings
from django.shortcuts import render


def info(request):
    """Вью для справочной информации."""

    return render(request, 'info_page.html')


def custom_404(request, exception):
    return render(request, '404.html', {'debug': settings.DEBUG})
