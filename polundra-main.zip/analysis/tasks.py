from celery.utils.log import get_task_logger

from interface.celery import app

from interface.settings import (
    PARSING_RENT, PARSING_SALE,
    RENT_TABLE, SALE_TABLE,
    RENT_PARAM, SALE_PARAM,
    TG_RENT_BLOCKS, TG_SALE_BLOCKS
)
from .models import SortedData, NewData
from .functions.base_export import GetCompetitiveAds
from .for_tasks.old_records_task import (
    delete_status_new,
    delete_not_in_parsing,
    change_id_records,
    delete_fakes
)
from .for_tasks.fakes_check import process_fakes
from stats.xml_parsing import download_xml
from stats.parse_mismatch import DefectiveAds
from ads_summ.tasks.tasks_functions import GetSummedAds
from actualising_report.models import (
    PrescriptionControl, NoPhotos,
    ForPost, OnlyMulti, OnlyActive
)
from actualising_report.tasks_functions.report_classes import Reports
from actualising_report.tasks_functions.send_notification \
    import send_telegram_notif, send_block_changes_notif
from actualising_report.photos_updated.updated_photos_report\
    import UpdatedPhotosReport
from actualising_report.tasks_functions.clear_blacklist import BlackListTask
from analysis.functions.save_last_parsing import SaveLastParsing
from analysis.functions.save_sophie_base import SaveSophie
from broker_cabinet.changes_tracking.execute_track import Execute


logger = get_task_logger(__name__)


@app.task(ignore_result=True)
def save_rent_mysql_data():
    """Метод выгружает данные парсинга и Софи."""
    p_rent = SaveLastParsing(
        PARSING_RENT,
        'rent'
    )
    p_rent.save_parsing_data()

    s_rent = SaveSophie(
        RENT_TABLE,
        RENT_PARAM
    )
    s_rent.save_sophie_result()
    s_rent.get_cian_addresses()


@app.task(ignore_result=True)
def save_sale_mysql_data():
    """Метод выгружает данные парсинга и Софи."""
    p_sale = SaveLastParsing(
        PARSING_SALE,
        'sale'
    )
    p_sale.save_parsing_data()

    s_sale = SaveSophie(
        SALE_TABLE,
        SALE_PARAM
    )
    s_sale.save_sophie_result()
    s_sale.get_cian_addresses()


@app.task(ignore_result=True)
def del_mysql_data():
    """Метод очищает данные парсинга и Софи."""
    p_rent = SaveLastParsing(
        PARSING_RENT,
        'rent'
    )
    p_sale = SaveLastParsing(
        PARSING_SALE,
        'sale'
    )
    p_rent.delete_parsing_data()
    p_sale.delete_parsing_data()

    s_rent = SaveSophie(
        RENT_TABLE,
        RENT_PARAM
    )
    s_sale = SaveSophie(
        SALE_TABLE,
        SALE_PARAM
    )
    s_rent.delete_sophie_result()
    s_sale.delete_sophie_result()


@app.task(ignore_result=True)
def sort_rent_results():
    """Задача получения объявлений аренды."""
    try:
        rent_competitive = GetCompetitiveAds(
            "rent_blocks",
            "price_meter_year_id",
            "cian_parsed_rents"
        )
        rent_competitive.get_competitive_objects()
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def sort_sale_results():
    """Задача получения объявлений продажи."""
    try:
        sale_competitive = GetCompetitiveAds(
            "sale_blocks",
            "price_per_meter_id",
            "cian_parsed_sales"
        )
        sale_competitive.get_competitive_objects()
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def delete_old_records():
    """Задача удаления устаревших объявлений."""
    try:
        delete_status_new()
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def delete_not_in_parsing_records():
    """Задача удаления устаревших объявлений."""
    try:
        delete_not_in_parsing('cian_parsed_rents', 'Аренда', SortedData)
        delete_not_in_parsing('cian_parsed_sales', 'Продажа', SortedData)
        delete_not_in_parsing('cian_parsed_rents', 'Аренда', NewData)
        delete_not_in_parsing('cian_parsed_sales', 'Продажа', NewData)
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def change_id_records_task():
    """Задача удаления устаревших объявлений."""
    try:
        change_id_records('cian_parsed_rents', 'Аренда', SortedData)
        change_id_records('cian_parsed_sales', 'Продажа', SortedData)
        change_id_records('cian_parsed_rents', 'Аренда', NewData)
        change_id_records('cian_parsed_sales', 'Продажа', NewData)
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def delete_old_fakes():
    """Задача удаления устаревших объявлений."""
    try:
        delete_fakes()
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def fakes_sort():
    """Задача для определения фейковых объявлений."""
    try:
        process_fakes(PARSING_RENT)
        process_fakes(PARSING_SALE)
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def backup_reg():
    """Задача получения статистики по бекапам."""
    try:
        download_xml("0600")
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def backup_multi():
    """Задача получения статистики по мульти бекапам."""
    try:
        download_xml("0700_multi")
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def send_mismatch():
    """Задача поиска несостыковок выгрузки с сообщением в тг."""
    try:
        cian_xml = DefectiveAds()
        cian_xml.url = (
            "https://base2.of.ru/api/v1/cian-feed-elements/-actions/feed"
        )
        cian_xml.lost_ads("Циан")

        avito_xml = DefectiveAds()
        avito_xml.url = (
            "https://base2.of.ru/api/v1/avito-feed-elements/-actions/feed"
        )
        avito_xml.lost_ads("Авито")

        mismatch = DefectiveAds()
        mismatch.cian_url = (
            "https://base2.of.ru/api/v1/cian-feed-elements/-actions/feed"
        )
        mismatch.avito_url = (
            "https://base2.of.ru/api/v1/avito-feed-elements/-actions/feed"
        )
        mismatch.cian = "Циан"
        mismatch.avito = "Авито"
        mismatch.mismatch()

    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def get_summed_ads():
    """Задача получения суммированных блоков."""
    try:
        g = GetSummedAds()
        g.add_to_db_summed()
        g.add_to_db_single()
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def prescription_report():
    """Задача по контролю давности объявлений."""
    try:
        prescription_rent = Reports(
            "prescription",
            PrescriptionControl,
            RENT_TABLE, RENT_PARAM,
        )
        prescription_rent.add_to_db()

        prescription_sale = Reports(
            "prescription",
            PrescriptionControl,
            SALE_TABLE, SALE_PARAM,
        )
        prescription_sale.add_to_db()

    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def no_photo_report():
    """Задача получения блоков без фото."""
    try:
        NoPhotos.objects.all().delete()
        no_photo_rent = Reports(
            "no_photo",
            NoPhotos,
            RENT_TABLE, RENT_PARAM,
        )
        no_photo_rent.add_to_db()

        no_photo_sale = Reports(
            "no_photo",
            NoPhotos,
            SALE_TABLE, SALE_PARAM,
        )
        no_photo_sale.add_to_db()

    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def for_post_report():
    """Задача получения объявлений на выгрузку."""
    try:
        ForPost.objects.all().delete()
        for_post_cian_rent = Reports(
            "for_post",
            ForPost,
            RENT_TABLE, RENT_PARAM,
            "cian"
        )
        for_post_cian_rent.add_to_db()

        for_post_cian_sale = Reports(
            "for_post",
            ForPost,
            SALE_TABLE, SALE_PARAM,
            "cian"
        )
        for_post_cian_sale.add_to_db()

        for_post_avito_rent = Reports(
            "for_post",
            ForPost,
            RENT_TABLE, RENT_PARAM,
            "avito"
        )
        for_post_avito_rent.add_to_db()

        for_post_avito_sale = Reports(
            "for_post",
            ForPost,
            SALE_TABLE, SALE_PARAM,
            "avito"
        )
        for_post_avito_sale.add_to_db()

        for_post_not_active_cian_rent = Reports(
            "for_post_not_active",
            ForPost,
            RENT_TABLE, RENT_PARAM,
            "cian"
        )
        for_post_not_active_cian_rent.add_to_db()

        for_post_not_active_cian_sale = Reports(
            "for_post_not_active",
            ForPost,
            SALE_TABLE, SALE_PARAM,
            "cian"
        )
        for_post_not_active_cian_sale.add_to_db()

        for_post_not_active_avito_rent = Reports(
            "for_post_not_active",
            ForPost,
            RENT_TABLE, RENT_PARAM,
            "avito"
        )
        for_post_not_active_avito_rent.add_to_db()

        for_post_not_active_avito_sale = Reports(
            "for_post_not_active",
            ForPost,
            SALE_TABLE, SALE_PARAM,
            "avito"
        )
        for_post_not_active_avito_sale.add_to_db()

        send_telegram_notif()

    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def photos_updated():
    """Задача для отслеживания изменений фото."""
    try:
        rent_photos = UpdatedPhotosReport(RENT_TABLE)
        rent_photos.add_to_db()
        sale_photos = UpdatedPhotosReport(SALE_TABLE)
        sale_photos.add_to_db()

    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def only_multi_report():
    """
    Задача получения объектов, которые можно
    добавить как части в мультиобъявления.
    """
    try:
        OnlyMulti.objects.all().delete()
        only_multi_rent = Reports(
            "only_multi",
            OnlyMulti,
            RENT_TABLE, RENT_PARAM,
        )
        only_multi_rent.add_to_db()

    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def only_active_report():
    """
    Задача по активным блокам
    с выключенными галкам на выгрузку у здания и/или блока.
    """
    try:
        OnlyActive.objects.all().delete()
        only_active_rent = Reports(
            "only_active",
            OnlyActive,
            RENT_TABLE, RENT_PARAM,
        )
        only_active_rent.add_to_db()

        only_active_sale = Reports(
            "only_active",
            OnlyActive,
            SALE_TABLE, SALE_PARAM,
        )
        only_active_sale.add_to_db()

    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def send_block_changes_task():
    """
    Рассылка по изменениям блоков.
    """
    try:
        send_block_changes_notif(
            'updated_at', RENT_TABLE, RENT_PARAM,
            TG_RENT_BLOCKS
        )
        send_block_changes_notif(
            'updated_at', SALE_TABLE, SALE_PARAM,
            TG_SALE_BLOCKS
        )

    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def blacklist_task_for_post():
    try:
        b_rent = BlackListTask(RENT_TABLE, 'rent', 'cian')
        b_rent.create_connection()
        b_sale = BlackListTask(SALE_TABLE, 'sale', 'cian')
        b_sale.create_connection()
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )


@app.task(ignore_result=True)
def broker_cabinet_task():
    try:
        e = Execute()
        e.execute()
    except Exception as ex:
        logger.error(
            f'Возникла ошибка при выполнении задачи! {ex}', exc_info=True
        )
