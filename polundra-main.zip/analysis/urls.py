from django.urls import path
from . import views


handler404 = 'analysis.views.custom_404'


urlpatterns = [
    path('info/', views.info, name='info_page'),
]
