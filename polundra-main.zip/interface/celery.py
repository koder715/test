import os
from celery import Celery

# Установка переменной окружения для настройки django и celery
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'interface.settings')

# Создание экземпляра celery приложения
app = Celery('interface')

# Загрузка конфигурации celery из django settings.py
app.config_from_object('django.conf:settings', namespace='CELERY')

# Обнаружение и загрузка задач из всех зарегистрированных приложений Django
app.autodiscover_tasks()
app.conf.enable_utc = False
